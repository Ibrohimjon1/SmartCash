package hunter.example.com.smartcashadmin.Klent;

/**
 * Created by Hunter on 13.09.2018.
 */

public class Klent_list {
    String  id;
    String num;
    String nomi;
    String klent;
    String telNum;

    public Klent_list(String id, String num, String nomi, String klent, String telNum) {
        this.id = id;
        this.num = num;
        this.nomi = nomi;
        this.klent = klent;
        this.telNum = telNum;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNomi() {
        return nomi;
    }

    public void setNomi(String nomi) {
        this.nomi = nomi;
    }

    public String getKlent() {
        return klent;
    }

    public void setKlent(String klent) {
        this.klent = klent;
    }

    public String getTelNum() {
        return telNum;
    }

    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }
}
