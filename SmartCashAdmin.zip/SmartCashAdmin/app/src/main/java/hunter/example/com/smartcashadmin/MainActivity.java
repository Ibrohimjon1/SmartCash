package hunter.example.com.smartcashadmin;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import hunter.example.com.smartcashadmin.Brodcast.ServisReceiver;
import hunter.example.com.smartcashadmin.DB.Sqlite_helper;
import hunter.example.com.smartcashadmin.Filial.Filial_royhat;
import hunter.example.com.smartcashadmin.Generatsiya.Gen_oyna;
import hunter.example.com.smartcashadmin.Klent.Klent_oyna;
import hunter.example.com.smartcashadmin.Telefonlar.Telefon_Royhat;

public class MainActivity extends AppCompatActivity {
    Button btn_Gen,btn_Klent,btn_Filial, btn_Telefon;
    public static Sqlite_helper SQLITE_HELPER;
    public static String url_address = "http://192.168.1.66/smart_cash/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_Gen=(Button)findViewById(R.id.Button_Generatsiya);
        btn_Klent=(Button)findViewById(R.id.Button_Klent);
        btn_Filial=(Button)findViewById(R.id.Button_Filial);
        btn_Telefon =(Button)findViewById(R.id.Button_Telefon);


        if (!isMyServiceRunning(ServisReceiver.class)) {
            Intent intent = new Intent(this, ServisReceiver.class);
            startService(intent);
        }

        TaskniTekshirish(MainActivity.this);
        init();
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {

                return true;
            }
        }
        return false;
    }

    public void init(){
        btn_Gen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Gen_oyna.class);
                startActivity(intent);
            }
        });

        btn_Klent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Klent_oyna.class);
                startActivity(intent);
            }
        });


        btn_Filial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Filial_royhat.class);
                startActivity(intent);
            }
        });


        btn_Telefon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Telefon_Royhat.class);
                startActivity(intent);
            }
        });


    }

    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static void TaskniTekshirish(Context context) {
        Orqa_fon hozirgi_vaqt = new Orqa_fon(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            hozirgi_vaqt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            hozirgi_vaqt.execute();
        }

    }


    public static class Orqa_fon extends AsyncTask<Void, String, String> {
        ProgressDialog loading;
        Context context;

        public Orqa_fon(Context context) {
            this.context = context;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {

            createDB(context);
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }


    public static void createDB(Context context){

        SQLITE_HELPER = new Sqlite_helper(context, "Base.sqlite", null, 1);

            SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS KLENT (Id INTEGER PRIMARY KEY AUTOINCREMENT, Klent_id VARCHAR,Klent_ismi VARCHAR, Klent_tel VARCHAR,Oshxona VARCHAR)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS GENERATSIYA (Id INTEGER PRIMARY KEY AUTOINCREMENT, Gen_id VARCHAR,Gen_vaqti VARCHAR,Gen_key VARCHAR,Gen_Imei VARCHAR)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS FILIAL (Id INTEGER PRIMARY KEY AUTOINCREMENT, Filial_id VARCHAR,Filial_nomi VARCHAR,Filial_vil VARCHAR,Filial_klentId VARCHAR)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS TELEFON (Id INTEGER PRIMARY KEY AUTOINCREMENT, Telefon_id VARCHAR,Telefon_KassaNomi VARCHAR,Telefon_FilialId VARCHAR,Telefon_holat VARCHAR,Telefon_Mudtlimi VARCHAR,Telefon_MudtlimiVaqti VARCHAR,Telefon_Generatsiya VARCHAR,Telefon_Kalit VARCHAR" +
                ",Telefon_Imei VARCHAR,Telefon_KlentId VARCHAR)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS VILOYAT (Id INTEGER PRIMARY KEY AUTOINCREMENT, Viloyat_id VARCHAR,Viloyat_nomi VARCHAR)");


    }
}
