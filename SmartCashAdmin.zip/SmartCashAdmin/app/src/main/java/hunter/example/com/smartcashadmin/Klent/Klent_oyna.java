package hunter.example.com.smartcashadmin.Klent;

import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

import hunter.example.com.smartcashadmin.MainActivity;
import hunter.example.com.smartcashadmin.R;

public class Klent_oyna extends AppCompatActivity {
    static ArrayList<Klent_list> klent_lists = new ArrayList<>();
    static Klent_adapter klent_adapter;
    ListView lv;
    ImageButton imBtn_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klent_oyna);
        lv = (ListView) findViewById(R.id.listviewKlent);
        imBtn_add=(ImageButton)findViewById(R.id.btn_klent_add);


        klent_adapter = new Klent_adapter(Klent_oyna.this, klent_lists);
        lv.setAdapter(klent_adapter);
        GetKlentData();
        imBtn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Klent_oyna.this, Klent_qoshish.class);
                startActivity(intent);
            }
        });

    }

    public void GetKlentData() {
            Klent_Oluvchi klent_oluvchi = new Klent_Oluvchi(Klent_oyna.this, "all", klent_lists, klent_adapter);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                klent_oluvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            } else {
                klent_oluvchi.execute();
            }
//        }
    }

}
