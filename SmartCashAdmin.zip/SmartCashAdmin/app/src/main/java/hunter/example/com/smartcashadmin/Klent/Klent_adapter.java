package hunter.example.com.smartcashadmin.Klent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import hunter.example.com.smartcashadmin.R;

/**
 * Created by Hunter on 13.09.2018.
 */

public class Klent_adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Klent_list> klent_lists;

    public Klent_adapter(Context context, ArrayList<Klent_list> klent_lists) {
        this.context = context;
        this.klent_lists = klent_lists;
    }

    @Override
    public int getCount() {
        return klent_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return klent_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        TextView txt_Id,txt_Num,txt_Nomi,txt_Fio,txt_tel;
        View view_holat;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        Klent_list klentList=klent_lists.get(position);
        ViewHolder holder=new ViewHolder();
        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.klent_item,null);

            holder.txt_Id=row.findViewById(R.id.txt_klent_Id);
            holder.txt_Num=row.findViewById(R.id.txt_klent_Num);
            holder.txt_Nomi=row.findViewById(R.id.txt_klent_Nomi);
            holder.txt_Fio=row.findViewById(R.id.txt_klent_FIO);
            holder.txt_tel=row.findViewById(R.id.txt_klent_Tel);
            holder.view_holat=row.findViewById(R.id.View_Holat);
                row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }

        holder.txt_Id.setText(klentList.getId());
        holder.txt_Num.setText(klentList.getNum());
        holder.txt_Nomi.setText(klentList.getNomi());
        holder.txt_Fio.setText(klentList.getKlent());
        holder.txt_tel.setText(klentList.getTelNum());
//         String cond=klentList.getHolat();
//         if (cond.equals("1")){
//             holder.view_holat.setBackgroundColor(Color.GREEN);
//         }else if (cond.equals("0")){
//             holder.view_holat.setBackgroundColor(Color.RED);
//
//         }
        return row;
    }
}
