package hunter.example.com.smartcashadmin.Brodcast;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.ColorSpace;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import hunter.example.com.smartcashadmin.Klent.Klent_qoshish;
import hunter.example.com.smartcashadmin.MainActivity;
import hunter.example.com.smartcashadmin.R;
import hunter.example.com.smartcashadmin.Telefonlar.Telefon_Oyna;
import hunter.example.com.smartcashadmin.mMySql.Connector;

/**
 * Created by Hunter on 14.09.2018.
 */

public class ServisReceiver extends Service {


    @Override
    public void onCreate() {
        super.onCreate();
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        Notification notification = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Smart Cash")
                .setContentText("Dasturni ishga tushirish uchun bosing!")
                .setContentIntent(pendingIntent).build();

        startForeground(1337, notification);
    }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String url = "";
       // try {
//            url = MainActivity.url_address +"update.php";
//            url = MainActivity.url_address +"Update.php?klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
       // } catch (UnsupportedEncodingException e) {
          //  e.printStackTrace();
        //}
        Functsiya(this);
        return Service.START_STICKY;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "Service Destroy", Toast.LENGTH_LONG).show();
        Intent restartService = new Intent("Vaqt_hisoblovchi");
        sendBroadcast(restartService);
    }

    public class MyBinder extends Binder {
//        public Hisoblovchi getService() {
//            return Hisoblovchi.this;
//        }
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            Toast.makeText(getApplicationContext(), "Service " + msg.arg1, Toast.LENGTH_LONG).show();
        }
    };

    public void Functsiya(final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String url = "";
                while (true) {
                    if (isOnline(getApplicationContext())) {

                        Cursor cursor = MainActivity.SQLITE_HELPER.getData("SELECT * FROM GENERATSIYA  ORDER BY Gen_vaqti DESC");
                        if (cursor.getCount()!=0){
                            cursor.moveToFirst();
                            String oxrgiVaqt=cursor.getString(2);
                            try {
                                url = MainActivity.url_address + "Download_Gen.php?vaqti="+URLEncoder.encode(oxrgiVaqt, "UTF-8");
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                        }else {
                            url = MainActivity.url_address + "Download_GenAll.php";
                        }
                        downloadData(context,url);
                        Message msg = handler.obtainMessage();
                        msg.arg1 = 5;
                        handler.sendMessage(msg);
                    }
                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

    }



    private BufferedReader reader = null;
    private String downloadData(Context context, String url) {
        HttpURLConnection con = Connector.connection(url);
        if (con == null) {
            return "Internetni tekshiring!";
        }
        InputStream inputStream = null;
        String xatolikar = "";
        try {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject json = null;
                    try {
                        json = new JSONObject(result);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (json != null) {
                        JSONObject object = null;
                        try {
                            object = json.getJSONObject("qiymat");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        boolean tugadi = true;
                        int sonlari = 0;

                        try {
                            sonlari = json.getInt("soni");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        for (int i = 1; i < sonlari; i++) {
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = object.getJSONObject("qiy_" + i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                tugadi = false;
                            }
                            if (tugadi) {
                                String id = "";
                                try {
                                    id = jsonObject.getString("id");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                if (id.equals("mal_yoq")) {
                                    tugadi = false;
                                } else {
                                    String vaqti = null;
                                    try {
                                        vaqti = jsonObject.getString("vaqti");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    String gen_key = null;
                                    try {
                                        gen_key = jsonObject.getString("gen_key");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    String imei = null;
                                    try {
                                        imei = jsonObject.getString("imei");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    String sqlq = "INSERT INTO GENERATSIYA VALUES (NULL ,?, ?, ?, ?)";
                                    MainActivity.SQLITE_HELPER.Mal_qoshish_4ta(id,vaqti,gen_key,imei,sqlq);
                                    showNotification(id,gen_key,vaqti);
                                }
                            }
                        }
                    }
                }

        } catch (UnknownHostException e) {
            e.printStackTrace();
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            xatolikar = xatolikar + " // " + e.getMessage();
        }  finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    xatolikar = xatolikar + " // " + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return "Internetni tekshiring!" + "  " + xatolikar;
    }

    private void showNotification(String id,String message,String ttime) {
        NotificationCompat.Builder builder =
                (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                        //  .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(message)
                        .setContentText(ttime)
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Intent notificationIntent = new Intent(this, Telefon_Oyna.class);
        notificationIntent.putExtra("id",id);
        notificationIntent.putExtra("qaysi","yangi");
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(contentIntent);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
        r.play();
        long[] vLongs = {500,1000};
        builder.setVibrate(vLongs);
        manager.notify(Integer.parseInt(id), builder.build());
    }


    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert cm != null;
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
}
