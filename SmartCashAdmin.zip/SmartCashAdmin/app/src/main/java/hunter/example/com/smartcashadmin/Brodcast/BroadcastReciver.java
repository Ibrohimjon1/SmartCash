package hunter.example.com.smartcashadmin.Brodcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Hunter on 14.09.2018.
 */

public class BroadcastReciver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) {
            Intent pushIntent = new Intent(context, ServisReceiver.class);
            context.startService(pushIntent);
        }

    }
}
