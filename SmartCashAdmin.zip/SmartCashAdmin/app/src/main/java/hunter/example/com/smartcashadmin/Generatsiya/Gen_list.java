package hunter.example.com.smartcashadmin.Generatsiya;

/**
 * Created by Hunter on 13.09.2018.
 */

public class Gen_list {
    String Id;
    String Sana;
    String Gen_Key;
    String Imei;
    String Num;

    public Gen_list(String id, String sana, String gen_Key, String imei, String num) {
        Id = id;
        Sana = sana;
        Gen_Key = gen_Key;
        Imei = imei;
        Num = num;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getSana() {
        return Sana;
    }

    public void setSana(String sana) {
        Sana = sana;
    }

    public String getGen_Key() {
        return Gen_Key;
    }

    public void setGen_Key(String gen_Key) {
        Gen_Key = gen_Key;
    }

    public String getImei() {
        return Imei;
    }

    public void setImei(String imei) {
        Imei = imei;
    }

    public String getNum() {
        return Num;
    }

    public void setNum(String num) {
        Num = num;
    }
}
