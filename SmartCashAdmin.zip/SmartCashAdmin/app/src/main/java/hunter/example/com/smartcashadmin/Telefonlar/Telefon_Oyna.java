package hunter.example.com.smartcashadmin.Telefonlar;

import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

import hunter.example.com.smartcashadmin.Klent.Jonatuvchi;
import hunter.example.com.smartcashadmin.MainActivity;
import hunter.example.com.smartcashadmin.R;
import hunter.example.com.smartcashadmin.mMySql.Connector;

import static hunter.example.com.smartcashadmin.Brodcast.ServisReceiver.isOnline;
import static hunter.example.com.smartcashadmin.MainActivity.url_address;

public class Telefon_Oyna extends AppCompatActivity {
    Button btn_chiqish, btn_saqlash;
    public static EditText edt_TelNum, edt_Klent, edt_KassaNomi,
            edt_MudatVaqti, edt_Generatsiya;
    public static Spinner spinner_Oshxona, spinner_Filial, spinner_Xudud;
    public static Switch switch_Holat, switch_Mudat;
    public static TextView txt_Key;
    public static String holat, muddat, imeimm = "";
    String Gen_id, Qaysi = "";

    public static ArrayList<String> oshxona_Nomi = new ArrayList<String>();
    public static ArrayList<String> oshxona_ID = new ArrayList<String>();
    public static ArrayList<String> filial_Nomi = new ArrayList<String>();
    public static ArrayList<String> filial_ID = new ArrayList<String>();
    public static ArrayList<String> viloyat_Nomi = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telefon__oyna);
        txt_Key = (TextView) findViewById(R.id.txt_klent_qoshish_Key);

        switch_Holat = (Switch) findViewById(R.id.switchklent_qoshish_Holat);
        switch_Mudat = (Switch) findViewById(R.id.switch_klent_qoshish_Mudat);


        spinner_Filial = (Spinner) findViewById(R.id.spinner_klent_qoshish_Filial);
        spinner_Oshxona = (Spinner) findViewById(R.id.spinner_klent_qoshish_Oshxona);
        spinner_Xudud = (Spinner) findViewById(R.id.spinner_klent_qoshish_Xudud);
        edt_Generatsiya = (EditText) findViewById(R.id.edt_klent_qoshish_Generatsiya);
        edt_KassaNomi = (EditText) findViewById(R.id.edt_klent_qoshish_KassaNomi);
        edt_Klent = (EditText) findViewById(R.id.edt_klent_qoshish_Klent);
        edt_MudatVaqti = (EditText) findViewById(R.id.edt_klent_qoshish_MudatVaqti);
        edt_TelNum = (EditText) findViewById(R.id.edt_klent_qoshish_TelNum);

        btn_chiqish = (Button) findViewById(R.id.btn_Klent_qoshish_Chiqish);
        btn_saqlash = (Button) findViewById(R.id.btn_Klent_qoshish_Saqlash);

        Intent intent = getIntent();
        Gen_id = intent.getStringExtra("id");
        Qaysi = intent.getStringExtra("qaysi");
        if (!Gen_id.equals("") && Qaysi.equals("yangi")) {
            GenerationKey(Gen_id);
        } else if (Qaysi.equals("ozgar")) {

        }
//        loadSpinnerData();
        GetKlentToSpinner();


        switch_Holat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    holat = "1";
                } else if (isChecked == false) {
                    holat = "0";

                }

            }
        });


        switch_Mudat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    edt_MudatVaqti.setEnabled(true);
                    muddat = "1";
                } else {
                    edt_MudatVaqti.setEnabled(false);
                    edt_MudatVaqti.setText("");
                    muddat = "0";
                }
            }
        });

        spinner_Oshxona.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//            String index=oshxona_Nomi.get(position);
                String index1 = oshxona_ID.get(position);
//            String index1=oshxona_ID.get(Integer.parseInt(index));
                FilalJonatish(index1);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btn_chiqish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edt_KassaNomi.getText().toString().equals("") &&
                        !edt_Klent.getText().toString().equals("") &&
                        !edt_MudatVaqti.getText().toString().equals("") &&
                        !edt_Generatsiya.getText().toString().equals("")) {
                    TaskniTekshir();
                }
            }
        });
    }

    private void FilalJonatish(String idd) {
        Telefon_KlentData_Olish telefon_klentData_olish = new Telefon_KlentData_Olish(Telefon_Oyna.this, idd);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            telefon_klentData_olish.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            telefon_klentData_olish.execute();
        }

    }

    private void TaskniTekshir() {
        Telefon_DataJonatish telefon_dataJonatish = new Telefon_DataJonatish(Telefon_Oyna.this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            telefon_dataJonatish.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            telefon_dataJonatish.execute();
        }

    }

    private void GenerationKey(String id) {
        Cursor cur = MainActivity.SQLITE_HELPER.getData("SELECT * FROM GENERATSIYA WHERE Gen_id='" + id + "'");
        String generatsiya = "";
        String vaqt = "";
        String imei = "";
        if (cur.getCount() != 0) {
            cur.moveToFirst();
            generatsiya = cur.getString(3);
            vaqt = cur.getString(2);
            imei = cur.getString(4);
            imeimm = cur.getString(4);
        }
        edt_Generatsiya.setText(generatsiya);
//        String minut=generatsiya.substring()
        String imm = "";
        String sekund = "";
        String minut = "";
        if (imei.length() > 2) {
            imm = imei.substring(0, 3);
        } else {
            imm = String.valueOf(5162);
        }
        if (vaqt.length() > 14) {
            minut = vaqt.substring(14, 16);
            sekund = vaqt.substring(17, 19);
        }

        try {
            int sekundInt = Integer.parseInt(sekund);
            int minutInt = Integer.parseInt(minut);
            int immInt = Integer.parseInt(imm);
            int qiymat = ((minutInt * sekundInt) + 5162) * immInt;
            txt_Key.setText(String.valueOf(qiymat));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public void GetKlentToSpinner() {
        Telefon_Oyna.Klent_Info_Oluvchi klent_info_oluvchi = new Telefon_Oyna.Klent_Info_Oluvchi();
        klent_info_oluvchi.execute();
    }

    private class Klent_Info_Oluvchi extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            String url_klent = "";

            url_klent = url_address + "/Download_KlentId.php";

            String qiymat = parseData(url_klent);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Telefon_Oyna.this, R.layout.spinner_item, oshxona_Nomi);
            spinner_Oshxona.setAdapter(dataAdapter);

        }

        private String parseData(String url_adress) {
            HttpURLConnection con = Connector.connection(url_adress);
            if (con == null) {
                return "inteer";
            }
            InputStream inputStream = null;
            String xatolik = "";
            try {
                if (con != null && isOnline(Telefon_Oyna.this)) {
                    inputStream = new BufferedInputStream(con.getInputStream());
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                    String resulr = reader.readLine();
                    if (resulr != null) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(resulr);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if (json != null) {
                            JSONObject object = null;
                            try {
                                object = json.getJSONObject("qiymat");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            boolean tugadi = true;
                            int sonlari = 0;

                            try {
                                sonlari = json.getInt("soni");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            oshxona_ID.clear();
                            oshxona_Nomi.clear();
                            for (int i = 1; i < sonlari; i++) {
                                JSONObject jsonObject = null;
                                try {
                                    jsonObject = object.getJSONObject("qiy_" + i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    tugadi = false;
                                }
                                if (tugadi) {
                                    String id = null;
                                    try {
                                        id = jsonObject.getString("id");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    if (id.equals("mal_yoq") || id == null) {
                                        tugadi = false;
                                        return "Ushbu sanada ma'lumotlar topilmadi!";
                                    }
                                    String oshxona_nomi = null;
                                    try {
                                        oshxona_nomi = jsonObject.getString("oshxona");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    oshxona_ID.add(id);
                                    oshxona_Nomi.add(oshxona_nomi);
                                } else {
                                    return "";
                                }
                            }
                            return "";
                        }
                    }
                    return "Ushbu sanada ma'lumotlar topilmadi!";
                }
            } catch (SocketException e) {
                e.printStackTrace();
                xatolik += "\n" + e.getMessage();
            } catch (SocketTimeoutException e) {
                e.printStackTrace();
                xatolik += "\n" + e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                xatolik += "\n" + e.getMessage();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        xatolik += "\n" + e.getMessage();
                    }
                }
                if (con != null) {
                    con.disconnect();
                }
            }
            return "" + "\n" + xatolik;
        }
    }

}
