package hunter.example.com.smartcashadmin.Klent;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.ArrayList;

import hunter.example.com.smartcashadmin.MainActivity;
import hunter.example.com.smartcashadmin.R;
import hunter.example.com.smartcashadmin.mMySql.Connector;

import static hunter.example.com.smartcashadmin.MainActivity.url_address;

public class Klent_qoshish extends AppCompatActivity {
    Button btn_chiqish, btn_saqlash;
    public static EditText
            edt_klent_Fio, edt_klent_Tel, edt_klent_Login, edt_klent_Parol, edt_klent_Oshxona;


    String Gen_id, Qaysi = "";
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klent_qoshish);

        edt_klent_Oshxona = (EditText) findViewById(R.id.edt_klent_Oshxona);
        edt_klent_Fio = (EditText) findViewById(R.id.edt_klent_Fio);
        edt_klent_Tel = (EditText) findViewById(R.id.edt_klent_Tel);
        edt_klent_Login = (EditText) findViewById(R.id.edt_klent_Login);
        edt_klent_Parol = (EditText) findViewById(R.id.edt_klent_Parol);


        btn_chiqish = (Button) findViewById(R.id.btn_Klent_qoshish_Chiqish);
        btn_saqlash = (Button) findViewById(R.id.btn_Klent_qoshish_Saqlash);

        Intent intent = getIntent();
        Gen_id = intent.getStringExtra("id");
        Qaysi = intent.getStringExtra("qaysi");

        btn_chiqish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String oshxona = edt_klent_Oshxona.getText().toString();
                String klent = edt_klent_Fio.getText().toString();
                String tel = edt_klent_Tel.getText().toString();
                String login = edt_klent_Login.getText().toString();
                String parol = edt_klent_Parol.getText().toString();
                if (!oshxona.equals("") && !klent.equals("") && tel.equals("") && login.equals("")
                        & parol.equals("")) {
                    TaskniTekshir();
                } else {
             Toast.makeText(Klent_qoshish.this,"Ma`lumotni to`liq kiriting",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void TaskniTekshir() {
        Jonatuvchi jonatuvchi = new Jonatuvchi(Klent_qoshish.this, url);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            jonatuvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            jonatuvchi.execute();
        }

    }

}
