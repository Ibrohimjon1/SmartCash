package hunter.example.com.smartcashadmin.Filial;

/**
 * Created by Hunter on 16.09.2018.
 */

public class Filial_list {
    String id;
    String num;
    String oshxona;
    String filial;
    String hudud;
    String login;
    String parol;

    public Filial_list(String id, String num, String oshxona, String filial, String hudud, String login, String parol) {
        this.id = id;
        this.num = num;
        this.oshxona = oshxona;
        this.filial = filial;
        this.hudud = hudud;
        this.login = login;
        this.parol = parol;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getOshxona() {
        return oshxona;
    }

    public void setOshxona(String oshxona) {
        this.oshxona = oshxona;
    }

    public String getFilial() {
        return filial;
    }

    public void setFilial(String filial) {
        this.filial = filial;
    }

    public String getHudud() {
        return hudud;
    }

    public void setHudud(String hudud) {
        this.hudud = hudud;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getParol() {
        return parol;
    }

    public void setParol(String parol) {
        this.parol = parol;
    }
}
