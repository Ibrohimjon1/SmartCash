package hunter.example.com.smartcashadmin.Filial;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import hunter.example.com.smartcashadmin.Brodcast.ServisReceiver;
import hunter.example.com.smartcashadmin.mMySql.Connector;

/**
 * Created by Hunter on 16.09.2018.
 */

public class Filial_Jonatuvchi extends AsyncTask<Void, Void, String> {

    Activity context;
    String urlAddress;
    ProgressDialog dialog;

    public Filial_Jonatuvchi(Activity context, String urlAddress) {
        this.context = context;
        this.urlAddress = urlAddress;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog = new ProgressDialog(context);
        dialog.setTitle("Jo'natilmoqda");
        dialog.setMessage("Iltimos kuting jo'natilmoqda!");
        dialog.show();

    }

    @Override
    protected String doInBackground(Void... voids) {


        String qiymar = downloadData(urlAddress);
        if (qiymar.equals("ok")) {

            return "ok";

        }
        return "";
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        dialog.dismiss();
        if (s.equals("ok")) {

            Toast.makeText(context, "Muvaffaqqiyatli jo'natildi!", Toast.LENGTH_SHORT).show();
        } else if (s.equals("no")) {
            Toast.makeText(context, "Jo`natishda hatolik bo`ldi", Toast.LENGTH_SHORT).show();

        } else {

        }
    }


    private BufferedReader reader = null;

    private String downloadData(String url) {
        HttpURLConnection con = Connector.connection(url);
        if (con == null) {
            return "Internetni tekshiring!";
        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null && ServisReceiver.isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
//                        klent_id = jsonObj.getString("Id");
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    xatolikar = xatolikar + "\n" + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return "Internetni tekshiring!" + "\n" + xatolikar;
    }
}
