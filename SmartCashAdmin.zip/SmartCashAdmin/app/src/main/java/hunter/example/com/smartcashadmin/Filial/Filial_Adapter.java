package hunter.example.com.smartcashadmin.Filial;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import hunter.example.com.smartcashadmin.Klent.Klent_adapter;
import hunter.example.com.smartcashadmin.Klent.Klent_list;
import hunter.example.com.smartcashadmin.R;

/**
 * Created by Hunter on 16.09.2018.
 */

public class Filial_Adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Filial_list> filial_lists;

    public Filial_Adapter(Context context, ArrayList<Filial_list> filial_lists) {
        this.context = context;
        this.filial_lists = filial_lists;
    }

    @Override
    public int getCount() {
        return filial_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return filial_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        TextView txt_Id,txt_Num,txt_filial,txt_xudud,txt_login,txt_parol,txt_oshxona;

    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        Filial_list filialList=filial_lists.get(position);
        Filial_Adapter.ViewHolder holder=new Filial_Adapter.ViewHolder();
        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.filial_item,null);

            holder.txt_Id=row.findViewById(R.id.txt_filial_Id);
            holder.txt_Num=row.findViewById(R.id.txt_filial_Num);
            holder.txt_oshxona=row.findViewById(R.id.txt_filial_OshxonaNomi);

            holder.txt_filial=row.findViewById(R.id.txt_filial_Nomi);
            holder.txt_login=row.findViewById(R.id.txt_filial_login);
            holder.txt_parol=row.findViewById(R.id.txt_filial_parol);

            row.setTag(holder);
        }else {
            holder=(Filial_Adapter.ViewHolder)row.getTag();
        }

        holder.txt_Id.setText(filialList.getId());
        holder.txt_Num.setText(filialList.getNum());
        holder.txt_oshxona.setText(filialList.getOshxona());
        holder.txt_filial.setText(filialList.getFilial());
        holder.txt_login.setText(filialList.getLogin());
        holder.txt_parol.setText(filialList.getParol());
//         String cond=klentList.getHolat();
//         if (cond.equals("1")){
//             holder.view_holat.setBackgroundColor(Color.GREEN);
//         }else if (cond.equals("0")){
//             holder.view_holat.setBackgroundColor(Color.RED);
//
//         }
        return row;

    }
}
