package hunter.example.com.smartcashadmin.Klent;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.system.Os;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;

import hunter.example.com.smartcashadmin.Brodcast.ServisReceiver;
import hunter.example.com.smartcashadmin.mMySql.Connector;

import static hunter.example.com.smartcashadmin.MainActivity.url_address;

public class Jonatuvchi extends AsyncTask<Void, Void, String> {

    Activity context;
    String urlAddress;
    ProgressDialog dialog;
    String Oshxona, klent, tel_Num, login, parol;

    public Jonatuvchi(Activity context, String urlAddress) {
        this.context = context;
        this.urlAddress = urlAddress;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog = new ProgressDialog(context);
        dialog.setTitle("Jo'natilmoqda");
        dialog.setMessage("Iltimos kuting jo'natilmoqda!");
        dialog.show();

        Oshxona = Klent_qoshish.edt_klent_Oshxona.getText().toString();
        klent = Klent_qoshish.edt_klent_Fio.getText().toString();
        tel_Num = Klent_qoshish.edt_klent_Tel.getText().toString();
        login = Klent_qoshish.edt_klent_Login.getText().toString();
        parol = Klent_qoshish.edt_klent_Parol.getText().toString();

    }

    @Override
    protected String doInBackground(Void... voids) {
        String url_klent = "";
        String klentIDD, filialIDD;
        try {
            url_klent = url_address + "Insert_Klent.php?Klent_ismi=" + URLEncoder.encode(klent, "UTF-8") +
                    "&Klent_tel=" + URLEncoder.encode(tel_Num, "UTF-8")
                    + "&Oshxona_nomi=" + URLEncoder.encode(Oshxona, "UTF-8")
                    + "&login=" + URLEncoder.encode(login, "UTF-8")
                    + "&parol=" + URLEncoder.encode(parol, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String qiymar = downloadData(url_klent);
        if (qiymar.equals("ok")) {

            return "ok";

        }
        return "";
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        dialog.dismiss();
        if (s.equals("ok")) {
            //
            Toast.makeText(context, "Muvaffaqqiyatli jo'natildi!", Toast.LENGTH_SHORT).show();
        } else if (s.equals("no")) {
            Toast.makeText(context, "Jo`natishda hatolik bo`ldi", Toast.LENGTH_SHORT).show();

        } else {

        }
    }


    private BufferedReader reader = null;

    private String downloadData(String url) {
        HttpURLConnection con = Connector.connection(url);
        if (con == null) {
            return "Internetni tekshiring!";
        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null && ServisReceiver.isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
//                        klent_id = jsonObj.getString("Id");
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            xatolikar = xatolikar + "\n" + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    xatolikar = xatolikar + "\n" + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return "Internetni tekshiring!" + "\n" + xatolikar;
    }
}
