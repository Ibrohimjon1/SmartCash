package hunter.example.com.smartcashadmin.Filial;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

import hunter.example.com.smartcashadmin.Klent.Klent_Oluvchi;
import hunter.example.com.smartcashadmin.Klent.Klent_oyna;
import hunter.example.com.smartcashadmin.R;

public class Filial_royhat extends AppCompatActivity {
    ImageButton imBtn_add;
    static ArrayList<Filial_list> filial_lists= new ArrayList<>();
    static Filial_Adapter adapter;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filial_royhat);
        imBtn_add=(ImageButton)findViewById(R.id.btn_filial_add);
        lv=(ListView)findViewById(R.id.listviewFilial);

       adapter=new Filial_Adapter(Filial_royhat.this,filial_lists);
       lv.setAdapter(adapter);
       GetFilialData();

        imBtn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Filial_royhat.this,Filial_qoshish.class);
                startActivity(intent);
            }
        });
    }

    public void GetFilialData() {
        Filial_Oluvchi filial_oluvchi= new Filial_Oluvchi(Filial_royhat.this,filial_lists,adapter);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            filial_oluvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            filial_oluvchi.execute();
        }
//        }
    }
}
