package hunter.example.com.smartcashadmin.Generatsiya;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import hunter.example.com.smartcashadmin.R;

/**
 * Created by Hunter on 13.09.2018.
 */

public class Gen_oyna_Adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Gen_list> genLists;

    public Gen_oyna_Adapter(Context context, ArrayList<Gen_list> genLists) {
        this.context = context;
        this.genLists = genLists;
    }

    @Override
    public int getCount() {
        return genLists.size();
    }

    @Override
    public Object getItem(int position) {
        return genLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        TextView txt_Id,txt_Sana,txt_GenKey,txt_Imei,txt_gen_oyna_item_num;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        Gen_list gen_list=genLists.get(position);
        ViewHolder holder=new ViewHolder();

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            row=inflater.inflate(R.layout.gen_item,null);
            holder.txt_Id=row.findViewById(R.id.txt_gen_oyna_item_Id);
            holder.txt_Sana=row.findViewById(R.id.txt_gen_oyna_item_Sana);
            holder.txt_GenKey=row.findViewById(R.id.txt_gen_oyna_item_GenKey);
            holder.txt_Imei=row.findViewById(R.id.txt_gen_oyna_item_IMEI);
            holder.txt_gen_oyna_item_num=row.findViewById(R.id.txt_gen_oyna_item_num);

            row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
        holder.txt_Id.setText(gen_list.getId());
        holder.txt_Sana.setText(gen_list.getSana());
        holder.txt_GenKey.setText(gen_list.getGen_Key());
        holder.txt_Imei.setText(gen_list.getImei());
        holder.txt_gen_oyna_item_num.setText(gen_list.getNum());

        return row;
    }
}
