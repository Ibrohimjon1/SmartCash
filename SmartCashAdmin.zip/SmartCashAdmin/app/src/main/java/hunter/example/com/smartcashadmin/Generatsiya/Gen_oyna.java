package hunter.example.com.smartcashadmin.Generatsiya;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import hunter.example.com.smartcashadmin.MainActivity;
import hunter.example.com.smartcashadmin.R;

public class Gen_oyna extends AppCompatActivity {
    static ArrayList<Gen_list> gen_lists= new ArrayList<>();
    static Gen_oyna_Adapter genOynaAdapter;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gen_oyna);
        lv=(ListView)findViewById(R.id.listview);

         genOynaAdapter=new Gen_oyna_Adapter(Gen_oyna.this,gen_lists);
        lv.setAdapter(genOynaAdapter);
        getGen();

           }

      public void getGen(){
          Cursor cursor= MainActivity.SQLITE_HELPER.getData("SELECT  * FROM GENERATSIYA");
          int p=0;
          if (cursor.getCount()!=0){
              gen_lists.clear();
              cursor.moveToFirst();
              do {
                 p++;
                 String id=cursor.getString(1);
                 String sana=cursor.getString(2);
                 String gen_key=cursor.getString(3);
                 String imei=cursor.getString(4);
                  gen_lists.add(new Gen_list(id,sana,gen_key,imei,String.valueOf(p)));

              }while (cursor.moveToNext());
                genOynaAdapter.notifyDataSetChanged();
          }else {
              gen_lists.clear();
              genOynaAdapter.notifyDataSetChanged();
          }
      }
}
