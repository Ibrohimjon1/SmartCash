package hunter.example.com.smartcashadmin.Filial;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.util.ArrayList;

import hunter.example.com.smartcashadmin.Klent.Klent_qoshish;
import hunter.example.com.smartcashadmin.R;
import hunter.example.com.smartcashadmin.mMySql.Connector;

import static hunter.example.com.smartcashadmin.Brodcast.ServisReceiver.isOnline;
import static hunter.example.com.smartcashadmin.MainActivity.url_address;

public class Filial_qoshish extends AppCompatActivity {
    EditText edt_Parol, edt_Login, edt_Filial;
    Button btn_Filial_Chiqish, btn_Filial_Saqlash;
    Spinner spinner_Xudud, spinner_Oshxona;
    ArrayList<String> oshxona_Nomi = new ArrayList<String>();
    ArrayList<String> oshxona_ID = new ArrayList<String>();
    ArrayList<String> viloyat_Nomi = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filial_qoshish);
        spinner_Oshxona = (Spinner) findViewById(R.id.spinner_filial_Oshxona);
        spinner_Xudud = (Spinner) findViewById(R.id.spinner_filial_Xudud);
        btn_Filial_Saqlash = (Button) findViewById(R.id.btn_Filial_qoshish_Saqlash);
        btn_Filial_Chiqish = (Button) findViewById(R.id.btn_Filial_qoshish_Chiqish);

        edt_Parol = (EditText) findViewById(R.id.edt_filial_Parol);
        edt_Login = (EditText) findViewById(R.id.edt_filial_Login);
        edt_Filial = (EditText) findViewById(R.id.edt_filial_Filial);
        loadSpinnerData();
        GetKlentToSpinner();

        btn_Filial_Chiqish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_Filial_Saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = spinner_Oshxona.getSelectedItemPosition();
                String oshxonaId = oshxona_ID.get(index);
                String filal = edt_Filial.getText().toString().replace("'", "`");
                String xudud = spinner_Xudud.getSelectedItem().toString();
                String login = edt_Login.getText().toString().replace("'", "`");
                String parol = edt_Parol.getText().toString().replace("'", "`");
                if (!oshxonaId.equals("") && !filal.equals("")&&
               !xudud.equals("") && !login.equals("") && !parol.equals("")){

                    String url_klent = "";
                    try {
                        url_klent = url_address + "Insert_Filial.php?Nomi=" + URLEncoder.encode(filal, "UTF-8") +
                                "&Xudud=" + URLEncoder.encode(xudud, "UTF-8")
                                + "&Klent_id=" + URLEncoder.encode(oshxonaId, "UTF-8")
                                + "&login=" + URLEncoder.encode(login, "UTF-8")
                                + "&parol=" + URLEncoder.encode(parol, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    TaskniTekshir(url_klent);
                }else {
                    Toast.makeText(Filial_qoshish.this,"Ma`lumotni to`liq kiriting",Toast.LENGTH_LONG).show();

                }

            }
        });
    }

    public void TaskniTekshir(String url) {
        Filial_Jonatuvchi filial_jonatuvchi = new Filial_Jonatuvchi(Filial_qoshish.this, url);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            filial_jonatuvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            filial_jonatuvchi.execute();
        }

    }

    public void GetKlentToSpinner() {
        Klent_Info_Oluvchi klent_info_oluvchi = new Klent_Info_Oluvchi();
        klent_info_oluvchi.execute();
    }

    private void loadSpinnerData() {

        viloyat_Nomi.add("Andijon");
        viloyat_Nomi.add("Farg`ona");
        viloyat_Nomi.add("Namangan");
        viloyat_Nomi.add("Buxoro");
        viloyat_Nomi.add("Toshkent");
        viloyat_Nomi.add("Samarqand");
        viloyat_Nomi.add("Navoiy");
        viloyat_Nomi.add("Jizzax");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, R.layout.spinner_item, viloyat_Nomi);
        // attaching data adapter to spinner
        spinner_Xudud.setAdapter(dataAdapter);
        spinner_Xudud.setSelection(0);
    }

    private class Klent_Info_Oluvchi extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            String url_klent = "";

            url_klent = url_address + "/Download_KlentId.php";

            String qiymat = parseData(url_klent);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Filial_qoshish.this, R.layout.spinner_item, oshxona_Nomi);
            // attaching data adapter to spinner
            spinner_Oshxona.setAdapter(dataAdapter);
            // adapter.notifyDataSetChanged();
        }

        private String parseData(String url_adress) {
            HttpURLConnection con = Connector.connection(url_adress);
            if (con == null) {
                return "inteer";
            }
            InputStream inputStream = null;
            String xatolik = "";
            try {
                if (con != null && isOnline(Filial_qoshish.this)) {
                    inputStream = new BufferedInputStream(con.getInputStream());
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                    String resulr = reader.readLine();
                    if (resulr != null) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(resulr);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if (json != null) {
                            JSONObject object = null;
                            try {
                                object = json.getJSONObject("qiymat");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            boolean tugadi = true;
                            int sonlari = 0;

                            try {
                                sonlari = json.getInt("soni");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            oshxona_ID.clear();
                            oshxona_Nomi.clear();
                            for (int i = 1; i < sonlari; i++) {
                                JSONObject jsonObject = null;
                                try {
                                    jsonObject = object.getJSONObject("qiy_" + i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    tugadi = false;
                                }
                                if (tugadi) {
                                    String id = null;
                                    try {
                                        id = jsonObject.getString("id");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    if (id.equals("mal_yoq") || id == null) {
                                        tugadi = false;
                                        return "Ushbu sanada ma'lumotlar topilmadi!";
                                    }
                                    String oshxona_nomi = null;
                                    try {
                                        oshxona_nomi = jsonObject.getString("oshxona");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    oshxona_ID.add(id);
                                    oshxona_Nomi.add(oshxona_nomi);
                                } else {
                                    return "";
                                }
                            }
                            return "";
                        }
                    }
                    return "Ushbu sanada ma'lumotlar topilmadi!";
                }
            } catch (SocketException e) {
                e.printStackTrace();
                xatolik += "\n" + e.getMessage();
            } catch (SocketTimeoutException e) {
                e.printStackTrace();
                xatolik += "\n" + e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                xatolik += "\n" + e.getMessage();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        xatolik += "\n" + e.getMessage();
                    }
                }
                if (con != null) {
                    con.disconnect();
                }
            }
            return "" + "\n" + xatolik;
        }
    }
}
