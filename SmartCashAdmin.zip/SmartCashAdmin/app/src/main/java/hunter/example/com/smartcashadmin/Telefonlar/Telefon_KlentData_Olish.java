package hunter.example.com.smartcashadmin.Telefonlar;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;

import hunter.example.com.smartcashadmin.R;
import hunter.example.com.smartcashadmin.mMySql.Connector;

import static hunter.example.com.smartcashadmin.MainActivity.url_address;

/**
 * Created by Hunter on 16.09.2018.
 */

public class Telefon_KlentData_Olish  extends AsyncTask<Void, Void, Void> {

    Context context;
    String data;

    public Telefon_KlentData_Olish(Context context, String data) {
        this.context = context;
        this.data = data;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        String url_klent = "";

        try {
            url_klent = url_address + "Download_FilialId.php?id="+ URLEncoder.encode(data, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        ;

        String qiymat = parseData(url_klent);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, R.layout.spinner_item,Telefon_Oyna.filial_Nomi);
        Telefon_Oyna.spinner_Filial.setAdapter(dataAdapter);

        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(context, R.layout.spinner_item,Telefon_Oyna.viloyat_Nomi);
        Telefon_Oyna.spinner_Xudud.setAdapter(dataAdapter2);
    }

    private String parseData(String url_adress) {

        HttpURLConnection con = Connector.connection(url_adress);
        if (con == null) {
            return "inteer";
        }
        InputStream inputStream = null;
        String xatolik = "";
        try {
            if (con != null) {
                inputStream = new BufferedInputStream(con.getInputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String resulr = reader.readLine();
                if (resulr != null) {
                    JSONObject json = null;
                    try {
                        json = new JSONObject(resulr);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (json != null) {
                        JSONObject object = null;
                        try {
                            object = json.getJSONObject("qiymat");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        boolean tugadi = true;
                        int sonlari = 0;

                        try {
                            sonlari = json.getInt("soni");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        Telefon_Oyna.filial_ID.clear();
                        Telefon_Oyna.filial_Nomi.clear();
                        Telefon_Oyna.viloyat_Nomi.clear();
                        for (int i = 1; i < sonlari; i++) {
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = object.getJSONObject("qiy_" + i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                tugadi = false;
                            }
                            if (tugadi) {
                                String id = null;
                                try {
                                    id = jsonObject.getString("id");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                if (id.equals("mal_yoq") || id == null) {
                                    tugadi = false;
                                    return "Ushbu sanada ma'lumotlar topilmadi!";
                                }
                                String Filial_nomi = null;
                                try {
                                    Filial_nomi = jsonObject.getString("filial");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                String Hudud_nomi = null;
                                try {
                                    Hudud_nomi = jsonObject.getString("hudud");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                Telefon_Oyna.filial_ID.add(id);
                                Telefon_Oyna.filial_Nomi.add(Filial_nomi);
                                Telefon_Oyna.viloyat_Nomi.add(Hudud_nomi);
                            } else {
                                return "";
                            }
                        }
                        return "";
                    }
                }
                return "Ushbu sanada ma'lumotlar topilmadi!";
            }
        } catch (SocketException e) {
            e.printStackTrace();
            xatolik += "\n" + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            xatolik += "\n" + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            xatolik += "\n" + e.getMessage();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    xatolik += "\n" + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return "" + "\n" + xatolik;
    }
}