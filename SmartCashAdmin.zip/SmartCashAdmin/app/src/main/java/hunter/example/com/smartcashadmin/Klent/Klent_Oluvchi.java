package hunter.example.com.smartcashadmin.Klent;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.widget.ListView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.util.ArrayList;

import hunter.example.com.smartcashadmin.MainActivity;
import hunter.example.com.smartcashadmin.R;
import hunter.example.com.smartcashadmin.mMySql.Connector;

import static hunter.example.com.smartcashadmin.Brodcast.ServisReceiver.isOnline;
import static hunter.example.com.smartcashadmin.MainActivity.url_address;

/**
 * Created by Hunter on 15.09.2018.
 */

public class Klent_Oluvchi extends AsyncTask<Void, Void, Void> {

    Context context;
    String vaqt;
    ArrayList<Klent_list> tarix_list;
    Klent_adapter adapter;

    public Klent_Oluvchi(Context context, String url_adress, ArrayList<Klent_list> tarix_list, Klent_adapter adapter) {
        this.context = context;
        this.vaqt = url_adress;
        this.tarix_list = tarix_list;
        this.adapter = adapter;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        String url_klent = "";
        if (vaqt.equals("all")) {

            url_klent = url_address+"/Download_KlentAll.php";

        } else {
        }
        String qiymat = parseData(url_klent);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        adapter.notifyDataSetChanged();
    }

    private String parseData(String url_adress) {
        HttpURLConnection con = Connector.connection(url_adress);
        if (con == null) {
            return "inteer";
        }
        InputStream inputStream = null;
        String xatolik = "";
        try {
            if (con != null && isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String resulr = reader.readLine();
                if (resulr != null) {
                    JSONObject json = null;
                    try {
                        json = new JSONObject(resulr);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (json != null) {
                        JSONObject object = null;
                        try {
                            object = json.getJSONObject("qiymat");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        boolean tugadi = true;
                        int sonlari = 0;

                        try {
                            sonlari = json.getInt("soni");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        int p=0;
                        tarix_list.clear();
                        for (int i = 1; i < sonlari; i++) {
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = object.getJSONObject("qiy_" + i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                tugadi = false;
                            }
                            if (tugadi) {
                                String id = null;
                                try {
                                    id = jsonObject.getString("id");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                if (id.equals("mal_yoq") || id == null) {
                                    tugadi = false;
                                    return "Ushbu sanada ma'lumotlar topilmadi!";
                                }
                                String Klent_ismi = null;
                                try {
                                    Klent_ismi = jsonObject.getString("fio");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                String Klent_tel = null;
                                try {
                                    Klent_tel = jsonObject.getString("klent_tel");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                String Oshxona_nomi = null;
                                try {
                                    Oshxona_nomi = jsonObject.getString("oshxona");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                p++;
//                                MainActivity.SQLITE_HELPER.queryData("INSERT INOT KLENT(Klent_id,Klent_ismi,Klent_tel,Oshxona) VALUES ('"+id+"','"+Klent_ismi+"','"+Klent_tel+"','"+Oshxona_nomi+"')");
                                tarix_list.add(new Klent_list(id,String.valueOf(p),Oshxona_nomi,Klent_ismi,Klent_tel));
                         //       tarix_list.add(new Klent_list(ismi, vaqti, muddati, summasi, holati));
                            } else {
                                return "";
                            }
                        }
                        return "";
                    }
                }
                return "Ushbu sanada ma'lumotlar topilmadi!";
            }
        } catch (SocketException e) {
            e.printStackTrace();
            xatolik += "\n" + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            xatolik += "\n" + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            xatolik += "\n" + e.getMessage();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    xatolik += "\n" + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return "" + "\n" + xatolik;
    }
}
