package com.tokopedia.showcase;

public interface ShowCaseListener {
    void onPrevious();
    void onNext();

    void onComplete();
}
