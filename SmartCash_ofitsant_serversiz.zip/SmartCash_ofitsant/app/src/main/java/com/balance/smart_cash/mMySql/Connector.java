package com.balance.smart_cash.mMySql;

import com.balance.smart_cash.Login.Login_oyna;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Connector {

    public static HttpURLConnection connection(String urlAdres) {
        try {
            URL url = new URL(urlAdres);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(15000);
            con.setReadTimeout(15000);
            con.setDoInput(true);
//            con.setDoOutput(true);
//            con.connect();
            return con;
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
        } catch (IOException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
        }
        return null;
    }
}
