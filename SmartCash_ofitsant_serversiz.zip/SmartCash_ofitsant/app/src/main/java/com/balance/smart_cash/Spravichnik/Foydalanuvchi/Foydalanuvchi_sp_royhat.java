package com.balance.smart_cash.Spravichnik.Foydalanuvchi;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.smart_cash.Admin.Admin_sp_royhat.Admin_Sp_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 25.08.2018.
 */

public class Foydalanuvchi_sp_royhat extends Fragment {
    private View parent_view;
    ListView lv;
    static ArrayList<Foydalanuvchi_sp_list> sp_lists = new ArrayList<>();
    static Foydalanuvchi_sp_adapter Foy_adpter;
    static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.foydalanuvchi_sp_royat, container, false);

        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setVisibility(View.VISIBLE);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String f_id = "";
                Intent intent = new Intent(getContext(), Foydalanuvchi_sp_oyna.class);
                intent.putExtra("SESSION_ID", f_id);
                startActivity(intent);
            }
        });

        init();
        return parent_view;
    }

    public void init() {
        lv = (ListView) parent_view.findViewById(R.id.foydalnuvchi_list);

        Foy_adpter = new Foydalanuvchi_sp_adapter(getContext(), sp_lists);
        lv.setAdapter(Foy_adpter);
        GetData_Foydalanuvchi();

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
//                TextView idd=(TextView)view.findViewById(R.id.foydalan_sp_royhat_item_Id);
//                String f_id=idd.getText().toString();
//                Intent intent = new Intent(getContext(),Foydalanuvchi_sp_oyna.class);
//                intent.putExtra("SESSION_ID", f_id);
//                startActivity(intent);

                final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
                dialog.setContentView(R.layout.alertdialog_oyna);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.setTitle(getString(R.string.o_zgartirish));
                Button btn_change = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ozgartir);
                Button btn_delet = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ochir);

                btn_change.setText(R.string.o_zgartirish);
                btn_delet.setText(R.string.o_chirish);

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextView idd = (TextView) view.findViewById(R.id.foydalan_sp_royhat_item_Id);
                        String f_id = idd.getText().toString();
                        Intent intent = new Intent(getContext(), Foydalanuvchi_sp_oyna.class);
                        intent.putExtra("SESSION_ID", f_id);
                        startActivity(intent);
                        dialog.dismiss();


                    }
                });

                btn_delet.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        TextView idd = (TextView) view.findViewById(R.id.foydalan_sp_royhat_item_Id);
                        String f_id = idd.getText().toString();
                        Login_oyna.SQLITE_HELPER.deleteData("DELETE FROM FOYDALANUVCHI WHERE Id='" + f_id + "'");
                        GetData_Foydalanuvchi();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
    }


    public static void GetData_Foydalanuvchi() {
        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM FOYDALANUVCHI");
        int p = 0;
        if (cursor_2.getCount() != 0) {
            layout_ofit_mal_yoq.setVisibility(View.GONE);
            sp_lists.clear();
            cursor_2.moveToFirst();
            do {
                p++;
                String id = cursor_2.getString(0);
                String ismi = cursor_2.getString(1);
                String dostp = cursor_2.getString(2);
                String parol = cursor_2.getString(3);
                String num = String.valueOf(p);
                sp_lists.add(new Foydalanuvchi_sp_list(id, num, ismi, parol));

            } while (cursor_2.moveToNext());
            Foy_adpter.notifyDataSetChanged();

        } else {
            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            sp_lists.clear();
            Foy_adpter.notifyDataSetChanged();
        }

    }
}
