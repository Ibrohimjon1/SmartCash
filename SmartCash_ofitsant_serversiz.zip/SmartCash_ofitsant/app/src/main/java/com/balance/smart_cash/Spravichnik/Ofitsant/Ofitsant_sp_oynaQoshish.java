package com.balance.smart_cash.Spravichnik.Ofitsant;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Ofitsant_sp_oynaQoshish extends AppCompatActivity {
    Button btn_ofitsant_oynaQoshish_saqlash, btn_ofitsant_oynaQoshish_ortga;
    ImageView ofitsant_sp_img;
    private static int RESULT_LOAD_IMAGE = 1;
    EditText edt_ofitsant_sp_FIO, edt_ofitsant_sp_foizi, edt_parol;
    String sessionId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ofitsant_sp_oyna);
        init();

        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        btn_ofitsant_oynaQoshish_saqlash = (Button) findViewById(R.id.btn_ofitsant_oynaQoshish_saqlash);
        btn_ofitsant_oynaQoshish_ortga = (Button) findViewById(R.id.btn_ofitsant_oynaQoshish_ortga);
        ofitsant_sp_img = (ImageView) findViewById(R.id.ofitsant_sp_img);
        edt_ofitsant_sp_FIO = (EditText) findViewById(R.id.edt_ofitsant_sp_FIO);
        edt_ofitsant_sp_foizi = (EditText) findViewById(R.id.edt_ofitsant_sp_foizi);
        edt_parol = (EditText) findViewById(R.id.edt_foydalnuvchi_Oyna_parol);

        btn_ofitsant_oynaQoshish_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_ofitsant_oynaQoshish_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Fio = edt_ofitsant_sp_FIO.getText().toString().trim();
                String foizi = edt_ofitsant_sp_foizi.getText().toString().trim();
                String parol = edt_parol.getText().toString();

                if (!Fio.equals("")) {
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM OFITSANT WHERE paroli = '" + parol + "'");
                    if (cursor.getCount() != 0) {
                        Toast.makeText(getApplicationContext(), R.string.parol_bor, Toast.LENGTH_SHORT).show();
                    } else {
                        if (!sessionId.equals("")) {

                            Login_oyna.SQLITE_HELPER.queryData("UPDATE OFITSANT SET ismi = '" + Fio + "', foiz = '" + foizi + "', paroli = '" + parol + "' WHERE Id='" + sessionId + "'");
                            finish();
                            Ofitsant_sp_royhat.GetData_Ofitsant();
                        } else {
                            String sql = "INSERT INTO OFITSANT VALUES (NULL, ?, ?, ?)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_3ta(Fio, foizi, parol, sql);
                            finish();
                            Ofitsant_sp_royhat.GetData_Ofitsant();
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM OFITSANT WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edt_ofitsant_sp_FIO.setText(cursor_2.getString(1));
            edt_ofitsant_sp_foizi.setText(cursor_2.getString(2));
            edt_parol.setText(cursor_2.getString(3));


        }
    }

}