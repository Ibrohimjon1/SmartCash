package com.balance.smart_cash.Otmenalar;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Otmen_list {
    String Buyurtma_sana;
    String Otmen_sana;
    String Stol;
    String Shot;
    String Son;
    String Taom;
    String num;
    String ofit;

    public Otmen_list(String buyurtma_sana, String otmen_sana, String stol, String shot, String son, String taom, String num, String ofit) {
        Buyurtma_sana = buyurtma_sana;
        Otmen_sana = otmen_sana;
        Stol = stol;
        Shot = shot;
        Son = son;
        Taom = taom;
        this.num = num;
        this.ofit = ofit;
    }

    public String getBuyurtma_sana() {
        return Buyurtma_sana;
    }

    public void setBuyurtma_sana(String buyurtma_sana) {
        Buyurtma_sana = buyurtma_sana;
    }

    public String getOtmen_sana() {
        return Otmen_sana;
    }

    public void setOtmen_sana(String otmen_sana) {
        Otmen_sana = otmen_sana;
    }

    public String getStol() {
        return Stol;
    }

    public void setStol(String stol) {
        Stol = stol;
    }

    public String getShot() {
        return Shot;
    }

    public void setShot(String shot) {
        Shot = shot;
    }

    public String getSon() {
        return Son;
    }

    public void setSon(String son) {
        Son = son;
    }

    public String getTaom() {
        return Taom;
    }

    public void setTaom(String taom) {
        Taom = taom;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getOfit() {
        return ofit;
    }

    public void setOfit(String ofit) {
        this.ofit = ofit;
    }
}
