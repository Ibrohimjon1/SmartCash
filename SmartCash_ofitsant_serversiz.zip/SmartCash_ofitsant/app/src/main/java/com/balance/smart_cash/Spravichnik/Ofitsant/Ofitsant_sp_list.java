package com.balance.smart_cash.Spravichnik.Ofitsant;

/**
 * Created by Hunter on 26.08.2018.
 */

public class Ofitsant_sp_list {
    String id;
    String num;
    String fio;
    String foiz;
    String parol;

    public Ofitsant_sp_list(String id, String num, String fio, String foiz, String parol) {
        this.id = id;
        this.num = num;
        this.fio = fio;
        this.foiz = foiz;
        this.parol = parol;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public String getFoiz() {
        return foiz;
    }

    public void setFoiz(String foiz) {
        this.foiz = foiz;
    }

    public String getParol() {
        return parol;
    }

    public void setParol(String parol) {
        this.parol = parol;
    }
}
