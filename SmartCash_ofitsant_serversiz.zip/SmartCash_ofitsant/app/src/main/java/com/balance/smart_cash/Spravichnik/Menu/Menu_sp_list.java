package com.balance.smart_cash.Spravichnik.Menu;

/**
 * Created by Hunter on 26.08.2018.
 */

public class Menu_sp_list {
    String Id;
    String Num;
    String Nomi;
    String Bolim;
    byte[] Rasm;


    public Menu_sp_list(String id, String num, String nomi, String bolim, byte[] rasm) {
        Id = id;
        Num = num;
        Nomi = nomi;
        Bolim = bolim;
        Rasm = rasm;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getNum() {
        return Num;
    }

    public void setNum(String num) {
        Num = num;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }

    public String getBolim() {
        return Bolim;
    }

    public void setBolim(String bolim) {
        Bolim = bolim;
    }

    public byte[] getRasm() {
        return Rasm;
    }

    public void setRasm(byte[] rasm) {
        Rasm = rasm;
    }
}
