package com.balance.smart_cash.Broadcast;

/**
 * Created by Ibrohimjon on 11.09.2018.
 */

import android.app.Activity;
import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Security.Security_screen;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Tekshiruvchi extends Service {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    public void onCreate() {
        super.onCreate();

//        Intent notificationIntent = new Intent(this, Login_oyna.class);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
//
//        Notification notification = new NotificationCompat.Builder(this)
//                .setSmallIcon(R.mipmap.ic_launcher)
//                .setContentTitle("Smart Cash")
//                .setContentText(getString(R.string.dastur_ishga_tushir_uchun_bosing))
//                .setContentIntent(pendingIntent).build();
//
//        startForeground(1337, notification);

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (ForegroundEnablingService.instance == null)
            throw new RuntimeException(ForegroundEnablingService.class.getSimpleName() + " not running");

        //Set both services to foreground using the same notification id, resulting in just one notification
        startForeground(ForegroundEnablingService.instance);
        startForeground(this);

        //Cancel this service's notification, resulting in zero notifications
        stopForeground(true);

        //Stop this service so we don't waste RAM.
        //Must only be called *after* doing the work or the notification won't be hidden.
        stopSelf();


        sharedPreferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        Functsiya(this);
        return Service.START_NOT_STICKY;
    }

    private static final int NOTIFICATION_ID = 1337;

    private static void startForeground(Service service) {
        Notification notification = new Notification.Builder(service).getNotification();
        service.startForeground(NOTIFICATION_ID, notification);
    }


    public void Mal_saqlash_str(String key, String qiymat) {
        editor.putString(key, qiymat);
        editor.commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }


    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    public void Functsiya(final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    String klent_id = sharedPreferences.getString("klent_id", "");
                    String url = "";
                    try {
                        url = Security_screen.url_address + Urllar.Tekshit_holat + ".php?klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    if (Security_screen.isOnline(context)) {
                        downloadData(context, url);
                    }
                    try {
                        Thread.sleep(30000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

    }

    private BufferedReader reader = null;
    private String Holat = "0";

    private String downloadData(Context context, String url) {
        HttpURLConnection con = Connector.connection(url);
        if (con == null) {
            return "Internetni tekshiring!";
        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
                        Holat = jsonObj.getString("holati");
                        String muddatlimi = jsonObj.getString("muddatlimi");
                        String muddat_vaqti = jsonObj.getString("muddat_vaqti");
                        Mal_saqlash_str("muddatlimi", muddatlimi);
                        Mal_saqlash_str("holati", Holat);
                        Mal_saqlash_str("muddat_vaqti", muddat_vaqti);
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    xatolikar = xatolikar + " // " + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return "Internetni tekshiring!" + "  " + xatolikar;
    }
}