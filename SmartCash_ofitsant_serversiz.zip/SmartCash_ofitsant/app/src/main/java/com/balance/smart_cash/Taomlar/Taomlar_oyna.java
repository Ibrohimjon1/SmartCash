package com.balance.smart_cash.Taomlar;

import android.app.Activity;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Menu.Menu_oyna;
import com.balance.smart_cash.Otdel.Otdel_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Umumiy.Umumiy_oyna;

import java.util.ArrayList;

public class Taomlar_oyna extends Fragment {

    GridView gridView;
    ArrayList<Taom_list> otdel_list = new ArrayList<>();
    private View parentView;
    String otdel_id, menu_id;
    Button btn_otdel, btn_menu, btn_taom;
    Taom_adapter adapter;
    FragmentTransaction fragment;
    TextView txt_taom_oyna_mal_yoq;
    View layout_taom_oyna_mal_yoq;
    SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.taomlar_oyna, container, false);

        Bundle bundle = this.getArguments();
        if (bundle != null) {
            otdel_id = bundle.getString("otdel");
            if (Umumiy_oyna.OTDEL_BORMI != 0) {
                if (!otdel_id.equals("yulduz")) {
                    menu_id = bundle.getString("menu");
                }
            } else {
                if (Umumiy_oyna.MENU_BORMI == 1) {
                    menu_id = bundle.getString("menu");
                } else {
                    menu_id = "";
                }
            }
        }
        Setup();
        if (otdel_id != null) {
            if (otdel_id.equals("yulduz")) {
                String sql = "";
                if (Umumiy_oyna.OTDEL_BORMI == -1) {
                    sql = "SELECT * FROM TAOMLAR WHERE populyar = 1";
                } else if (Umumiy_oyna.OTDEL_BORMI != 0) {
                    sql = "SELECT * FROM TAOMLAR WHERE populyar = 1 AND otdel_id = '" + Umumiy_oyna.OTDEL_BORMI + "'";
                } else {
                    sql = "SELECT * FROM TAOMLAR WHERE populyar = 1";
                }
                Get_taom(sql);
            } else {
                String sql = null;
                if (Umumiy_oyna.OTDEL_BORMI != 0) {
                    sql = "SELECT * FROM TAOMLAR WHERE otdel_id = '" + otdel_id + "' AND menu_id='" + menu_id + "'";
                } else if (Umumiy_oyna.MENU_BORMI == 1) {
                    sql = "SELECT * FROM TAOMLAR WHERE menu_id='" + menu_id + "'";
                } else {
                    sql = "SELECT * FROM TAOMLAR";
                }
                Get_taom(sql);
            }
        }
        return parentView;
    }

    private void Setup() {

        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        btn_taom = (Button) getActivity().findViewById(R.id.btn_umum_taom);
        btn_menu = (Button) getActivity().findViewById(R.id.btn_umum_menu);
        btn_otdel = (Button) getActivity().findViewById(R.id.btn_umum_otdel);
        txt_taom_oyna_mal_yoq = (TextView) parentView.findViewById(R.id.txt_taom_oyna_mal_yoq);
        layout_taom_oyna_mal_yoq = parentView.findViewById(R.id.layout_taom_oyna_mal_yoq);
        if (Umumiy_oyna.OTDEL_BORMI != 0) {
            btn_otdel.setVisibility(View.VISIBLE);
            Umumiy_oyna.view_umum_oq.setVisibility(View.GONE);
        } else {
            btn_otdel.setVisibility(View.GONE);
            Umumiy_oyna.view_umum_oq.setVisibility(View.VISIBLE);
        }
        if (!otdel_id.equals("yulduz")) {
            if (Umumiy_oyna.MENU_BORMI == 1) {
                btn_menu.setVisibility(View.VISIBLE);
            } else {
                btn_menu.setVisibility(View.GONE);
            }
            btn_taom.setVisibility(View.VISIBLE);

        } else {
            if (Umumiy_oyna.OTDEL_BORMI == 0) {
                if (Umumiy_oyna.MENU_BORMI == 0) {
                    btn_menu.setVisibility(View.GONE);
                    btn_taom.setVisibility(View.VISIBLE);
                } else {
                    btn_menu.setVisibility(View.VISIBLE);
                    btn_taom.setVisibility(View.GONE);
                }
            } else {
                btn_menu.setVisibility(View.GONE);
                btn_taom.setVisibility(View.GONE);
            }

        }
        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Umumiy_oyna.OTDEL_BORMI == 0) {
                    changeFragment(new Menu_oyna(), "otdel", "");
                } else {
                    changeFragment(new Menu_oyna(), "otdel", otdel_id);
                }
            }
        });
        btn_taom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                changeFragment_2(new Taomlar_oyna());
            }
        });
        btn_otdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Otdel_oyna(), "", "");
            }
        });

        gridView = (GridView) parentView.findViewById(R.id.grid_view_taom);
        otdel_list.clear();

        int yulduz_bormi = sharedPreferences.getInt("yulduz_bormi", 1);

        adapter = new Taom_adapter(getContext(), otdel_list, yulduz_bormi);
        gridView.setAdapter(adapter);


    }

    public void Get_taom(String sql) {
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            otdel_list.clear();
            do {

                String id = cursor.getString(0);
                String nomi = cursor.getString(1);
                String narxi = cursor.getString(2);
                byte[] image = cursor.getBlob(5);
                String foizi = cursor.getString(6);
                int yulduz = cursor.getInt(7);
                String print = cursor.getString(8);

                otdel_list.add(new Taom_list(id, nomi, narxi, foizi, image, yulduz, print));
            } while (cursor.moveToNext());
            txt_taom_oyna_mal_yoq.setVisibility(View.GONE);
            layout_taom_oyna_mal_yoq.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        } else {
            if (otdel_id.equals("yulduz")) {
                txt_taom_oyna_mal_yoq.setText(R.string.populyar_tanlanmagan);
                txt_taom_oyna_mal_yoq.setVisibility(View.VISIBLE);
                layout_taom_oyna_mal_yoq.setVisibility(View.VISIBLE);
            } else {
                txt_taom_oyna_mal_yoq.setText(R.string.menuga_taom_kiritilmagan);
                txt_taom_oyna_mal_yoq.setVisibility(View.VISIBLE);
                layout_taom_oyna_mal_yoq.setVisibility(View.VISIBLE);
            }
            otdel_list.clear();
            adapter.notifyDataSetChanged();
        }
    }

    public void changeFragment_2(Fragment targetFragment) {
        Bundle bundle = new Bundle();
        if (Umumiy_oyna.OTDEL_BORMI == 0) {
            bundle.putString("otdel", "");
        } else {
            bundle.putString("otdel", otdel_id);
        }
        if (Umumiy_oyna.MENU_BORMI == 0) {
            bundle.putString("menu", "");
        } else {
            bundle.putString("menu", menu_id);
        }
        targetFragment.setArguments(bundle);

        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }

    public void changeFragment(Fragment targetFragment, String key, String id) {
        if (!key.equals("")) {
            Bundle bundle = new Bundle();
            bundle.putString(key, id + "");
            targetFragment.setArguments(bundle);
        }
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }
}
