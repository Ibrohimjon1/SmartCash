package com.balance.smart_cash.Spravichnik.Printer;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 28.08.2018.
 */

public class Printer_sp_QoshishOyna extends AppCompatActivity {
    Button btn_printer_oyna_qoshish, btn_printer_oyna_chiqish;
    EditText printerNomi, printerUrl;
    Spinner spinner;
    String sessionId;
    ArrayList<String> spiner_dostup = new ArrayList<String>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.printer_sp_oyna);
        init();

        spiner_dostup.clear();
        spiner_dostup.add("Pos 58");
        spiner_dostup.add("Pos 80");

        SetDataOnSpinner();
        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        spinner = (Spinner) findViewById(R.id.print_SP_spinner);
        btn_printer_oyna_qoshish = (Button) findViewById(R.id.btn_printer_oyna_qoshish);
        btn_printer_oyna_chiqish = (Button) findViewById(R.id.btn_printer_oyna_chiqish);
        printerNomi = (EditText) findViewById(R.id.edit_PrinterNomi);
        printerUrl = (EditText) findViewById(R.id.edit_PrinterUrl);
        btn_printer_oyna_chiqish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_printer_oyna_qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!printerNomi.getText().toString().equals("") && !printerUrl.getText().toString().equals("")) {

                    String tip = "" + spinner.getSelectedItemPosition();
                    if (!sessionId.equals("")) {
                        String sql = "UPDATE PRINTER SET nomi =?, url=?, tipi = ? WHERE Id='" + sessionId + "'";
                        String nomi = printerNomi.getText().toString().trim();
                        String url = printerUrl.getText().toString().trim();
                        Login_oyna.SQLITE_HELPER.Printer_qoshish(nomi, url,tip, sql);
                        printerNomi.setText("");
                        printerUrl.setText("");
                        Printer_sp_royhat.GetData_Printer();
                        finish();
                    } else {

                        String nomi = printerNomi.getText().toString().trim();
                        String url = printerUrl.getText().toString().trim();
                        String sql = "INSERT INTO PRINTER VALUES (NULL, ?, ?, ?, 0)";
                        Login_oyna.SQLITE_HELPER.Printer_qoshish(nomi, url,tip, sql);
                        printerUrl.setText("");
                        printerNomi.setText("");
                        Printer_sp_royhat.GetData_Printer();
                        finish();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

    public void SetDataOnSpinner() {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.spinner_item, spiner_dostup);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM PRINTER WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            printerNomi.setText(cursor_2.getString(1));
            printerUrl.setText(cursor_2.getString(2));
            String tip = cursor_2.getString(3);
            if (tip.equals("0")) {
                spinner.setSelection(0);
            } else if (tip.equals("1")) {
                spinner.setSelection(1);
            }


        }
    }
}