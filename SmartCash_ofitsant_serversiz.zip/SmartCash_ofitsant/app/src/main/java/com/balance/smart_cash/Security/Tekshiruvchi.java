package com.balance.smart_cash.Security;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Tekshiruvchi extends AsyncTask<Void, Void, String> {

    Activity context;
    String urlAddress;
    ProgressDialog dialog;

    public Tekshiruvchi(Activity context, String urlAddress) {
        this.context = context;
        this.urlAddress = urlAddress;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog = new ProgressDialog(context);
        dialog.setTitle(context.getString(R.string.tekshirilmoqda));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setMessage(context.getString(R.string.iltimos_tekshirilmoqda));
        dialog.show();

    }

    @Override
    protected String doInBackground(Void... voids) {

        return downloadData();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        dialog.dismiss();
        if (s.equals("ok")) {
            Mal_yozish();

            Intent intent = new Intent(context, Login_oyna.class);
            context.startActivity(intent);
            Security_screen.frameAnimation.stop();
            context.finish();
        } else if (s.equals("no")) {
            new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("")
                    .setContentText(context.getString(R.string.kalitingiz_notogri))
                    .show();
        } else {

            new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("")
                    .setContentText(s)
                    .show();
        }

    }

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")
    private void Mal_yozish() {
        preferences = context.getSharedPreferences("Holati", Activity.MODE_PRIVATE);
        editor = preferences.edit();

        Mal_saqlash("klent_id",tel_id);
        Mal_saqlash("filial_id", id);
        Mal_saqlash("holati", Holat);
        Mal_saqlash("muddatlimi", muddatlimi);
        Mal_saqlash("muddat_vaqti", muddat_vaqti);
    }

    public void Mal_saqlash(String kalit, String qiymat) {
        editor.putString(kalit, qiymat);
        editor.commit();
    }

    private String id = "";
    private String tel_id = "";
    private String Holat = "";
    private String muddatlimi = "";
    private String muddat_vaqti = "";

    private BufferedReader reader = null;

    private String downloadData() {
        HttpURLConnection con = Connector.connection(urlAddress);
        if (con == null) {
            return context.getString(R.string.internetni_tekshir);
        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null && Security_screen.isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
                        id = jsonObj.getString("id");
                        tel_id = jsonObj.getString("tel_id");
                        Holat = jsonObj.getString("Holat");
                        muddatlimi = jsonObj.getString("muddatlimi");
                        muddat_vaqti = jsonObj.getString("muddat_vaqti");
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + " // " + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    xatolikar = xatolikar + " // " + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return context.getString(R.string.internetni_tekshir) + "  " + xatolikar;
    }
}
