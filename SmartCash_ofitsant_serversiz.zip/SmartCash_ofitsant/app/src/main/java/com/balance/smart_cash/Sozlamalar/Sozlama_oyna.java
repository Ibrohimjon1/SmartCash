package com.balance.smart_cash.Sozlamalar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Sozlama_oyna extends AppCompatActivity {

    LinearLayout set_oshxona_nomi, set_tolov_print, set_taom_print, set_bekor_print, set_foiz, set_tolov_auto, set_auto_delete, set_ruchnoy_delete;

    Switch switch_ofitsant,switch_bonus, switch_stol, switch_yulduz, switch_otdel, switch_menu, switch_platik, switch_naqd, switch_kop, switch_kam, switch_ozgartir, switch_ochirish,
            switch_ochir_royh_korish, switch_tolov_korish, switch_pul_korish, switch_ofitsant_korish, switch_oldingi_korish, switch_sync;

    TextView txt_oshxona_nomi, txt_tolov_pechat, txt_taom_pechat, txt_bekor_pechat, txt_foiz, txt_auto_tolov, txt_auto_delete;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sozlama_oyna);

        sharedPreferences = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        set_oshxona_nomi = (LinearLayout) findViewById(R.id.set_oshxona_nomi);
        set_tolov_print = (LinearLayout) findViewById(R.id.set_tolov_printer);
        set_taom_print = (LinearLayout) findViewById(R.id.set_taom_printer);
        set_bekor_print = (LinearLayout) findViewById(R.id.set_bekor_printer);
        set_foiz = (LinearLayout) findViewById(R.id.set_foiz);
        set_tolov_auto = (LinearLayout) findViewById(R.id.set_tolov_auto);
        set_auto_delete = (LinearLayout) findViewById(R.id.set_auto_delete);
        set_ruchnoy_delete = (LinearLayout) findViewById(R.id.set_ruchnoy_delete);

        txt_tolov_pechat = (TextView) findViewById(R.id.txt_set_tolov_print);
        txt_taom_pechat = (TextView) findViewById(R.id.txt_set_taom_print);
        txt_bekor_pechat = (TextView) findViewById(R.id.txt_set_bekor_print);
        txt_foiz = (TextView) findViewById(R.id.txt_set_foiz);
        txt_auto_tolov = (TextView) findViewById(R.id.txt_set_auto_tolov);
        txt_auto_delete = (TextView) findViewById(R.id.txt_set_auto_delete);
        txt_oshxona_nomi = (TextView) findViewById(R.id.txt_set_oshxona_nomi);

        switch_ofitsant = (Switch) findViewById(R.id.switch_set_ofitsant);
        switch_bonus = (Switch) findViewById(R.id.switch_set_bonus);
        switch_stol = (Switch) findViewById(R.id.switch_set_stol);
        switch_yulduz = (Switch) findViewById(R.id.switch_set_yulduz);
        switch_otdel = (Switch) findViewById(R.id.switch_set_otdel);
        switch_menu = (Switch) findViewById(R.id.switch_set_menu);
        switch_platik = (Switch) findViewById(R.id.switch_set_plastik);
        switch_naqd = (Switch) findViewById(R.id.switch_set_naqd);
        switch_kop = (Switch) findViewById(R.id.switch_set_kop_tolov);
        switch_kam = (Switch) findViewById(R.id.switch_set_kam_tolov);
        switch_ozgartir = (Switch) findViewById(R.id.switch_set_ozgatirish_taom);
        switch_ochirish = (Switch) findViewById(R.id.switch_set_taom_ochirish);
        switch_ochir_royh_korish = (Switch) findViewById(R.id.switch_set_ochir_korish);
        switch_tolov_korish = (Switch) findViewById(R.id.switch_set_shot_korish);
        switch_pul_korish = (Switch) findViewById(R.id.switch_set_pul_hisob_korish);
        switch_ofitsant_korish = (Switch) findViewById(R.id.switch_set_ofitsant_korish);
        switch_oldingi_korish = (Switch) findViewById(R.id.switch_set_oldingi_korish);
        switch_sync = (Switch) findViewById(R.id.switch_set_sync);

        Mal_toldirish();

        switch_stol.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("stol_bormi", 1);
                } else {
                    Mal_saqlash("stol_bormi", 0);
                }
            }
        });

        switch_yulduz.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("yulduz_bormi", 1);
                } else {
                    Mal_saqlash("yulduz_bormi", 0);
                }
            }
        });

        switch_otdel.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("otdel_bormi", 1);
                } else {
                    Mal_saqlash("otdel_bormi", 0);
                }
            }
        });

        switch_menu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("menu_bormi", 1);
                } else {
                    Mal_saqlash("menu_bormi", 0);
                }
            }
        });

        switch_platik.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("plastik_tolov", 1);
                } else {
                    Mal_saqlash("plastik_tolov", 0);
                }
            }
        });
        switch_naqd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("naqd_tolov", 1);
                } else {
                    Mal_saqlash("naqd_tolov", 0);
                }
            }
        });

        switch_kop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("kop_tolov", 1);
                } else {
                    Mal_saqlash("kop_tolov", 0);
                }
            }
        });

        switch_kam.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("kam_tolov", 1);
                } else {
                    Mal_saqlash("kam_tolov", 0);
                }
            }
        });

        switch_ozgartir.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ozgartirish", 1);
                } else {
                    Mal_saqlash("ozgartirish", 0);
                }
            }
        });

        switch_ochirish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ochirish", 1);
                } else {
                    Mal_saqlash("ochirish", 0);
                }
            }
        });

        switch_ochir_royh_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ochir_royh_korish", 1);
                } else {
                    Mal_saqlash("ochir_royh_korish", 0);
                }
            }
        });

        switch_tolov_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("tolov_korish", 1);
                } else {
                    Mal_saqlash("tolov_korish", 0);
                }
            }
        });
        switch_pul_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("pul_korish", 1);
                } else {
                    Mal_saqlash("pul_korish", 0);
                }
            }
        });

        switch_ofitsant_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ofitsant_korish", 1);
                } else {
                    Mal_saqlash("ofitsant_korish", 0);
                }
            }
        });
        switch_oldingi_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("oldingi_korish", 1);
                } else {
                    Mal_saqlash("oldingi_korish", 0);
                }
            }
        });
        switch_sync.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("sync_bormi", 1);
                } else {
                    Mal_saqlash("sync_bormi", 0);
                }
            }
        });
        switch_ofitsant.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ofitsant_bormi", 1);
                } else {
                    Mal_saqlash("ofitsant_bormi", 0);
                }
            }
        });

        switch_bonus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("bonus", 1);
                } else {
                    Mal_saqlash("bonus", 0);
                }
            }
        });
        set_oshxona_nomi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nom_dialog();
            }
        });
        set_tolov_print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tolov_print_dialog();
            }
        });
        set_taom_print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Taom_print_dialog();
            }
        });
        set_bekor_print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bekor_dialog();
            }
        });
        set_foiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Foiz_dialog();
            }
        });
        set_tolov_auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tolov_auto_dialog();
            }
        });
        set_auto_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Auto_delete_dialog();
            }
        });
        set_ruchnoy_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ruchnoy_delete_dialog();
            }
        });

    }

    private void Mal_toldirish() {
        int ofitsant_bormi = sharedPreferences.getInt("ofitsant_bormi", 1);
        int bonus = sharedPreferences.getInt("bonus", 1);
        int otdel_bormi = sharedPreferences.getInt("otdel_bormi", 1);
        int menu_bormi = sharedPreferences.getInt("menu_bormi", 1);
        int stol_bormi = sharedPreferences.getInt("stol_bormi", 1);
        int yulduz_bormi = sharedPreferences.getInt("yulduz_bormi", 1);
        int plastik_tolov = sharedPreferences.getInt("plastik_tolov", 1);
        int naqd_tolov = sharedPreferences.getInt("naqd_tolov", 1);
        int kop_tolov = sharedPreferences.getInt("kop_tolov", 1);
        int kam_tolov = sharedPreferences.getInt("kam_tolov", 1);
        int ozgartirish = sharedPreferences.getInt("ozgartirish", 1);
        int ochirish = sharedPreferences.getInt("ochirish", 1);
        int ochir_royh_korish = sharedPreferences.getInt("ochir_royh_korish", 1);
        int tolov_korish = sharedPreferences.getInt("tolov_korish", 1);
        int pul_korish = sharedPreferences.getInt("pul_korish", 1);
        int ofitsant_korish = sharedPreferences.getInt("ofitsant_korish", 1);
        int oldingi_korish = sharedPreferences.getInt("oldingi_korish", 1);
        int sync_bormi = sharedPreferences.getInt("sync_bormi", 1);

        if (otdel_bormi == 0) {
            switch_otdel.setChecked(false);
        } else if (otdel_bormi == 1) {
            switch_otdel.setChecked(true);
        }
        if (menu_bormi == 0) {
            switch_menu.setChecked(false);
        } else if (menu_bormi == 1) {
            switch_menu.setChecked(true);
        }
        if (stol_bormi == 0) {
            switch_stol.setChecked(false);
        } else if (stol_bormi == 1) {
            switch_stol.setChecked(true);
        }
        if (yulduz_bormi == 0) {
            switch_yulduz.setChecked(false);
        } else if (yulduz_bormi == 1) {
            switch_yulduz.setChecked(true);
        }
        if (plastik_tolov == 0) {
            switch_platik.setChecked(false);
        } else if (plastik_tolov == 1) {
            switch_platik.setChecked(true);
        }
        if (naqd_tolov == 0) {
            switch_naqd.setChecked(false);
        } else if (naqd_tolov == 1) {
            switch_naqd.setChecked(true);
        }
        if (kop_tolov == 0) {
            switch_kop.setChecked(false);
        } else if (kop_tolov == 1) {
            switch_kop.setChecked(true);
        }
        if (kam_tolov == 0) {
            switch_kam.setChecked(false);
        } else if (kam_tolov == 1) {
            switch_kam.setChecked(true);
        }
        if (bonus == 0) {
            switch_bonus.setChecked(false);
        } else if (bonus == 1) {
            switch_bonus.setChecked(true);
        }
        if (ozgartirish == 0) {
            switch_ozgartir.setChecked(false);
        } else if (ozgartirish == 1) {
            switch_ozgartir.setChecked(true);
        }
        if (ochirish == 0) {
            switch_ochirish.setChecked(false);
        } else if (ochirish == 1) {
            switch_ochirish.setChecked(true);
        }
        if (ochir_royh_korish == 0) {
            switch_ochir_royh_korish.setChecked(false);
        } else if (ochir_royh_korish == 1) {
            switch_ochir_royh_korish.setChecked(true);
        }
        if (tolov_korish == 0) {
            switch_tolov_korish.setChecked(false);
        } else if (tolov_korish == 1) {
            switch_tolov_korish.setChecked(true);
        }
        if (pul_korish == 0) {
            switch_pul_korish.setChecked(false);
        } else if (pul_korish == 1) {
            switch_pul_korish.setChecked(true);
        }
        if (ofitsant_korish == 0) {
            switch_ofitsant_korish.setChecked(false);
        } else if (ofitsant_korish == 1) {
            switch_ofitsant_korish.setChecked(true);
        }
        if (oldingi_korish == 0) {
            switch_oldingi_korish.setChecked(false);
        } else if (oldingi_korish == 1) {
            switch_oldingi_korish.setChecked(true);
        }
        if (sync_bormi == 0) {
            switch_sync.setChecked(false);
        } else if (sync_bormi == 1) {
            switch_sync.setChecked(true);
        }
        if (ofitsant_bormi == 0) {
            switch_ofitsant.setChecked(false);
        } else if (ofitsant_bormi == 1) {
            switch_ofitsant.setChecked(true);
        }
        String oshxona_nomi = sharedPreferences.getString("oshxona_nomi", "");
        int tolov_print = sharedPreferences.getInt("tolov_print", -1);
        int taom_print = sharedPreferences.getInt("taom_print", -1);
        int bekor_print = sharedPreferences.getInt("bekor_print", -1);
        float foiz = sharedPreferences.getFloat("foiz", -1);
        int auto_tolov = sharedPreferences.getInt("auto_tolov", 0);
        int auto_delete = sharedPreferences.getInt("auto_delete", 0);

        txt_oshxona_nomi.setText(oshxona_nomi);
        if (tolov_print == -1) {
            txt_tolov_pechat.setText("To'lov cheki chiqarilmaydi");
        } else if (tolov_print == -2) {
            txt_tolov_pechat.setText("To'lov cheki kassadan chiqadi");
        } else {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT nomi FROM PRINTER WHERE Id = '" + tolov_print + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                String print_nomi = cursor.getString(0);
                txt_tolov_pechat.setText(print_nomi);
            }
        }

        if (taom_print == -1) {
            txt_taom_pechat.setText("Taom cheki chiqarilmaydi");
        } else if (taom_print == -2) {
            txt_taom_pechat.setText("Taom otdeli bo'yicha alohida");
        } else {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT nomi FROM PRINTER WHERE Id = '" + taom_print + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                String print_nomi = cursor.getString(0);
                txt_taom_pechat.setText(print_nomi);
            }
        }

        if (bekor_print == 0) {
            txt_bekor_pechat.setText("Bekor qilingan taom cheki chiqmaydi");
        } else if (bekor_print == -1) {
            txt_bekor_pechat.setText("Kassadan va taom otdelidan");
        } else if (bekor_print == -2) {
            txt_bekor_pechat.setText("Taom otdelidan");
        } else {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT nomi FROM PRINTER WHERE Id = '" + bekor_print + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                String print_nomi = cursor.getString(0);
                txt_bekor_pechat.setText(print_nomi);
            }
        }

        if (foiz == -1) {
            txt_foiz.setText("Kassir kiritsin");
        } else if (foiz == -2) {
            txt_foiz.setText("Foiz olinmaydi");
        } else {
            txt_foiz.setText("Umumiy summaning " + foiz + " i olinadi");
        }

        if (auto_tolov == 0) {
            txt_auto_tolov.setText("Avtomatik yozilmaydi");
        } else if (auto_tolov == 1) {
            txt_auto_tolov.setText("Naqd pulga yoziladi");
        } else if (auto_tolov == 2) {
            txt_auto_tolov.setText("Plastikka yoziladi");
        }

        if (auto_delete == 0) {
            txt_auto_delete.setText("Avtomatik o'chirilmaydi");
        } else if (auto_delete == 1) {
            txt_auto_delete.setText("Ma'lumot onlinega yuklanganda");
        } else if (auto_delete == 2) {
            txt_auto_delete.setText("Haftada 1 marta");
        } else if (auto_delete == 3) {
            txt_auto_delete.setText("Oyda 1 marta");
        }
    }

    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    private void Bekor_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_otmen_taom_print);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int bekor_print = sharedPreferences.getInt("bekor_print", -1);

        ArrayList<String> list = new ArrayList<>();
        final ArrayList<String> list_id = new ArrayList<>();
        list.clear();
        list_id.clear();
        list_id.add("");
        list_id.add("");
        list.add("Kassadan va taom otdelidan");
        list.add("Taom otdelidan");
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM PRINTER");
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String prin_id = cursor.getString(0);
                String prin_nomi = cursor.getString(1);
                list.add(prin_nomi);
                list_id.add(prin_id);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (bekor_print == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (bekor_print == -1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else if (bekor_print == -2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(1);
        } else {
            int index = list_id.indexOf("" + bekor_print);
            spinner.setSelection(index);
            swit.setChecked(true);
            spinner.setEnabled(true);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    if (spinner.getSelectedItemPosition() == 0) {
                        editor.putInt("bekor_print", -1);
                        editor.commit();
                    } else if (spinner.getSelectedItemPosition() == 1) {
                        editor.putInt("bekor_print", -2);
                        editor.commit();
                    } else {
                        int index = spinner.getSelectedItemPosition();
                        String id = list_id.get(index);
                        try {
                            int is = Integer.parseInt(id);
                            editor.putInt("bekor_print", is);
                            editor.commit();
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                } else {
                    editor.putInt("bekor_print", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Bonus_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_bonus);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int bonus = sharedPreferences.getInt("bonus", -1);

        ArrayList<String> list = new ArrayList<>();
        list.add("Kassir kiritadi");
        list.add("Umumiy to'lov summaning 2 foizi");
        list.add("3000");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (bonus == -1) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(bonus);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    int index = spinner.getSelectedItemPosition();
                    editor.putInt("bonus", index);
                    editor.commit();
                } else {
                    editor.putInt("bonus", -1);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();

            }
        });

        dialog.show();
    }

    private void Foiz_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_xizmat_foizi);
        dialog.setCancelable(true);
        dialog.setTitle("");


        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);
        final EditText edt_foiz = dialog.findViewById(R.id.edt_set_xizmat_foiz);

        double foiz = sharedPreferences.getFloat("foiz", -2);

        ArrayList<String> list = new ArrayList<>();
        list.add("Foiz kiritish");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);


        if (foiz == -2) {
            spinner.setSelection(0);
            spinner.setEnabled(false);
            swit.setChecked(false);
            edt_foiz.setEnabled(false);
            edt_foiz.setText("");
        } else {
            edt_foiz.setEnabled(true);
            edt_foiz.setTextColor(Color.BLACK);
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
            edt_foiz.setText("" + foiz);
            edt_foiz.setSelection(edt_foiz.getText().toString().length());
        }

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    if (swit.isChecked()) {
                        edt_foiz.setEnabled(true);
                        edt_foiz.setTextColor(Color.BLACK);
                        edt_foiz.requestFocus();
                        edt_foiz.setSelection(edt_foiz.getText().toString().length());
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
                if (isChecked) {
                    edt_foiz.setEnabled(true);
                    edt_foiz.setTextColor(Color.BLACK);
                } else {

                    edt_foiz.setEnabled(false);
                    edt_foiz.setTextColor(Color.GRAY);
                }
            }
        });
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
//                    if (spinner.getSelectedItemPosition() == 0) {
//                        editor.putFloat("foiz", -1);
//                        editor.commit();
//                    } else
                    if (spinner.getSelectedItemPosition() == 0) {
                        String foi = edt_foiz.getText().toString();
                        float so_son = 0;
                        if (!foi.equals("")) {
                            try {
                                so_son = Float.parseFloat(foi);
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = format.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                            }
                        }
                        editor.putFloat("foiz", so_son);
                        editor.commit();
                    }
                } else {
                    editor.putFloat("foiz", -2);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();

            }
        });

        dialog.show();
    }


    private void Tolov_auto_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_tolov_auto);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int auto_tolov = sharedPreferences.getInt("auto_tolov", -1);
        ArrayList<String> list = new ArrayList<>();
        list.add("Naqd pulga yozilsin");
        list.add("Plastikka yozilsin");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);
        if (auto_tolov == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (auto_tolov == 1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else if (auto_tolov == 2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(1);
        } else if (auto_tolov == 3) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(2);
        }
        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    int index = spinner.getSelectedItemPosition();
                    editor.putInt("auto_tolov", index + 1);
                    editor.commit();
                } else {
                    editor.putInt("auto_tolov", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Auto_delete_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_auto_delete);
        dialog.setCancelable(true);
        dialog.setTitle("");
        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int auto_delete = sharedPreferences.getInt("auto_delete", 0);

        ArrayList<String> list = new ArrayList<>();
        list.add("Ma'lumot onlinega yuklanganda");
        list.add("Haftada 1 marta");
        list.add("Oyda 1 marta");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);
        if (auto_delete == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (auto_delete == 1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else if (auto_delete == 2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(1);
        } else if (auto_delete == 3) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(2);
        }
        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    int index = spinner.getSelectedItemPosition();
                    editor.putInt("auto_delete", index + 1);
                    editor.commit();
                } else {
                    editor.putInt("auto_delete", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Ruchnoy_delete_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_ruchnoy_delete);
        dialog.setCancelable(true);
        dialog.setTitle("");
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        dialog.show();
    }

    private void Taom_print_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_taom_print);
        dialog.setCancelable(true);
        dialog.setTitle("");
        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int taom_print = sharedPreferences.getInt("taom_print", -1);

        ArrayList<String> list = new ArrayList<>();
        final ArrayList<String> list_id = new ArrayList<>();
        list.clear();
        list_id.clear();
        list_id.add("0");
        list.add("Otdeli bo'yicha alohida");

        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM PRINTER");
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String prin_id = cursor.getString(0);
                String prin_nomi = cursor.getString(1);
                list_id.add(prin_id);
                list.add(prin_nomi);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (taom_print == -1) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (taom_print == -2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else {
            int index = list_id.indexOf("" + taom_print);
            spinner.setSelection(index);
            swit.setChecked(true);
            spinner.setEnabled(true);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    if (spinner.getSelectedItemPosition() == 0) {
                        editor.putInt("taom_print", -2);
                        editor.commit();
                    } else {
                        int index = spinner.getSelectedItemPosition();
                        String id = list_id.get(index);
                        try {
                            int is = Integer.parseInt(id);
                            editor.putInt("taom_print", is);
                            editor.commit();
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                } else {
                    editor.putInt("taom_print", -1);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Tolov_print_dialog() {
        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_tolov_print);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int tolov_print = sharedPreferences.getInt("tolov_print", -1);

        ArrayList<String> list = new ArrayList<>();
        final ArrayList<String> list_id = new ArrayList<>();
        list.clear();
        list_id.clear();
        list.add("Kassadan");
        list_id.add("Kassadan");
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM PRINTER");
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String prin_id = cursor.getString(0);
                String prin_nomi = cursor.getString(1);
                list_id.add(prin_id);
                list.add(prin_nomi);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Sozlama_oyna.this, R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (tolov_print == -1) {
            spinner.setEnabled(false);
            swit.setChecked(false);
        } else if (tolov_print == -2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else {
            int index = list_id.indexOf("" + tolov_print);
            spinner.setSelection(index);
            swit.setChecked(true);
            spinner.setEnabled(true);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    if (spinner.getSelectedItemPosition() == 0) {
                        editor.putInt("tolov_print", -2);
                        editor.commit();
                    } else {
                        int index = spinner.getSelectedItemPosition();
                        String id = list_id.get(index);
                        try {
                            int is = Integer.parseInt(id);
                            editor.putInt("tolov_print", is);
                            editor.commit();
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    editor.putInt("tolov_print", -1);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Nom_dialog() {

        final Dialog dialog = new Dialog(Sozlama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_oshxona_nomi);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setTitle("");
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);
        final EditText edt_nomi = dialog.findViewById(R.id.edt_set_oshxona_nomi);

        String oshxona_nomi = sharedPreferences.getString("oshxona_nomi", "");
        edt_nomi.setText(oshxona_nomi);
        edt_nomi.setSelection(oshxona_nomi.length());
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomi = edt_nomi.getText().toString();
                if (!nomi.equals("")) {
                    editor.putString("oshxona_nomi", nomi);
                    editor.commit();
                    dialog.cancel();
                    txt_oshxona_nomi.setText(nomi);
                }
            }
        });

        dialog.show();

    }

}
