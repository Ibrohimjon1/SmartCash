package com.balance.smart_cash.Otmenalar;

import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Asosiy.Stol_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Ofitsant.Ofitsant_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Otmena_oyna extends Fragment {

    private View parent_view;
    ListView listV;
    static ArrayList<Otmen_list> otmen_lists = new ArrayList<>();
    ImageView btn_yangilash;
    static Otmen_adpter otmen_adpter;
    static TextView txt_otmenaoyna_yoq;
    FragmentTransaction fragment;
    static View txt_otdel_oyna_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.otmena_oyna, container, false);

        Bosh_oyna.txt_asos_tool.setText(R.string.qaytarilgan_taom_royh);
        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);
        int oldingi_korish = Bosh_oyna.sharedPreferences.getInt("oldingi_korish", 1);
        if (oldingi_korish == 0) {
            Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
            Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.VISIBLE);
        } else {
            Bosh_oyna.layout_asos_sana.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_lock.setVisibility(View.GONE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.GONE);
        }

        Bosh_oyna.qaysi_oyna = Bosh_oyna.OTMEN_OYNA;
        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
                final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
                if (ofit_bormi == 0) {
                    if (stol_bormi == 0) {
                        changeFragment(new Saboy1_oyna());
                    } else {
                        changeFragment(new Stol_oyna());
                    }
                } else if (ofit_bormi == 1) {
                    changeFragment(new Ofitsant_oyna());
                }
            }
        });
        init();
        return parent_view;

    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public void init() {
        btn_yangilash = (ImageView) getActivity().findViewById(R.id.btn_asos_yangilash);
        txt_otmenaoyna_yoq = (TextView) parent_view.findViewById(R.id.txt_otmenaoyna_yoq);
        listV = (ListView) parent_view.findViewById(R.id.otmen_listview);
        txt_otdel_oyna_mal_yoq = parent_view.findViewById(R.id.txt_otdel_oyna_mal_yoq);
        otmen_adpter = new Otmen_adpter(getContext(), otmen_lists);
        listV.setAdapter(otmen_adpter);

        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        String strDate = format.format(calendar1.getTime());
        Bosh_oyna.txt_sana.setText(strDate);

        final Calendar calendar = Calendar.getInstance();
        Bosh_oyna.year_x = calendar.get(Calendar.YEAR);
        Bosh_oyna.month_x = calendar.get(Calendar.MONTH);
        Bosh_oyna.day_x = calendar.get(Calendar.DAY_OF_MONTH);

        String sana = Bosh_oyna.txt_sana.getText().toString();
        String sql = "SELECT * FROM OTMEN_TAOMLAR WHERE ochirilgan_sana LIKE '" + sana + "%'";
        Yangilash yangilash = new Yangilash(sql, getContext());
        yangilash.execute();
        btn_yangilash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sana = Bosh_oyna.txt_sana.getText().toString();
                if (!sana.equals("")) {
                    String sql = "SELECT * FROM OTMEN_TAOMLAR WHERE ochirilgan_sana LIKE '" + sana + "%'";
                    Yangilash yangilash = new Yangilash(sql, getContext());
                    yangilash.execute();
                }
            }
        });

    }

    public static class Yangilash extends AsyncTask<Void, Void, String> {

        String sql;
        Context context;
        ProgressDialog dialog;

        public Yangilash(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

//            txt_otmenaoyna_yoq.setVisibility(View.VISIBLE);
//            txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
//            txt_otmenaoyna_yoq.setText(R.string.iltimos_mal_yuklanmoqda);
            otmen_lists.clear();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                int tartib = 0;
                do {
                    tartib++;
                    String taom = cursor.getString(2);
                    String soni = cursor.getString(3);
                    String bosh_sana = cursor.getString(4);
                    String ochir_sana = cursor.getString(5);
                    String shot = cursor.getString(6);
                    String stol = cursor.getString(7);
                    String ofit = cursor.getString(8);
                    otmen_lists.add(new Otmen_list(bosh_sana, ochir_sana, stol, shot, soni, taom, "" + tartib, ofit));
                } while (cursor.moveToNext());
                return "ok";
            } else {
                return "yoq";
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            otmen_adpter.notifyDataSetChanged();
            if (s.equals("ok")) {
                txt_otmenaoyna_yoq.setVisibility(View.GONE);
                txt_otdel_oyna_mal_yoq.setVisibility(View.GONE);
            } else {
                txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
                txt_otmenaoyna_yoq.setVisibility(View.VISIBLE);
                txt_otmenaoyna_yoq.setText(R.string.ushbu_sanada_qaytarilgan_yoq);
            }
        }
    }

}
