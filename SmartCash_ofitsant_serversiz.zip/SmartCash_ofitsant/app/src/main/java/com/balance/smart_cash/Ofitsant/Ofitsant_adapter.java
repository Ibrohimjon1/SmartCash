package com.balance.smart_cash.Ofitsant;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

public class Ofitsant_adapter extends BaseAdapter {

    private final Context mContext;
    private ArrayList<Ofitsant_list> stollar;

    // 1
    public Ofitsant_adapter(Context context, ArrayList<Ofitsant_list> stollar) {
        this.mContext = context;
        this.stollar = stollar;
    }

    // 2
    @Override
    public int getCount() {
        return stollar.size();
    }

    // 3
    @Override
    public long getItemId(int position) {
        return 0;
    }

    // 4
    @Override
    public Object getItem(int position) {
        return null;
    }

    // 5
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Ofitsant_list ofitsant_list = stollar.get(position);

        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.ofitsant_item, null);
        }

        final TextView txt_id = (TextView) convertView.findViewById(R.id.txt_ofit_item_id);
        final TextView txt_ismi = (TextView) convertView.findViewById(R.id.txt_ofit_item_ismi);

        txt_id.setText(ofitsant_list.getId());
        txt_ismi.setText(ofitsant_list.getIsmi());


        return convertView;
    }

}