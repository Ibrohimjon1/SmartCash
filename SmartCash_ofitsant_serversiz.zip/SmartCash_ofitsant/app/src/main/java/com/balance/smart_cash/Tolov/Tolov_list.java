package com.balance.smart_cash.Tolov;

/**
 * Created by Ibrohimjon on 20.08.2018.
 */

public class Tolov_list {

    String Tartib;
    String Taom;
    String Soni;
    String Narxi;
    String Summa;

    public Tolov_list(String tartib, String taom, String soni, String narxi, String summa) {
        Tartib = tartib;
        Taom = taom;
        Soni = soni;
        Narxi = narxi;
        Summa = summa;
    }

    public String getTartib() {
        return Tartib;
    }

    public void setTartib(String tartib) {
        Tartib = tartib;
    }

    public String getTaom() {
        return Taom;
    }

    public void setTaom(String taom) {
        Taom = taom;
    }

    public String getSoni() {
        return Soni;
    }

    public void setSoni(String soni) {
        Soni = soni;
    }

    public String getNarxi() {
        return Narxi;
    }

    public void setNarxi(String narxi) {
        Narxi = narxi;
    }

    public String getSumma() {
        return Summa;
    }

    public void setSumma(String summa) {
        Summa = summa;
    }
}
