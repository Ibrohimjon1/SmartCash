package com.balance.smart_cash.Tolov;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Asosiy.Stol_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Print.Tolov_pechat;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;
import com.balance.smart_cash.Umumiy.Umumiy_list;
import com.balance.smart_cash.Umumiy.Umumiy_oyna;
import com.lb.auto_fit_textview.AutoResizeTextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Tolov_oyna extends AppCompatActivity implements View.OnClickListener {
    ListView listView;
    ArrayList<Tolov_list> tolov_lists = new ArrayList<>();
    AutoResizeTextView btn_naqd, btn_plastik, btn_ortga, btn_tolov, btn_bonus;
    AutoResizeTextView btn_00, btn_0, btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9;
    ImageView btn_c;
    AutoResizeTextView txt_plastik, txt_tolov_ofit_ismi, txt_naqd, txt_bonus, txt_qaytim, txt_taom_summa, txt_xizmat, txt_tolov_sum;
    int TOLOV_SUMMA = 0;
    int TAOM_SUMMA = 0;
    int XIZMAT_SUMMA = 0;
    View btn_bonus_iks, view_bonus, view_naqd, view_plastik;
    int qaysi_bosildi = 0;
    final int BONUS_TXT = 0, NAQD_TXT = 1, PLASTIK_TXT = 2, QAYTIM_TXT = 3;
    SharedPreferences sharedPreferences;
    TextView txt_tolov_foiz;
    int PLASTIK_BORMI, NAQD_BORMI, BONUS_BORMI, KOP_TOLOV, KAM_TOLOV, TOLOV_PRINT;
    float FOIZ_BORMI, foizi;
    View layout_tolov_qaytim, layout_tolov_plastik, layout_tolov_naqd, layout_tolov_bonus, layout_tolov_foiz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tolov_oyna);

        sharedPreferences = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);

        PLASTIK_BORMI = sharedPreferences.getInt("plastik_tolov", 1);
        NAQD_BORMI = sharedPreferences.getInt("naqd_tolov", 1);
        BONUS_BORMI = sharedPreferences.getInt("bonus", 1);
        KOP_TOLOV = sharedPreferences.getInt("kop_tolov", 0);
        KAM_TOLOV = sharedPreferences.getInt("kam_tolov", 0);
        FOIZ_BORMI = sharedPreferences.getFloat("foiz", -2);

        TOLOV_PRINT = sharedPreferences.getInt("tolov_print", -1);

        txt_tolov_foiz = (TextView) findViewById(R.id.txt_tolov_foiz);
        init();
        btn_0 = (AutoResizeTextView) findViewById(R.id.btn_login_0);
        btn_00 = (AutoResizeTextView) findViewById(R.id.btn_login_00);
        btn_1 = (AutoResizeTextView) findViewById(R.id.btn_login_1);
        btn_2 = (AutoResizeTextView) findViewById(R.id.btn_login_2);
        btn_3 = (AutoResizeTextView) findViewById(R.id.btn_login_3);
        btn_4 = (AutoResizeTextView) findViewById(R.id.btn_login_4);
        btn_5 = (AutoResizeTextView) findViewById(R.id.btn_login_5);
        btn_6 = (AutoResizeTextView) findViewById(R.id.btn_login_6);
        btn_7 = (AutoResizeTextView) findViewById(R.id.btn_login_7);
        btn_8 = (AutoResizeTextView) findViewById(R.id.btn_login_8);
        btn_9 = (AutoResizeTextView) findViewById(R.id.btn_login_9);
        btn_c = (ImageView) findViewById(R.id.btn_login_c);

        btn_c.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if (btn_c.isPressed()) {
                            updateUI();
                        } else
                            timer.cancel();
                    }
                }, 100, 100);

                return true;

            }
        });


        btn_0.setOnClickListener(this);
        btn_00.setOnClickListener(this);
        btn_1.setOnClickListener(this);
        btn_2.setOnClickListener(this);
        btn_3.setOnClickListener(this);
        btn_4.setOnClickListener(this);
        btn_5.setOnClickListener(this);
        btn_6.setOnClickListener(this);
        btn_7.setOnClickListener(this);
        btn_8.setOnClickListener(this);
        btn_9.setOnClickListener(this);
        btn_c.setOnClickListener(this);
    }


    private void updateUI() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Ochirish();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    public void init() {
        listView = (ListView) findViewById(R.id.list_tolov);
        layout_tolov_bonus = findViewById(R.id.layout_tolov_bonus);
        layout_tolov_foiz = findViewById(R.id.layout_tolov_foiz);
        layout_tolov_naqd = findViewById(R.id.layout_tolov_naqd);
        layout_tolov_plastik = findViewById(R.id.layout_tolov_plastik);
        layout_tolov_qaytim = findViewById(R.id.layout_tolov_qaytim);

        btn_naqd = (AutoResizeTextView) findViewById(R.id.btn_tolov_naqd);
        btn_ortga = (AutoResizeTextView) findViewById(R.id.btn_tolov_ortga);
        btn_plastik = (AutoResizeTextView) findViewById(R.id.btn_tolov_plastik);
        btn_bonus = (AutoResizeTextView) findViewById(R.id.btn_tolov_bonus);
        btn_tolov = (AutoResizeTextView) findViewById(R.id.btn_tolov_tolov);
        txt_bonus = (AutoResizeTextView) findViewById(R.id.txt_tolov_bonus_sum);
        txt_plastik = (AutoResizeTextView) findViewById(R.id.txt_tolov_plast_sum);
        txt_naqd = (AutoResizeTextView) findViewById(R.id.txt_tolov_naqd_sum);
        txt_qaytim = (AutoResizeTextView) findViewById(R.id.txt_tolov_qaytim_sum);
        txt_xizmat = (AutoResizeTextView) findViewById(R.id.txt_tolov_xizmat_summa);
        txt_tolov_sum = (AutoResizeTextView) findViewById(R.id.txt_tolov_summa);
        txt_taom_summa = (AutoResizeTextView) findViewById(R.id.txt_tolov_taom_summa);
        txt_tolov_ofit_ismi = (AutoResizeTextView) findViewById(R.id.txt_tolov_ofit_ismi);
        btn_bonus_iks = (View) findViewById(R.id.btn_tolov_bonus_iks);
        view_bonus = findViewById(R.id.liniya_tolov_bonus);
        view_naqd = findViewById(R.id.liniya_tolov_naqd);
        view_plastik = findViewById(R.id.liniya_tolov_plastik);

        btn_bonus_iks.setVisibility(View.GONE);

        txt_qaytim.setText("0");

        if (BONUS_BORMI == 0) {
            layout_tolov_bonus.setVisibility(View.GONE);
        } else {
            layout_tolov_bonus.setVisibility(View.VISIBLE);
        }

        if (PLASTIK_BORMI == 0) {
            layout_tolov_plastik.setVisibility(View.GONE);
        } else {
            layout_tolov_plastik.setVisibility(View.VISIBLE);
        }
        if (NAQD_BORMI == 0) {
            layout_tolov_naqd.setVisibility(View.GONE);
        } else {
            layout_tolov_naqd.setVisibility(View.VISIBLE);
        }


        txt_bonus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qay = qaysi_bosildi;
                if (qay == NAQD_TXT) {
                    view_naqd.setBackgroundColor(Color.GRAY);
                } else if (qay == PLASTIK_TXT) {
                    view_plastik.setBackgroundColor(Color.GRAY);
                }
                view_bonus.setBackgroundColor(Color.BLUE);
                qaysi_bosildi = BONUS_TXT;
            }
        });
        txt_naqd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qay = qaysi_bosildi;
                if (qay == BONUS_TXT) {
                    view_bonus.setBackgroundColor(Color.GRAY);
                } else if (qay == PLASTIK_TXT) {
                    view_plastik.setBackgroundColor(Color.GRAY);
                }
                view_naqd.setBackgroundColor(Color.BLUE);
                qaysi_bosildi = NAQD_TXT;
            }
        });

        txt_plastik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qay = qaysi_bosildi;
                if (qay == BONUS_TXT) {
                    view_bonus.setBackgroundColor(Color.GRAY);
                } else if (qay == NAQD_TXT) {
                    view_naqd.setBackgroundColor(Color.GRAY);
                }
                view_plastik.setBackgroundColor(Color.BLUE);
                qaysi_bosildi = PLASTIK_TXT;
            }
        });

        tolov_lists.clear();
        if (Umumiy_oyna.umumiy_lists.size() > 0) {
            String umum_taom_summa = Umumiy_oyna.txt_umum_summa.getText().toString();
            if (!umum_taom_summa.equals("")) {
                txt_taom_summa.setText(umum_taom_summa);
                try {
                    TAOM_SUMMA = Integer.parseInt(umum_taom_summa.replaceAll(" ", ""));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                }
            }
            int umum_foiz_sum = 0;
            for (int i = 0; i < Umumiy_oyna.umumiy_lists.size(); i++) {
                Umumiy_list umumiy_list = Umumiy_oyna.umumiy_lists.get(i);
                String nomi = umumiy_list.getNomi();
                String narxi = umumiy_list.getNarxi();
                String soni = umumiy_list.getSoni();
                String umum_sum = umumiy_list.getUmum_summa();
                String foizi = umumiy_list.getFoizi();
                if (!umum_sum.equals("")) {
                    int umu_s = 0;
                    try {
                        umu_s = Integer.parseInt(umum_sum.replace(" ", ""));
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                    if (foizi.equals("1")) {
                        umum_foiz_sum += umu_s;
                    }
                }
                tolov_lists.add(new Tolov_list("" + (i + 1), nomi, soni, narxi, umum_sum));
            }
            int xizma = 0;
            if (FOIZ_BORMI == -2) {
                layout_tolov_foiz.setVisibility(View.GONE);
                xizma = 0;
            } else {
                foizi = FOIZ_BORMI;
                if (Umumiy_oyna.ofit_id_asos.equals("Saboy")) {
                    txt_tolov_ofit_ismi.setText("Saboy");
                    foizi = 0;
                } else if (Umumiy_oyna.ofit_id_asos.equals("Ofitsant yo'q")) {
                    txt_tolov_ofit_ismi.setText("№" + Umumiy_oyna.shot_asos + " - " + getString(R.string.shot_raqam));
                    foizi = 0;
                } else {
                    txt_tolov_ofit_ismi.setText(getString(R.string.admin_ofitsant) + " " + Stol_oyna.ofit_ismi);
                    String ofit_id = Stol_oyna.ofit_id_asos;
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT foiz FROM OFITSANT WHERE Id = '" + ofit_id.replace("'", "''") + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String foi = cursor.getString(0);
                        if (!foi.equals("")) {
                            try {
                                foizi = Float.parseFloat(foi);
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = format.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                            }
                        }
                    }
                }
                int foiz_sum = (int) (umum_foiz_sum * foizi) / 10000;
                xizma = foiz_sum * 100;
                txt_tolov_foiz.setText("" + foizi + "%");
            }
            TOLOV_SUMMA = TAOM_SUMMA + xizma;
            txt_xizmat.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(xizma)));
            txt_tolov_sum.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(TOLOV_SUMMA)));

            int auto_tolov = sharedPreferences.getInt("auto_tolov", 0);

            if (auto_tolov == 0) {

            } else if (auto_tolov == 1 && NAQD_BORMI == 1) {
                txt_naqd.setText(txt_tolov_sum.getText().toString());
                view_naqd.setBackgroundColor(Color.BLUE);
            } else if (auto_tolov == 2 && PLASTIK_BORMI == 1) {
                txt_plastik.setText(txt_tolov_sum.getText().toString());
                view_plastik.setBackgroundColor(Color.BLUE);
            } else if (auto_tolov == 3 && BONUS_BORMI == 1) {
                txt_bonus.setText(txt_tolov_sum.getText().toString());
                view_bonus.setBackgroundColor(Color.BLUE);
            }
            qaysi_bosildi = NAQD_TXT;

        }
        Tolov_adapter sot = new Tolov_adapter(Tolov_oyna.this, tolov_lists);
        listView.setAdapter(sot);

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        btn_tolov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String bonus = txt_bonus.getText().toString().replace(" ", "");
                final String naqd = txt_naqd.getText().toString().replace(" ", "");
                final String plastik = txt_plastik.getText().toString().replace(" ", "");

                final String umum_summa = txt_tolov_sum.getText().toString().replace(" ", "");

                int bonus_son = 0, naqd_son = 0, plast = 0, umum_s = 0;
                if (!bonus.equals("")) {
                    try {
                        bonus_son = Integer.parseInt(bonus);
                    } catch (NumberFormatException f) {
                        f.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, f.getMessage(), sql);
                    }
                }
                if (!naqd.equals("")) {
                    try {
                        naqd_son = Integer.parseInt(naqd);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                }
                if (!plastik.equals("")) {
                    try {
                        plast = Integer.parseInt(plastik);
                    } catch (NumberFormatException r) {
                        r.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                    }
                }
                if (!umum_summa.equals("")) {
                    try {
                        umum_s = Integer.parseInt(umum_summa);
                    } catch (NumberFormatException r) {
                        r.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                    }
                }
                if ((plast + naqd_son + bonus_son) == umum_s) {
                    new SweetAlertDialog(Tolov_oyna.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText(getString(R.string.ogohlantirish))
                            .setContentText(getString(R.string.tolov_qilmoqchimisiz))
                            .setCancelText(getString(R.string.yoq))
                            .setConfirmText(getString(R.string.ha))
                            .showCancelButton(true)
                            .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    // reuse previous dialog instance, keep widget user state, reset them if you need
                                    sDialog.cancel();
                                }
                            })
                            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    Orqa_Pechat orqa_pechat = new Orqa_Pechat(umum_summa, bonus, naqd, plastik);
                                    orqa_pechat.execute();
                                    sDialog.dismiss();
                                }
                            })
                            .show();

                } else if ((plast + naqd_son + bonus_son) < umum_s) {
                    if (KAM_TOLOV == 0) {
                        Bosh_oyna.OGOHLANTIRISH_XABAR(Tolov_oyna.this, getString(R.string.ogohlantirish), getString(R.string.tolov_summadan_kam_kiritdiz));
                    } else {
                        new SweetAlertDialog(Tolov_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText(getString(R.string.ogohlantirish))
                                .setContentText(getString(R.string.tolov_summadan_kam_kiritdiz))
                                .setCancelText(getString(R.string.yoq))
                                .setConfirmText(getString(R.string.yoq))
                                .showCancelButton(true)
                                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        // reuse previous dialog instance, keep widget user state, reset them if you need
                                        sDialog.cancel();
                                    }
                                })
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        Orqa_Pechat orqa_pechat = new Orqa_Pechat(umum_summa, bonus, naqd, plastik);
                                        orqa_pechat.execute();
                                        sDialog.dismiss();
                                    }
                                })
                                .show();
                    }
                } else if ((plast + naqd_son + bonus_son) > umum_s) {
                    if (KOP_TOLOV == 0) {
                        Bosh_oyna.OGOHLANTIRISH_XABAR(Tolov_oyna.this, getString(R.string.ogohlantirish),  getString(R.string.to_lov_summadan_ko_p_pul_olinsinmi));
                    } else {
                        new SweetAlertDialog(Tolov_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText(getString(R.string.ogohlantirish))
                                .setContentText(getString(R.string.tolovdan_kop_kiritgingiz))
                                .setCancelText(getString(R.string.yoq))
                                .setConfirmText(getString(R.string.yoq))
                                .showCancelButton(true)
                                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        // reuse previous dialog instance, keep widget user state, reset them if you need
                                        sDialog.cancel();
                                    }
                                })
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        Orqa_Pechat orqa_pechat = new Orqa_Pechat(umum_summa, bonus, naqd, plastik);
                                        orqa_pechat.execute();
                                        sDialog.dismiss();
                                    }
                                })
                                .show();
                    }
                }
            }
        });

        btn_bonus_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                txt_bonus.setText("");
                txt_naqd.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(TOLOV_SUMMA)));
                txt_plastik.setText("");
                btn_bonus_iks.setVisibility(View.GONE);
            }
        });


        btn_bonus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bonus = txt_tolov_sum.getText().toString();
                if (!bonus.equals("")) {
                    String qaytim = txt_qaytim.getText().toString().replace(" ", "");
                    if (!qaytim.equals("") && !qaytim.equals("0")) {
                        int qayt = 0;
                        try {
                            qayt = Integer.parseInt(qaytim);
                        } catch (NumberFormatException r) {
                            r.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                        }
                        if (qayt < 0) {
                            String naq = txt_bonus.getText().toString().replace(" ", "");
                            if (!naq.equals("")) {
                                int naqd = 0;
                                try {
                                    naqd = Integer.parseInt(naq);
                                } catch (NumberFormatException w) {
                                    w.printStackTrace();
                                    Calendar calendar1 = Calendar.getInstance();
                                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                    String strDate = format.format(calendar1.getTime());
                                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, w.getMessage(), sql);
                                }
                                txt_bonus.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1) + naqd)));
                            } else {
                                txt_bonus.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1))));
                            }
                            txt_qaytim.setText("0");
                            txt_qaytim.setTextColor(Color.BLACK);
                        } else {
                            txt_bonus.setText("");
                        }
                    }
                    int qay = qaysi_bosildi;
                    if (qay == NAQD_TXT) {
                        view_naqd.setBackgroundColor(Color.GRAY);
                    } else if (qay == PLASTIK_TXT) {
                        view_plastik.setBackgroundColor(Color.GRAY);
                    }
                    view_bonus.setBackgroundColor(Color.BLUE);
                    qaysi_bosildi = BONUS_TXT;
                }
            }
        });

        btn_plastik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String qaytim = txt_qaytim.getText().toString().replace(" ", "");
                if (!qaytim.equals("")) {
                    int qayt = 0;
                    try {
                        qayt = Integer.parseInt(qaytim);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }

                    if (qayt < 0) {
                        String naq = txt_plastik.getText().toString().replace(" ", "");
                        if (!naq.equals("")) {
                            int naqd = 0;
                            try {
                                naqd = Integer.parseInt(naq);
                            } catch (NumberFormatException w) {
                                w.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = format.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, w.getMessage(), sql);
                            }
                            txt_plastik.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1) + naqd)));
                        } else {
                            txt_plastik.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1))));
                        }
                        txt_qaytim.setText("0");
                        txt_qaytim.setTextColor(Color.BLACK);
                    } else {
                        txt_plastik.setText(txt_tolov_sum.getText().toString());
                        txt_bonus.setText("");
                        txt_naqd.setText("");
                        txt_qaytim.setText("0");
                    }
                } else {
                    txt_plastik.setText(txt_tolov_sum.getText().toString());
                    txt_bonus.setText("");
                    txt_qaytim.setText("0");
                    txt_qaytim.setTextColor(Color.BLACK);
                    txt_naqd.setText("");
                }
                int qay = qaysi_bosildi;
                if (qay == BONUS_TXT) {
                    view_bonus.setBackgroundColor(Color.GRAY);
                } else if (qay == NAQD_TXT) {
                    view_naqd.setBackgroundColor(Color.GRAY);
                }
                view_plastik.setBackgroundColor(Color.BLUE);
                qaysi_bosildi = PLASTIK_TXT;
            }
        });

        btn_naqd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String qaytim = txt_qaytim.getText().toString().replace(" ", "");
                if (!qaytim.equals("")) {
                    int qayt = 0;
                    try {
                        qayt = Integer.parseInt(qaytim);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }

                    if (qayt < 0) {
                        String naq = txt_naqd.getText().toString().replace(" ", "");
                        if (!naq.equals("")) {
                            int naqd = 0;
                            try {
                                naqd = Integer.parseInt(naq);
                            } catch (NumberFormatException w) {
                                w.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = format.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, w.getMessage(), sql);
                            }
                            txt_naqd.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1) + naqd)));
                        } else {
                            txt_naqd.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1))));
                        }
                        txt_qaytim.setText("0");
                        txt_qaytim.setTextColor(Color.BLACK);
                    } else {
                        txt_naqd.setText(txt_tolov_sum.getText().toString());
                        txt_bonus.setText("");
                        txt_plastik.setText("");
                        txt_qaytim.setText("0");
                    }
                } else {
                    txt_naqd.setText(txt_tolov_sum.getText().toString());
                    txt_bonus.setText("");
                    txt_qaytim.setText("0");
                    txt_qaytim.setTextColor(Color.BLACK);
                    txt_plastik.setText("");
                }
                int qay = qaysi_bosildi;
                if (qay == BONUS_TXT) {
                    view_bonus.setBackgroundColor(Color.GRAY);
                } else if (qay == PLASTIK_TXT) {
                    view_plastik.setBackgroundColor(Color.GRAY);
                }
                view_naqd.setBackgroundColor(Color.BLUE);
                qaysi_bosildi = NAQD_TXT;
            }
        });
    }


    class Orqa_Pechat extends AsyncTask<Void, String, String> {

        ProgressDialog loading;
        String umum_summa;
        String bonus;
        String naqd;
        String plastik;

        public Orqa_Pechat(String umum_summa, String bonus, String naqd, String plastik) {
            this.umum_summa = umum_summa;
            this.bonus = bonus;
            this.naqd = naqd;
            this.plastik = plastik;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(Tolov_oyna.this, getString(R.string.pechat_qilinmoqda), null, true, true);
        }

        @Override
        protected String doInBackground(Void... voids) {
            String shot = Tolov(umum_summa, bonus, naqd, plastik);
            return shot;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            if (!s.equals("")) {
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
            }
            finish();
            if (Umumiy_oyna.activity != null) {
                Umumiy_oyna.activity.finish();
            }

            if (!Umumiy_oyna.ofit_id_asos.equals("Saboy")) {
                Stol_oyna.Get_stol();
            } else {
                Saboy1_oyna.LoadData();
            }

        }
    }


    public String Tolov(String umum_summa, String bonus, String naqd, String plastik) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        String vaqti = format.format(calendar.getTime());

        String stol_id = Umumiy_oyna.stol_nomer_asos;
        String shot_id = Umumiy_oyna.shot_asos;
        String taom_sum = txt_taom_summa.getText().toString().replace(" ", "");
        String xizmat_sum = txt_xizmat.getText().toString().replace(" ", "");


        String sql = "UPDATE STOLLAR SET holati = 1 WHERE nomi LIKE '" + stol_id + "'";
        String sql_i = "UPDATE SHOTLAR SET yopilgan_sana = '" + vaqti + "', summa = '" + umum_summa + "' WHERE shot_raqam LIKE '" + shot_id + "' AND ochilgan_vaqt = '" + Umumiy_oyna.vaqti_asos + "'";
        Login_oyna.SQLITE_HELPER.queryData(sql);
        Login_oyna.SQLITE_HELPER.queryData(sql_i);

        String sql_so = "INSERT INTO TOLOVLAR VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
        Login_oyna.SQLITE_HELPER.Mal_qoshish_zakar(shot_id, vaqti, taom_sum, xizmat_sum, umum_summa, bonus, naqd, plastik, stol_id, "-", sql_so);


        String xatolik_soz = "";
        if (TOLOV_PRINT != -1) {
            String oshxona_nomi = sharedPreferences.getString("oshxona_nomi", "");

            String BEKOR_SOZ = "\"" + oshxona_nomi + "\"\n";
            String ismi = Stol_oyna.ofit_ismi;

            String shot = shot_id;
            if (shot.length() < 25) {
                for (int l = shot.length(); l < 25; l++) {
                    shot = shot + " ";
                }
            }
            String stol = stol_id;
            if (stol.length() < 25) {
                for (int l = stol.length(); l < 25; l++) {
                    stol = stol + " ";
                }
            }
            String pechat_shapka = "";
            if (ismi.equals("Ofitsant yo'q")) {
                pechat_shapka = "" +
                        "________________________________________________\n\n" +
                        " " + getString(R.string.vaqti) + ":                    " + vaqti + "  \n" +
                        " " + getString(R.string.shot_raqam) + ":        " + shot + " \n" +
                        " " + getString(R.string.stol_raqam) + ":        " + stol + " \n" +
                        "________________________________________________\n\n";
            } else {
                if (ismi.length() < 36) {
                    for (int i = ismi.length(); i < 36; i++) {
                        ismi = " " + ismi;
                    }
                }
                pechat_shapka = "" +
                        "________________________________________________\n\n" +
                        " " + getString(R.string.vaqti) + ":                    " + vaqti + " \n" +
                        " " + getString(R.string.admin_ofitsant) + ":" + ismi + " \n" +
                        " " + getString(R.string.shot_raqam) + ":        " + shot + " \n"+
                        " " + getString(R.string.stol_raqam) + ":        " + stol + " \n" +
                        "________________________________________________\n\n";
            }
            String asosiy = "";

            for (int i = 0; i < tolov_lists.size(); i++) {
                Tolov_list tolov_list = tolov_lists.get(i);
                String nomi = tolov_list.getTaom();
                String soni = tolov_list.getSoni();
                String summa = tolov_list.getSumma();
                if (nomi.length() < 33) {
                    for (int j = nomi.length(); j < 33; j++) {
                        nomi = nomi + " ";
                    }
                } else {
                    String taom_boshi = "" + nomi.substring(0, 33) + "             \n ";
                    String oxir = nomi.substring(33, nomi.length());
                    if (oxir.length() < 33) {
                        for (int j = oxir.length(); j < 33; j++) {
                            oxir = oxir + " ";
                        }
                    }
                    nomi = taom_boshi + oxir;
                }
                if (soni.length() < 4) {
                    for (int k = soni.length(); k < 4; k++) {
                        soni = soni + " ";
                    }
                }

                if (summa.length() < 7) {
                    for (int k = summa.length(); k < 7; k++) {
                        summa = " " + summa;
                    }
                }
                asosiy = asosiy + " " + nomi + " " + soni + " " + summa + " \n";
            }

            String tolov_sum = txt_taom_summa.getText().toString();
            String xizmat = txt_xizmat.getText().toString();
            if (tolov_sum.length() < 32) {
                for (int i = tolov_sum.length(); i < 32; i++) {
                    tolov_sum = " " + tolov_sum;
                }
            }
            if (xizmat.length() < 30) {
                for (int i = xizmat.length(); i < 30; i++) {
                    xizmat = " " + xizmat;
                }
            }
            String pad = " " + getString(R.string.taom_sum) + ": " + tolov_sum + " \n" +
                    " " + getString(R.string.xizmat_sum) +": " + xizmat + " \n" +
                    "________________________________________________\n";

            String taom = asosiy + "________________________________________________\n\n" + pad + " \n";

            String padval = "  " + getString(R.string.to_lov_sum) +":  " + txt_tolov_sum.getText().toString() + " \n";

            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + TOLOV_PRINT + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                String print_ip = cursor.getString(0);

                xatolik_soz = Tolov_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom, padval);
            }
        }
        return xatolik_soz;
    }

    @Override
    public void onBackPressed() {
//        Xabar();
        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btn_login_0: {
                Toldirish("0");
            }
            break;
            case R.id.btn_login_00: {
                Toldirish("00");
            }
            break;
            case R.id.btn_login_1: {
                Toldirish("1");
            }
            break;
            case R.id.btn_login_2: {
                Toldirish("2");
            }
            break;
            case R.id.btn_login_3: {
                Toldirish("3");
            }
            break;
            case R.id.btn_login_4: {
                Toldirish("4");
            }
            break;
            case R.id.btn_login_5: {
                Toldirish("5");
            }
            break;
            case R.id.btn_login_6: {
                Toldirish("6");
            }
            break;
            case R.id.btn_login_7: {
                Toldirish("7");
            }
            break;
            case R.id.btn_login_8: {
                Toldirish("8");
            }
            break;
            case R.id.btn_login_9: {
                Toldirish("9");
            }
            break;
            case R.id.btn_login_c: {
                Ochirish();
            }
            break;
        }
    }

    private void Ochirish() {
        int qay = qaysi_bosildi;
        switch (qay) {
            case BONUS_TXT: {
                String bonus = txt_bonus.getText().toString().replace(" ", "");
                if (!bonus.equals("")) {
                    String yangi = bonus.substring(0, bonus.length() - 1);
                    if (!yangi.equals("")) {
                        txt_bonus.setText(Bosh_oyna.getDecimalFormattedString(yangi));
                    } else {
                        txt_bonus.setText("");
                    }
                } else {
                    txt_bonus.setText("");
                }
                QAYT_hisob();
            }
            break;
            case NAQD_TXT: {
                String naqd = txt_naqd.getText().toString().replace(" ", "");
                if (!naqd.equals("")) {
                    String yangi = naqd.substring(0, naqd.length() - 1);
                    if (!yangi.equals("")) {
                        txt_naqd.setText(Bosh_oyna.getDecimalFormattedString(yangi));
                    } else {
                        txt_naqd.setText("");
                    }
                } else {
                    txt_naqd.setText("");
                }
                QAYT_hisob();
            }
            break;
            case PLASTIK_TXT: {
                String plastik = txt_plastik.getText().toString().replace(" ", "");
                if (!plastik.equals("")) {
                    String yangi = plastik.substring(0, plastik.length() - 1);
                    if (!yangi.equals("")) {
                        txt_plastik.setText(Bosh_oyna.getDecimalFormattedString(yangi));
                    } else {
                        txt_plastik.setText("");
                    }
                } else {
                    txt_plastik.setText("");
                }
                QAYT_hisob();
            }
            break;
        }
    }

    private void QAYT_hisob() {
        final int UMUM_sum = TOLOV_SUMMA;
        String bonus = txt_bonus.getText().toString().replace(" ", "");
        String naqd = txt_naqd.getText().toString().replace(" ", "");
        String plastik = txt_plastik.getText().toString().replace(" ", "");
        String qaytim = txt_qaytim.getText().toString();
        int bon = 0, naq = 0, plast = 0, qayt = 0;
        if (!bonus.equals("")) {
            try {
                bon = Integer.parseInt(bonus);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
        }
        if (naqd.equals("") && plastik.equals("")) {
            qayt = bon - UMUM_sum;
        } else if (!naqd.equals("") && plastik.equals("")) {
            try {
                naq = Integer.parseInt(naqd);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
            qayt = bon + naq - UMUM_sum;
        } else if (naqd.equals("") && !plastik.equals("")) {
            try {
                plast = Integer.parseInt(plastik);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
            qayt = bon + plast - UMUM_sum;

        } else if (!naqd.equals("") && !plastik.equals("")) {
            try {
                plast = Integer.parseInt(plastik);
                naq = Integer.parseInt(naqd);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
            qayt = bon + plast + naq - UMUM_sum;

        }
        if (qayt < 0) {
            txt_qaytim.setText("-" + Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt * (-1))));
            txt_qaytim.setTextColor(Color.RED);
        } else {
            txt_qaytim.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(qayt)));
            txt_qaytim.setTextColor(Color.BLACK);
        }
    }

    private void Toldirish(String son) {
        int qay = qaysi_bosildi;
        switch (qay) {
            case BONUS_TXT: {
                String bonus = txt_bonus.getText().toString().replace(" ", "");
                if (son.equals("0") || son.equals("00")) {
                    if (!bonus.equals("")) {
                        txt_bonus.setText(Bosh_oyna.getDecimalFormattedString(bonus + son));
                        QAYT_hisob();
                    }
                } else {
                    txt_bonus.setText(Bosh_oyna.getDecimalFormattedString(bonus + son));
                    QAYT_hisob();
                }
            }
            break;
            case NAQD_TXT: {
                String naqd = txt_naqd.getText().toString().replace(" ", "");
                if (son.equals("0") || son.equals("00")) {
                    if (!naqd.equals("")) {
                        txt_naqd.setText(Bosh_oyna.getDecimalFormattedString(naqd + son));
                        QAYT_hisob();
                    }
                } else {
                    txt_naqd.setText(Bosh_oyna.getDecimalFormattedString(naqd + son));
                    QAYT_hisob();
                }
            }
            break;
            case PLASTIK_TXT: {
                String plastik = txt_plastik.getText().toString().replace(" ", "");
                if (son.equals("0") || son.equals("00")) {
                    if (!plastik.equals("")) {
                        txt_plastik.setText(Bosh_oyna.getDecimalFormattedString(plastik + son));
                        QAYT_hisob();
                    }
                } else {
                    txt_plastik.setText(Bosh_oyna.getDecimalFormattedString(plastik + son));
                    QAYT_hisob();
                }
            }
            break;
        }
    }


}
