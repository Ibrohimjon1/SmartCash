package com.balance.smart_cash.Umumiy;

/**
 * Created by Ibrohimjon on 20.08.2018.
 */

public class Umumiy_list {

    String Sotil_id;
    String Tov_id;
    String Nomi;
    String Soni;
    String Narxi;
    String Umum_summa;
    String Foizi;
    String Vaqti;
    String Printer;

    public Umumiy_list(String sotil_id, String tov_id, String nomi, String soni, String narxi, String umum_summa, String foizi, String vaqti, String printer) {
        Sotil_id = sotil_id;
        Tov_id = tov_id;
        Nomi = nomi;
        Soni = soni;
        Narxi = narxi;
        Umum_summa = umum_summa;
        Foizi = foizi;
        Vaqti = vaqti;
        Printer = printer;
    }

    public String getSotil_id() {
        return Sotil_id;
    }

    public void setSotil_id(String sotil_id) {
        Sotil_id = sotil_id;
    }

    public String getTov_id() {
        return Tov_id;
    }

    public void setTov_id(String tov_id) {
        Tov_id = tov_id;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }

    public String getSoni() {
        return Soni;
    }

    public void setSoni(String soni) {
        Soni = soni;
    }

    public String getNarxi() {
        return Narxi;
    }

    public void setNarxi(String narxi) {
        Narxi = narxi;
    }

    public String getUmum_summa() {
        return Umum_summa;
    }

    public void setUmum_summa(String umum_summa) {
        Umum_summa = umum_summa;
    }

    public String getFoizi() {
        return Foizi;
    }

    public void setFoizi(String foizi) {
        Foizi = foizi;
    }

    public String getVaqti() {
        return Vaqti;
    }

    public void setVaqti(String vaqti) {
        Vaqti = vaqti;
    }

    public String getPrinter() {
        return Printer;
    }

    public void setPrinter(String printer) {
        Printer = printer;
    }
}
