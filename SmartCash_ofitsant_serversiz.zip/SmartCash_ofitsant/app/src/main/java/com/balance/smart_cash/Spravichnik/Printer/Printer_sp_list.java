package com.balance.smart_cash.Spravichnik.Printer;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Printer_sp_list {
    String id;
    String num;
    String nomi;
    String url;
    String Tipi;

    public Printer_sp_list(String id, String num, String nomi, String url, String tipi) {
        this.id = id;
        this.num = num;
        this.nomi = nomi;
        this.url = url;
        Tipi = tipi;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNomi() {
        return nomi;
    }

    public void setNomi(String nomi) {
        this.nomi = nomi;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTipi() {
        return Tipi;
    }

    public void setTipi(String tipi) {
        Tipi = tipi;
    }
}
