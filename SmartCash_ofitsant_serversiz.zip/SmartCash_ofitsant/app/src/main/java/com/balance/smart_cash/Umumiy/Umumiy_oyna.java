package com.balance.smart_cash.Umumiy;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Asosiy.Stol_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Menu.Menu_oyna;
import com.balance.smart_cash.Otdel.Otdel_oyna;
import com.balance.smart_cash.Print.Taom_pechat;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;
import com.balance.smart_cash.Taomlar.Taomlar_oyna;
import com.balance.smart_cash.Tolov.Tolov_oyna;
import com.ufreedom.uikit.FloatingText;
import com.yydcdut.sdlv.Menu;
import com.yydcdut.sdlv.MenuItem;
import com.yydcdut.sdlv.SlideAndDragListView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Umumiy_oyna extends FragmentActivity implements AdapterView.OnItemLongClickListener,
        AdapterView.OnItemClickListener, AbsListView.OnScrollListener,
        SlideAndDragListView.OnDragDropListener, SlideAndDragListView.OnSlideListener,
        SlideAndDragListView.OnMenuItemClickListener, SlideAndDragListView.OnItemDeleteListener,
        SlideAndDragListView.OnItemScrollBackListener {

    public static Context context;
    public static Activity activity;
    public static TextView txt_stol_nomer, txt_umum_summa, txt_umum_taom_soni;
    public static ArrayList<Umumiy_list> umumiy_lists = new ArrayList<>();
    public static ArrayList<String> tang_idlar = new ArrayList<>();
    public static ArrayList<Integer> tang_posit = new ArrayList<>();
    private Menu mMenu;
    public static SlideAndDragListView mListView;
    ImageView btn_ortga;
    Button btn_otdel, btn_menu, btn_taom;
    Umumiy_list list;
    FragmentTransaction fragment;
    static ImageView btn_tolov;
    static ImageView btn_pechat;
    public static String shot_asos = "", ofit_id_asos = "", stol_nomer_asos, vaqti_asos = "";
    RelativeLayout layout;
    LinearLayout linearLayout;
    ImageView btn_yulduz, btn_umum_pop_ortga;
    public static int OTDEL_BORMI, MENU_BORMI, TAOM_PECHAT_BORMI, BEKOR_PRINT;
    SharedPreferences sharedPreferences;
    public static View view_umum_oq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.umumiy_oyna);
        context = Umumiy_oyna.this;
        activity = Umumiy_oyna.this;

        sharedPreferences = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        txt_stol_nomer = (TextView) findViewById(R.id.txt_umum_stol_nomer);
        txt_umum_taom_soni = (TextView) findViewById(R.id.txt_umum_taom_soni);
        txt_umum_summa = (TextView) findViewById(R.id.txt_umum_summa);
        btn_ortga = (ImageView) findViewById(R.id.btn_umum_oyna_ortga);
        view_umum_oq = findViewById(R.id.view_umum_oq);
        btn_taom = (Button) findViewById(R.id.btn_umum_taom);
        btn_menu = (Button) findViewById(R.id.btn_umum_menu);
        btn_pechat = (ImageView) findViewById(R.id.btn_umum_pechat);
        btn_tolov = (ImageView) findViewById(R.id.btn_umum_tolov);
        layout = (RelativeLayout) findViewById(R.id.layout_umum_btn);
        linearLayout = (LinearLayout) findViewById(R.id.layout_umum_ortga);
        btn_yulduz = (ImageView) findViewById(R.id.btn_umum_yulduz);
        btn_umum_pop_ortga = (ImageView) findViewById(R.id.btn_umum_pop_ortga);

        view_umum_oq.setVisibility(View.GONE);

        int yulduz_bormi = sharedPreferences.getInt("yulduz_bormi", 1);
        OTDEL_BORMI = sharedPreferences.getInt("otdel_bormi", 0);
        TAOM_PECHAT_BORMI = sharedPreferences.getInt("taom_print", 0);
        BEKOR_PRINT = sharedPreferences.getInt("bekor_print", 0);
        MENU_BORMI = sharedPreferences.getInt("menu_bormi", 1);
        if (yulduz_bormi == 1) {
            btn_yulduz.setVisibility(View.VISIBLE);
        } else {
            btn_yulduz.setVisibility(View.GONE);
        }
        btn_umum_pop_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Otdel_oyna());
                layout.setVisibility(View.VISIBLE);
                btn_yulduz.setVisibility(View.VISIBLE);
            }
        });

        btn_yulduz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.setVisibility(View.VISIBLE);
                changeFragment_taom(new Taomlar_oyna(), "yulduz");
//                linearLayout.setVisibility(View.VISIBLE);
            }
        });

        btn_tolov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tang_idlar.size() == 0) {
                    if (umumiy_lists.size() > 0) {
                        Intent intent = new Intent(Umumiy_oyna.this, Tolov_oyna.class);
                        startActivity(intent);
                    }
                } else {
                    Pechat_xabar(1);
                }
            }
        });

        linearLayout.setVisibility(View.GONE);
        layout.setVisibility(View.VISIBLE);

        btn_otdel = (Button) findViewById(R.id.btn_umum_otdel);
        Intent intent = getIntent();
        stol_nomer_asos = intent.getExtras().getString("stol");
        ofit_id_asos = intent.getExtras().getString("ofit");
        shot_asos = intent.getExtras().getString("shot");
        vaqti_asos = intent.getExtras().getString("vaqti");
        initMenu();
        initUiAndListener();
        if (stol_nomer_asos != null) {
            if (!stol_nomer_asos.equals("Saboy")) {
                txt_stol_nomer.setText(String.format(getString(R.string.umum_stol_soz), stol_nomer_asos, Stol_oyna.ofit_ismi));
            } else {
                txt_stol_nomer.setText(R.string.saboy);
            }
        }
        if (!shot_asos.equals("yangi")) {
            String sql = "SELECT * FROM ZAKAZLAR WHERE shot_raqam='" + shot_asos + "' AND vaqti >='" + vaqti_asos + "' AND ofit_id='" + ofit_id_asos.replace("'", "''") + "'";
            Orqa_fon orqa_fon = new Orqa_fon(sql);
            orqa_fon.execute();
        } else {
            umumiy_lists.clear();
        }

        btn_otdel.setVisibility(View.GONE);
        btn_menu.setVisibility(View.GONE);
        btn_taom.setVisibility(View.GONE);
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tang_idlar.clear();
        tang_posit.clear();
        if (OTDEL_BORMI != 0) {
            if (savedInstanceState == null) {
                changeFragment(new Otdel_oyna());
            }
        } else {
            if (MENU_BORMI == 1) {
                if (savedInstanceState == null) {
                    changeFragment(new Menu_oyna());
                }
            } else {
                if (savedInstanceState == null) {
                    changeFragment_taom(new Taomlar_oyna(), "");
                }
            }
        }

        btn_pechat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (umumiy_lists.size() > 0 && tang_idlar.size() > 0) {
                    Pechat_xabar(0);
                } else {

                }
            }
        });

    }

    public void Pechat_xabar(final int i) {
        String soz = "";
        if (TAOM_PECHAT_BORMI > 0) {
            soz = getString(R.string.pechat_qilmoqchimisiz);
        } else {
            soz = getString(R.string.buyurtmani_saqlamoqchimisiz);
        }
        new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setContentText(soz)
                .setCancelText(getString(R.string.yoq))
                .setConfirmText(getString(R.string.ha))
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(final SweetAlertDialog sDialog) {
                        sDialog.dismiss();
                        Orqa_Pechat orqa_pechat = new Orqa_Pechat(i);
                        orqa_pechat.execute();
                    }
                })
                .show();
    }


    class Orqa_Pechat extends AsyncTask<Void, String, String> {

        int qaysi = 0;
        ProgressDialog loading;

        public Orqa_Pechat(int qaysi) {
            this.qaysi = qaysi;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            String soz = "";
            if (TAOM_PECHAT_BORMI > 0) {
                soz = getString(R.string.pechat_qilinmoqda);
            } else {
                soz = getString(R.string.saqlanmoqda);
            }
            loading = ProgressDialog.show(Umumiy_oyna.this, soz, null, true, true);
        }

        @Override
        protected String doInBackground(Void... voids) {
            String shot = Qogozga_chiqar();
            return shot;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            if (!xatolik_soz.equals("")) {
                Toast.makeText(getApplication(), xatolik_soz, Toast.LENGTH_SHORT).show();
            }
            String sql = "SELECT * FROM ZAKAZLAR WHERE shot_raqam='" + s + "' AND vaqti >='" + vaqti_asos + "' AND ofit_id='" + ofit_id_asos.replace("'", "''") + "'";
            Orqa_fon orqa_fon = new Orqa_fon(sql);
            orqa_fon.execute();
            if (qaysi == 1) {
                Intent intent = new Intent(Umumiy_oyna.this, Tolov_oyna.class);
                startActivity(intent);
            }
        }
    }

    String xatolik_soz = "";
    String now_date;

    public String Qogozga_chiqar() {
        String shot_ra = "";
        if (umumiy_lists.size() > 0) {
            Calendar calendar = Calendar.getInstance();
            @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            @SuppressLint("SimpleDateFormat") SimpleDateFormat format2 = new SimpleDateFormat("dd.MM.yyyy");
            String strDate = format.format(calendar.getTime());
            now_date = format2.format(calendar.getTime());
            if (shot_asos.equals("yangi")) {
                String sql1 = "SELECT * FROM SHOTLAR WHERE ochilgan_vaqt LIKE '" + now_date + "%' ORDER BY Id DESC LIMIT 1";
                Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql1);
                int shot = 1;
                if (cursor.getCount() != 0) {
                    try {
                        cursor.moveToFirst();
                        String shot_raqa = cursor.getString(1);
                        try {
                            shot = Integer.parseInt(shot_raqa);
                        } catch (NumberFormatException we) {
                            we.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat formatt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDatet = formatt.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDatet, we.getMessage(), sql);
                        }
                        shot++;
                    } catch (Exception e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat formatt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDatet = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDatet, e.getMessage(), sql);

                    }
                } else {
                    shot = 1;
                }

                shot_ra = String.valueOf(shot);
                shot_asos = shot_ra;
                vaqti_asos = strDate;
                if (!stol_nomer_asos.equals("Saboy")) {
                    String sql_5 = "INSERT INTO SHOTLAR VALUES(NULL, ?, ?, NULL, ?, ?, NULL, 0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_4ta(shot_ra, strDate, Stol_oyna.ofit_ismi, stol_nomer_asos, sql_5);
                } else {
                    String sql_5 = "INSERT INTO SHOTLAR VALUES(NULL, ?, ?, NULL, ?, ?, NULL, 0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_4ta(shot_ra, strDate, "saboy", stol_nomer_asos, sql_5);
                }
                if (!stol_nomer_asos.equals("Saboy")) {
                    String sql_4 = "INSERT INTO STOLLAR VALUES(NULL, ?, 0, ?, ?, ?)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_4ta(stol_nomer_asos, ofit_id_asos, shot_ra, strDate, sql_4);
                }
            } else {
                shot_ra = shot_asos;
            }
            ArrayList<Umumiy_list> pech_qilina = new ArrayList<>();
            pech_qilina.clear();
            for (int i = 0; i < umumiy_lists.size(); i++) {
                Umumiy_list umumiy_list = umumiy_lists.get(i);
                String sotil_id = umumiy_list.getSotil_id();
                if (sotil_id.equals("")) {
                    String tov_id = umumiy_list.getTov_id();
                    String nomi = umumiy_list.getNomi();
                    String soni = umumiy_list.getSoni();
                    String narxi = umumiy_list.getNarxi().replace(" ", "");
                    String summa = umumiy_list.getUmum_summa().replace(" ", "");
                    String foizi = umumiy_list.getFoizi();
                    String print = umumiy_list.getPrinter();
                    String ofit_i = ofit_id_asos;

                    pech_qilina.add(umumiy_list);

                    String sql = "INSERT INTO ZAKAZLAR VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_zakar(tov_id, nomi, narxi, soni, summa, foizi, shot_ra, ofit_i, strDate, print, sql);
                }

            }

            if (pech_qilina.size() > 0 && TAOM_PECHAT_BORMI == 1) {
                Collections.sort(pech_qilina, new Comparator<Umumiy_list>() {
                    @Override
                    public int compare(Umumiy_list s1, Umumiy_list s2) {
                        return s1.getPrinter().compareTo(s2.getPrinter());
                    }
                });
                String sto = "";
                if (!stol_nomer_asos.equals("Saboy")) {
                    sto = "" + stol_nomer_asos + "-" + getString(R.string.stol)+"\n";
                } else {
                    sto = "" + stol_nomer_asos + "\n";
                }
                String ismi = "";
                if (!stol_nomer_asos.equals("Saboy")) {
                    ismi = Stol_oyna.ofit_ismi;
                } else {
                    ismi = "saboy";
                }

                String shot = shot_ra;
                if (shot.length() < 33) {
                    for (int l = shot.length(); l < 33; l++) {
                        shot = " " + shot;
                    }
                }
                String pechat_shapka = "";
                if (ismi.equals("Ofitsant yo'q")) {
                    pechat_shapka = "" +
                            "________________________________________________\n\n" +
                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                            " " + getString(R.string.vaqti) + ":                    " + strDate + "  \n" +
                            "________________________________________________\n";
                } else {
                    if (ismi.length() < 36) {
                        for (int i = ismi.length(); i < 36; i++) {
                            ismi = " " + ismi;
                        }
                    }
                    pechat_shapka = "" +
                            "________________________________________________\n\n" +
                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                            " " + getString(R.string.vaqti) + ":                    " + strDate + "  \n" +
                            " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                            "________________________________________________\n";
                }
                String print_id_eski = "";
                String print_eski = "";
                for (int i = 0; i < pech_qilina.size(); i++) {
                    Umumiy_list list = pech_qilina.get(i);
                    String prin_id = list.getPrinter();
                    if (!prin_id.equals(print_id_eski) && !print_id_eski.equals("")) {
                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + print_id_eski.trim() + "'");
                        if (cursor.getCount() != 0) {
                            cursor.moveToFirst();
                            String print_ip = cursor.getString(0);
                            xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, sto, pechat_shapka, print_eski);
                            print_eski = "";
                            String taom = list.getNomi();
                            String soni = list.getSoni();
                            if (taom.length() < 35) {
                                for (int j = taom.length(); j < 35; j++) {
                                    taom = taom + " ";
                                }
                            } else {
                                String taom_boshi = "" + taom.substring(0, 35) + "\n";
                                String oxir = taom.substring(35, taom.length());
                                if (oxir.length() < 35) {
                                    for (int j = oxir.length(); j < 35; j++) {
                                        oxir = oxir + " ";
                                    }
                                }
                                taom = taom_boshi + oxir;
                            }
                            if (soni.length() < 10) {
                                for (int k = soni.length(); k < 10; k++) {
                                    soni = soni + " ";
                                }
                            }
                            print_eski = print_eski + "\n " + taom + "  " + soni + "\n ";
                            print_id_eski = prin_id;
                        }
                    } else {
                        String taom = list.getNomi();
                        String soni = list.getSoni();
                        if (taom.length() < 35) {
                            for (int j = taom.length(); j < 35; j++) {
                                taom = taom + " ";
                            }
                        } else {
                            String taom_boshi = "" + taom.substring(0, 35) + "             \n ";
                            String oxir = taom.substring(35, taom.length());
                            if (oxir.length() < 35) {
                                for (int j = oxir.length(); j < 35; j++) {
                                    oxir = oxir + " ";
                                }
                            }
                            taom = taom_boshi + oxir;
                        }
                        if (soni.length() < 10) {
                            for (int k = soni.length(); k < 10; k++) {
                                soni = soni + " ";
                            }
                        }
                        print_eski = print_eski + "\n " + taom + "  " + soni + "\n";
                        print_id_eski = prin_id;
                    }
                }

                if (pech_qilina.size() > 0) {
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + print_id_eski.trim() + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, sto, pechat_shapka, print_eski);

                    }
                }

            }

        }
        return shot_ra;
    }

    class Orqa_fon extends AsyncTask<Void, String, String> {
        String sql;

        public Orqa_fon(String sql) {
            this.sql = sql;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {

            Get_sotilgan(sql);
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            adapter.notifyDataSetChanged();
            txt_umum_taom_soni.setText(umumiy_lists.size() + "");
            txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umum_summa)));
            if (umumiy_lists.size() > 0) {
                mListView.smoothScrollToPositionFromTop(umumiy_lists.size() - 1, 10, 500);
            }
        }

    }

    int umum_summa = 0;

    public void Get_sotilgan(String sql) {
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            umumiy_lists.clear();
            tang_posit.clear();
            tang_idlar.clear();
            umum_summa = 0;
            do {
                String id = cursor.getString(0);
                String tov_id = cursor.getString(1);
                String nomi = cursor.getString(2);
                String narxi = cursor.getString(3);
                String soni = cursor.getString(4);
                String summa = cursor.getString(5);
                String foizi = cursor.getString(6);
                String vaqti = cursor.getString(9);
                String print = cursor.getString(10);
                umumiy_lists.add(new Umumiy_list(id, tov_id, nomi, soni, Bosh_oyna.getDecimalFormattedString(narxi), Bosh_oyna.getDecimalFormattedString(summa), foizi, vaqti, print));
                if (!summa.equals("")) {
                    try {
                        int sum = Integer.parseInt(summa.replace(" ", ""));
                        umum_summa += sum;
                    } catch (NumberFormatException w) {
                        w.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql3 = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate,w.getMessage(), sql3);
                    }
                }
            } while (cursor.moveToNext());

        } else {
            umum_summa = 0;
            umumiy_lists.clear();
            tang_posit.clear();
            tang_idlar.clear();
        }
    }

    public static BaseAdapter adapter = new BaseAdapter() {
        @Override
        public int getCount() {
            return umumiy_lists.size();
        }

        @Override
        public Object getItem(int position) {
            return umumiy_lists.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        class ViewHolder {
            TextView txt_id, txt_nomi, txt_print, txt_soni, txt_narxi, txt_summa, txt_sotil_id, txt_foizi, txt_vaqti;

            View layout;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {

            View row = view;
            ViewHolder holder = new ViewHolder();

            if (row == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                row = inflater.inflate(R.layout.umum_items, null);

                holder.txt_sotil_id = (TextView) row.findViewById(R.id.txt_umum_item_sotil_id);
                holder.txt_id = (TextView) row.findViewById(R.id.txt_umum_item_id);
                holder.txt_nomi = (TextView) row.findViewById(R.id.txt_umum_item_nomi);
                holder.txt_soni = (TextView) row.findViewById(R.id.txt_umum_item_soni);
                holder.txt_print = (TextView) row.findViewById(R.id.txt_umum_item_printer);
                holder.txt_narxi = (TextView) row.findViewById(R.id.txt_umum_item_narxi);
                holder.txt_summa = (TextView) row.findViewById(R.id.txt_umum_item_umum_summa);
                holder.txt_foizi = (TextView) row.findViewById(R.id.txt_umum_item_foizi);
                holder.txt_vaqti = (TextView) row.findViewById(R.id.txt_umum_item_vaqti);
                holder.layout = (View) row.findViewById(R.id.layout_umum_item);

                row.setTag(holder);
            } else {
                holder = (ViewHolder) row.getTag();
            }
            try {

                Umumiy_list qarzdorlar_list = umumiy_lists.get(position);

                holder.txt_sotil_id.setText(qarzdorlar_list.getSotil_id());
                holder.txt_id.setText(qarzdorlar_list.getTov_id());
                holder.txt_nomi.setText(qarzdorlar_list.getNomi());
                holder.txt_soni.setText(qarzdorlar_list.getSoni());
                holder.txt_print.setText(qarzdorlar_list.getPrinter());
                holder.txt_narxi.setText(Bosh_oyna.getDecimalFormattedString(qarzdorlar_list.getNarxi()));
                holder.txt_foizi.setText(qarzdorlar_list.getFoizi());
                holder.txt_vaqti.setText(qarzdorlar_list.getVaqti());
                holder.txt_summa.setText(Bosh_oyna.getDecimalFormattedString(qarzdorlar_list.getUmum_summa()));
                if (!holder.txt_sotil_id.getText().toString().equals("")) {
                    holder.layout.setBackgroundColor(Color.rgb(172, 222, 241));
                } else {
                    holder.layout.setBackgroundColor(Color.rgb(255, 255, 255));
                }
            } catch (IndexOutOfBoundsException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
            return row;
        }
    };

    public void Oyna_ochish(final String id, final String nomi, final String esk_soni, String narxi, final int position, final String sot_id, final String printer_id, final int holati) {

        final Dialog dialog = new Dialog(Umumiy_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.ozgart_oyna);
        dialog.setCancelable(false);
        dialog.setTitle(getString(R.string.o_zgartirish));

        Button btn_ortga = (Button) dialog.findViewById(R.id.btn_umum_ozg_ortga);
        Button btn_saqlash = (Button) dialog.findViewById(R.id.btn_umum_ozg_saqlash);
        Button btn_plus = (Button) dialog.findViewById(R.id.btn_umum_ozg_plus);
        Button btn_minus = (Button) dialog.findViewById(R.id.btn_umum_ozg_minus);
        final TextView txt_soni = (TextView) dialog.findViewById(R.id.txt_umum_ozg_soni);
        final TextView txt_narxi = (TextView) dialog.findViewById(R.id.txt_umum_ozg_narxi);
        final TextView txt_nomi = (TextView) dialog.findViewById(R.id.txt_umum_ozg_nomi);

        txt_soni.setText(esk_soni);
        txt_nomi.setText(nomi);
        txt_narxi.setText(String.format(getString(R.string.ozgar_som), narxi));

        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String soni = txt_soni.getText().toString();
                if (!soni.equals("")) {
                    int eski_soni = 0;
                    try {
                        eski_soni = Integer.parseInt(soni);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                    if (eski_soni > 0) {
                        eski_soni--;
                        txt_soni.setText(String.valueOf(eski_soni));
                    }
                }
            }
        });
        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String soni = txt_soni.getText().toString();
                if (!soni.equals("")) {
                    int eski_soni = 0;
                    try {
                        eski_soni = Integer.parseInt(soni);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                    int eski = 0;
                    try {
                        eski = Integer.parseInt(esk_soni);
                    } catch (NumberFormatException r) {
                        r.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                    }
                    eski_soni++;

                    if (holati == 1) {
                        if (eski_soni <= eski) {
                            txt_soni.setText(String.valueOf(eski_soni));
                        }
                    } else {
                        txt_soni.setText(String.valueOf(eski_soni));
                    }
                }

            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String soni = txt_soni.getText().toString();

                if (!soni.equals("")) {

                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    final String ochgan_sana = format.format(calendar.getTime());
                    if (!soni.equals("0")) {
                        String narxi = txt_narxi.getText().toString().replace(" ", "");
                        int narx = 0, son = 0, eski_soni = 0, qosh_son = 0, qosh_summa = 0, umum = 0;
                        if (!narxi.equals("")) {
                            try {
                                narx = Integer.parseInt(narxi.substring(0, narxi.length() - 4));
                            } catch (NumberFormatException r) {
                                r.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat formatr = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = formatr.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                            }
                            try {
                                son = Integer.parseInt(soni);
                            } catch (NumberFormatException r) {
                                r.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat formatr = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = formatr.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                            }
                            try {
                                eski_soni = Integer.parseInt(esk_soni.replace(" ", ""));
                            } catch (NumberFormatException r) {
                                r.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat formatr = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = formatr.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                            }
                            qosh_son = son - eski_soni;
                            qosh_summa = qosh_son * narx;
                            int umu_narx = 0;
                            try {
                                if (!txt_umum_summa.getText().toString().equals("")) {
                                    try {
                                        umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                                        umu_narx = umu_narx + qosh_summa;
                                        txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                                    } catch (NumberFormatException e) {
                                        e.printStackTrace();
                                        Calendar calendar1 = Calendar.getInstance();
                                        SimpleDateFormat format3 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                        String strDate = format3.format(calendar1.getTime());
                                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                    }
                                }
                            } catch (NumberFormatException r) {
                                r.printStackTrace();
                                Calendar calendar1 = Calendar.getInstance();
                                SimpleDateFormat formatw = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                String strDate = formatw.format(calendar1.getTime());
                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                            }
                            umum = narx * son;
                            umumiy_lists.get(position).setUmum_summa(Bosh_oyna.getDecimalFormattedString(String.valueOf(umum)));
                        }

                        if (holati == 1) {
                            String sql;
                            Umumiy_list u = umumiy_lists.get(position);
                            String tov_id = u.getTov_id();
                            String vaqti = u.getVaqti();
                            String sql_in = "INSERT INTO OTMEN_TAOMLAR VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
                            String och_Soni = "";
                            if (qosh_son < 0) {
                                och_Soni = "" + (qosh_son * (-1));
                            } else {
                                och_Soni = "" + qosh_son;
                            }
                            String ofit_s = "";
                            if (!ofit_id_asos.equals("Saboy")) {
                                ofit_s = Stol_oyna.ofit_ismi;
                            } else {
                                ofit_s = "saboy";
                            }
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_Otmenlar(tov_id, txt_nomi.getText().toString(), och_Soni, vaqti, ochgan_sana, shot_asos, stol_nomer_asos, ofit_s, Login_oyna.foydalanuvhi_id, sql_in);
                            sql = "UPDATE ZAKAZLAR SET soni = '" + soni + "', summasi = '" + Bosh_oyna.getDecimalFormattedString(String.valueOf(umum)) + "' WHERE Id = '" + sot_id + "'";
                            Login_oyna.SQLITE_HELPER.queryData(sql);

                            if (BEKOR_PRINT != 0) {
                                String BEKOR_SOZ = getString(R.string.bekor_qilindi);
                                String ismi = ofit_s;

                                String shot = shot_asos;
                                if (shot.length() < 33) {
                                    for (int l = shot.length(); l < 33; l++) {
                                        shot = " " + shot;
                                    }
                                }
                                String pechat_shapka = "";
                                if (ismi.equals("Ofitsant yo'q")) {
                                    pechat_shapka = "" +
                                            "________________________________________________\n\n" +
                                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                            " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                                            " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                            " " + getString(R.string.bekor_vaqti) + ":          " + esk_soni + "  \n" +
                                            "________________________________________________\n";
                                } else {

                                    if (ismi.length() < 36) {
                                        for (int i = ismi.length(); i < 36; i++) {
                                            ismi = " " + ismi;
                                        }
                                    }
                                    pechat_shapka = "" +
                                            "________________________________________________\n\n" +
                                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                            " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                                            " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                            " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                                            " " + getString(R.string.bekor_vaqti) + ":          " + esk_soni + "  \n" +
                                            "________________________________________________\n";
                                }
                                String taom_nomi = nomi;
                                if (taom_nomi.length() < 35) {
                                    for (int j = taom_nomi.length(); j < 35; j++) {
                                        taom_nomi = taom_nomi + " ";
                                    }
                                }
                                String taom = "\n " + taom_nomi + "  " + och_Soni + "    \n";

                                if (BEKOR_PRINT == -1) {
                                    Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE nomi = 'Kassa'");
                                    if (cursor1.getCount() != 0) {
                                        cursor1.moveToFirst();
                                        String print_ip = cursor1.getString(0);
                                        xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                    }
                                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + printer_id.trim() + "'");
                                    if (cursor.getCount() != 0) {
                                        cursor.moveToFirst();
                                        String print_ip = cursor.getString(0);
                                        xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                    }
                                } else if (BEKOR_PRINT == -2) {

                                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + printer_id.trim() + "'");
                                    if (cursor.getCount() != 0) {
                                        cursor.moveToFirst();
                                        String print_ip = cursor.getString(0);
                                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                    }
                                } else {
                                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + BEKOR_PRINT + "'");
                                    if (cursor.getCount() != 0) {
                                        cursor.moveToFirst();
                                        String print_ip = cursor.getString(0);
                                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                    }
                                }
                            }
                        }
                        umumiy_lists.get(position).setSoni(soni);
                        adapter.notifyDataSetChanged();
                        txt_umum_taom_soni.setText(umumiy_lists.size() + "");
                        dialog.cancel();
                    } else {

                        new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText(getString(R.string.ogohlantirish))
                                .setContentText(getString(R.string.taomdan_o_ta_tanlayapsiz_ochirilsinmi))
                                .setCancelText(getString(R.string.yoq_ochirilmasin))
                                .setConfirmText(getString(R.string.ha_ochirilsin))
                                .showCancelButton(true)
                                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        // reuse previous dialog instance, keep widget user state, reset them if you need
                                        sDialog.cancel();
                                    }
                                })
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(final SweetAlertDialog sDialog) {
                                        String narxi = txt_narxi.getText().toString().replace(" ", "");
                                        int narx = 0, son = 0, eski_soni = 0, qosh_son = 0, qosh_summa;
                                        int umu_narx = 0;

                                        if (!narxi.equals("")) {
                                            try {
                                                narx = Integer.parseInt(narxi.substring(0, narxi.length() - 4));
                                            } catch (NumberFormatException r) {
                                                r.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                                            }
                                            try {
                                                eski_soni = Integer.parseInt(esk_soni.replace(" ", ""));
                                            } catch (NumberFormatException r) {
                                                r.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                                            }
                                            try {
                                                qosh_son = son - eski_soni;
                                                qosh_summa = qosh_son * narx;
                                                if (!txt_umum_summa.getText().toString().equals("")) {
                                                    try {
                                                        umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                                                        umu_narx = umu_narx + qosh_summa;
                                                        txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                                                    } catch (NumberFormatException e) {
                                                        e.printStackTrace();
                                                        Calendar calendar1 = Calendar.getInstance();
                                                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                        String strDate = format.format(calendar1.getTime());
                                                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                                    }
                                                }
                                            } catch (NumberFormatException r) {
                                                r.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                                            }
                                        }
                                        if (holati == 1) {
                                            String sql = "DELETE FROM ZAKAZLAR WHERE Id = '" + sot_id + "'";
                                            Login_oyna.SQLITE_HELPER.queryData(sql);
                                            Umumiy_list u = umumiy_lists.get(position);
                                            String tov_id = u.getTov_id();
                                            String vaqti = u.getVaqti();
                                            String ismi = "";
                                            if (stol_nomer_asos.equals("Saboy")) {
                                                ismi = "saboy";
                                            } else {
                                                ismi = ofit_id_asos;
                                            }

                                            String sql_in = "INSERT INTO OTMEN_TAOMLAR VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?,0)";
                                            Login_oyna.SQLITE_HELPER.Mal_qoshish_Otmenlar(tov_id, txt_nomi.getText().toString(), esk_soni, vaqti,
                                                    ochgan_sana, shot_asos, stol_nomer_asos, ismi, Login_oyna.foydalanuvhi_id, sql_in);


                                            String BEKOR_SOZ = getString(R.string.bekor_qilindi);

                                            String shot = shot_asos;
                                            if (shot.length() < 33) {
                                                for (int l = shot.length(); l < 33; l++) {
                                                    shot = " " + shot;
                                                }
                                            }
                                            String pechat_shapka = "";
                                            if (ismi.equals("Ofitsant yo'q")) {
                                                pechat_shapka = "" +
                                                        "________________________________________________\n\n" +
                                                        " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                                        " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                                                        " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                                        " " + getString(R.string.buyur_soni) + ":          " + esk_soni + "  \n" +
                                                        "________________________________________________\n";
                                            } else {

                                                if (ismi.length() < 36) {
                                                    for (int i = ismi.length(); i < 36; i++) {
                                                        ismi = " " + ismi;
                                                    }
                                                }
                                                pechat_shapka = "" +
                                                        "________________________________________________\n\n" +
                                                        " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                                        " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                                                        " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                                        " "+ getString(R.string.admin_ofitsant) +":" + ismi + "  \n" +
                                                        " " + getString(R.string.buyur_soni) + ":          " + esk_soni + "  \n" +
                                                        "________________________________________________\n";
                                            }

                                            String taom_nomi = nomi;
                                            if (taom_nomi.length() < 35) {
                                                for (int j = taom_nomi.length(); j < 35; j++) {
                                                    taom_nomi = taom_nomi + " ";
                                                }
                                            }
                                            String taom = "\n " + taom_nomi + "  " + esk_soni + "\n";

                                            if (BEKOR_PRINT == -1) {
                                                Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE nomi = 'Kassa'");
                                                if (cursor1.getCount() != 0) {
                                                    cursor1.moveToFirst();
                                                    String print_ip = cursor1.getString(0);
                                                    xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                }
                                                Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + printer_id.trim() + "'");
                                                if (cursor.getCount() != 0) {
                                                    cursor.moveToFirst();
                                                    String print_ip = cursor.getString(0);
                                                    xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                }
                                            } else if (BEKOR_PRINT == -2) {

                                                Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + printer_id.trim() + "'");
                                                if (cursor.getCount() != 0) {
                                                    cursor.moveToFirst();
                                                    String print_ip = cursor.getString(0);
                                                    xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                }
                                            } else {
                                                Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + BEKOR_PRINT + "'");
                                                if (cursor.getCount() != 0) {
                                                    cursor.moveToFirst();
                                                    String print_ip = cursor.getString(0);
                                                    xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                }
                                            }

                                        } else {
                                            int index = tang_idlar.indexOf(id);
                                            try {
                                                tang_idlar.remove(index);
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                            }
                                            try {
                                                tang_posit.remove(index);
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                            }
                                        }
                                        umumiy_lists.remove(position);

                                        adapter.notifyDataSetChanged();
                                        sDialog.cancel();
                                        dialog.cancel();

                                    }
                                })
                                .show();
                    }
                }
//                } else {
//                    dialog.cancel();
//                }
                txt_umum_taom_soni.setText(umumiy_lists.size() + "");
            }
        });
        dialog.show();
    }

    @Override
    public void onBackPressed() {
//        Stol_oyna.Get_stol();
        if (tang_idlar.size() > 0 && umumiy_lists.size() > 0) {
            Xabar();
        } else {
            finish();
        }
        if (!stol_nomer_asos.equals("Saboy")) {
            Stol_oyna.Get_stol();
        } else {
            Saboy1_oyna.LoadData();
        }
    }

    public void Xabar() {
        new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.ogohlantirish))
                .setContentText(getString(R.string.chiqishni_hohlaysizmi))
                .setCancelText(getString(R.string.yoq))
                .setConfirmText(getString(R.string.ha))
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.cancel();
                        finish();
                    }
                })
                .show();
    }


    public void initMenu() {
        mMenu = new Menu(true);
        mMenu.addItem(new MenuItem.Builder().setWidth((int) getResources().getDimension(R.dimen.slv_item_bg_btn_width) + 30)
                .setBackground(Utils.getDrawable(Umumiy_oyna.this, R.drawable.btn_right0))
                .setDirection(MenuItem.DIRECTION_LEFT)
                .setTextColor(Color.BLACK)
                .setTextSize(14)
                .setIcon(getResources().getDrawable(R.drawable.delete_umum))
                .build());
        mMenu.addItem(new MenuItem.Builder().setWidth((int) getResources().getDimension(R.dimen.slv_item_bg_btn_width_img))
                .setBackground(Utils.getDrawable(Umumiy_oyna.this, R.drawable.btn_left1))
                .setDirection(MenuItem.DIRECTION_RIGHT)
                .setTextColor(Color.BLACK)
                .setIcon(getResources().getDrawable(R.drawable.edit_umum))
                .build());
    }


    public void initUiAndListener() {
        mListView = (SlideAndDragListView) findViewById(R.id.lv_edit);
        mListView.setMenu(mMenu);
        mListView.setAdapter(adapter);
        mListView.setOnScrollListener(this);
        mListView.setOnDragDropListener(null);
        mListView.setOnItemClickListener(this);
        mListView.setOnSlideListener(this);
        mListView.setOnMenuItemClickListener(this);
        mListView.setOnItemDeleteListener(this);
        mListView.setOnItemLongClickListener(this);
        mListView.setOnItemScrollBackListener(this);
    }

    public static void Mal_qoshish(String tov_id, String nomi, String narxi, String fozi, String printer) {
        int indez = tang_idlar.indexOf(tov_id);
        if (!narxi.equals("")) {
            int narx = 0;
            int umu_narx = 0;
            if (!txt_umum_summa.getText().toString().equals("")) {
                try {
                    umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                }
            }
            try {

                narx = Integer.parseInt(narxi.replace(" ", ""));
                final FloatingText translateFloatingText = new FloatingText.FloatingTextBuilder(activity)
                        .textColor(Color.RED)
                        .textSize(50)
                        .textContent("+" + Bosh_oyna.getDecimalFormattedString(narxi))
                        .build();
                translateFloatingText.attach2Window();
                translateFloatingText.startFloating(txt_umum_summa);
                umu_narx = umu_narx + narx;
                txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
        }
        if (indez > -1) {
            int index = tang_posit.get(indez);
            Umumiy_list umumiy_list = umumiy_lists.get(index);
            String eski_soni = umumiy_list.getSoni();
            String narx = umumiy_list.getNarxi();
            int eeskisi = 0;
            int es_narx = 0;
            int umu_sum = 0;
            try {
                eeskisi = Integer.parseInt(eski_soni.replace(" ", ""));
                es_narx = Integer.parseInt(narx.replace(" ", ""));
                eeskisi++;
                umu_sum = eeskisi * es_narx;
            } catch (NumberFormatException w) {
                w.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, w.getMessage(), sql);
            }
            umumiy_lists.get(index).setSoni(String.valueOf(eeskisi));
            umumiy_lists.get(index).setUmum_summa(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_sum)));

            adapter.notifyDataSetChanged();

            View txt = getViewByPosition(index, mListView);
            if (txt != null) {
                final FloatingText translateFloatingText = new FloatingText.FloatingTextBuilder(activity)
                        .textColor(Color.RED)
                        .textSize(50)
                        .textContent("+1")
                        .build();
                translateFloatingText.attach2Window();
                TextView txt_son = (TextView) txt.findViewById(R.id.txt_umum_item_soni);
                translateFloatingText.startFloating(txt_son);
                int h1 = mListView.getHeight();
                int h2 = mListView.getChildAt(0).getHeight();

                mListView.smoothScrollToPositionFromTop(index, h1 / 2 - h2 / 2, 500);
            }
        } else {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar.getTime());
            umumiy_lists.add(new Umumiy_list("", tov_id, nomi, "1", narxi, narxi, fozi, strDate, printer));
            tang_idlar.add(tov_id);
            tang_posit.add(umumiy_lists.size() - 1);

            adapter.notifyDataSetChanged();
            if (umumiy_lists.size() > 0) {
                mListView.smoothScrollToPositionFromTop(umumiy_lists.size() - 1, 10, 500);
            }
        }

        txt_umum_taom_soni.setText(umumiy_lists.size() + "");
    }

    public static View getViewByPosition(int position, ListView listView) {
        final int firstListItemPosition = listView.getFirstVisiblePosition();
        final int lastListItemPosition = firstListItemPosition + listView.getChildCount() - 1;

        if (position < firstListItemPosition || position > lastListItemPosition) {
            return listView.getAdapter().getView(position, null, listView);
        } else {
            final int childIndex = position - firstListItemPosition;
            return listView.getChildAt(childIndex);
        }
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }

    public void changeFragment_taom(Fragment targetFragment, String nomi) {
        Bundle bundle = new Bundle();
        bundle.putString("otdel", nomi);
        targetFragment.setArguments(bundle);

        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }

    @Override
    public void onDragViewStart(int beginPosition) {
        list = umumiy_lists.get(beginPosition);
    }

    @Override
    public void onDragDropViewMoved(int fromPosition, int toPosition) {
//        Umumiy_list applicationInfo = umumiy_lists.remove(fromPosition);
//        umumiy_lists.add(toPosition, applicationInfo);
    }

    @Override
    public void onDragViewDown(int finalPosition) {
        umumiy_lists.set(finalPosition, list);
    }

    @Override
    public void onSlideOpen(View view, View parentView, int position, int direction) {
    }

    @Override
    public void onSlideClose(View view, View parentView, int position, int direction) {
//        toast("onSlideClose   position--->" + position + "  direction--->" + direction);
    }

    @Override
    public int onMenuItemClick(View vi, final int itemPosition, int buttonPosition, int direction) {
//        toast("onMenuItemClick   itemPosition--->" + itemPosition + "  buttonPosition-->" + buttonPosition + "  direction-->" + direction);
        View txt = getViewByPosition(itemPosition, mListView);
        View view = txt.findViewById(R.id.layout_umum_item);
        TextView txt_sot_id = (TextView) view.findViewById(R.id.txt_umum_item_sotil_id);
        final String sot_id = txt_sot_id.getText().toString();

        final TextView txt_id = (TextView) view.findViewById(R.id.txt_umum_item_id);
        final TextView txt_nomi = (TextView) view.findViewById(R.id.txt_umum_item_nomi);
        final TextView txt_soni = (TextView) view.findViewById(R.id.txt_umum_item_soni);
        final TextView txt_narxi = (TextView) view.findViewById(R.id.txt_umum_item_narxi);
        final TextView txt_print = (TextView) view.findViewById(R.id.txt_umum_item_printer);
        final TextView txt_vaqti = (TextView) view.findViewById(R.id.txt_umum_item_vaqti);
        final TextView txt_um_summ = (TextView) view.findViewById(R.id.txt_umum_item_umum_summa);
        final String id = txt_id.getText().toString();
        final String nomi = txt_nomi.getText().toString();
        //Update
        if (sot_id.equals("")) {
            switch (direction) {
                case MenuItem.DIRECTION_LEFT:
                    switch (buttonPosition) {
                        case 0:

                            new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                    .setContentText(getString(R.string.ushbu_taomni_ochirmoqchimisiz))
                                    .setCancelText(getString(R.string.yoq))
                                    .setConfirmText(getString(R.string.ha))
                                    .showCancelButton(true)
                                    .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            // reuse previous dialog instance, keep widget user state, reset them if you need

                                            sDialog.cancel();

                                        }
                                    })
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(final SweetAlertDialog sDialog) {
                                            String umu_sum = txt_um_summ.getText().toString();
                                            int qosh_summa;
                                            if (!umu_sum.equals("")) {
                                                try {
                                                    qosh_summa = Integer.parseInt(umu_sum.replace(" ", ""));
                                                    int umu_narx = 0;
                                                    if (!txt_umum_summa.getText().toString().equals("")) {
                                                        try {
                                                            umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                                                            umu_narx = umu_narx - qosh_summa;
                                                            txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                                                        } catch (NumberFormatException e) {
                                                            e.printStackTrace();
                                                            Calendar calendar1 = Calendar.getInstance();
                                                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                            String strDate = format.format(calendar1.getTime());
                                                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                                        }
                                                    }
                                                } catch (NumberFormatException r) {
                                                    r.printStackTrace();
                                                    Calendar calendar1 = Calendar.getInstance();
                                                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                    String strDate = format.format(calendar1.getTime());
                                                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                                                }
                                            }
                                            int index = tang_idlar.indexOf(txt_id.getText().toString());
                                            try {
                                                tang_idlar.remove(index);
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                            }
                                            try {
                                                tang_posit.remove(tang_idlar.size());
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                            }
                                            try {
                                                umumiy_lists.remove(itemPosition);
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Calendar calendar1 = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String strDate = format.format(calendar1.getTime());
                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                            }
                                            adapter.notifyDataSetChanged();

                                            txt_umum_taom_soni.setText(umumiy_lists.size() + "");
                                            sDialog.cancel();
                                        }
                                    })
                                    .show();
                            return Menu.ITEM_NOTHING;
                    }
                    break;
                case MenuItem.DIRECTION_RIGHT:
                    switch (buttonPosition) {
                        case 0:
                            String soni = txt_soni.getText().toString();
                            String narxi = txt_narxi.getText().toString();
                            String print = txt_print.getText().toString();
                            Oyna_ochish(id, nomi, soni, narxi, itemPosition, sot_id, print, 0);
                            return Menu.ITEM_SCROLL_BACK;
                    }
            }
        } else {

            int ozgartirish = sharedPreferences.getInt("ozgartirish", 1);
            int ochirish = sharedPreferences.getInt("ochirish", 1);
            switch (direction) {
                case MenuItem.DIRECTION_LEFT:
                    switch (buttonPosition) {
                        case 0:
                            if (ochirish == 0) {
                                Bosh_oyna.OGOHLANTIRISH_XABAR(Umumiy_oyna.this, getString(R.string.ogohlantirish), getString(R.string.cheki_chiq_mal_ochir_yoq));
                            } else {
                                new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                        .setContentText(getString(R.string.taom_cheki_chiqqan_ochirmoqchimisiz))
                                        .setCancelText(getString(R.string.yoq))
                                        .setConfirmText(getString(R.string.ha))
                                        .showCancelButton(true)
                                        .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                            @Override
                                            public void onClick(SweetAlertDialog sDialog) {
                                                // reuse previous dialog instance, keep widget user state, reset them if you need

                                                sDialog.cancel();

                                            }
                                        })
                                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                            @Override
                                            public void onClick(final SweetAlertDialog sDialog) {
                                                String umu_sum = txt_um_summ.getText().toString();
                                                int qosh_summa;
                                                if (!umu_sum.equals("")) {
                                                    try {
                                                        qosh_summa = Integer.parseInt(umu_sum.replace(" ", ""));
                                                        int umu_narx = 0;
                                                        if (!txt_umum_summa.getText().toString().equals("")) {
                                                            try {
                                                                umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                                                                umu_narx = umu_narx - qosh_summa;
                                                                txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                                                            } catch (NumberFormatException e) {
                                                                e.printStackTrace();
                                                                Calendar calendar1 = Calendar.getInstance();
                                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                                String strDate = format.format(calendar1.getTime());
                                                                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                                                            }
                                                        }
                                                    } catch (NumberFormatException r) {
                                                        r.printStackTrace();
                                                        Calendar calendar1 = Calendar.getInstance();
                                                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                        String strDate = format.format(calendar1.getTime());
                                                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                                                    }
                                                }
                                                String sql = "DELETE FROM ZAKAZLAR WHERE Id ='" + sot_id + "'";
                                                Login_oyna.SQLITE_HELPER.deleteData(sql);
                                                try {
                                                    umumiy_lists.remove(itemPosition);
                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                    e.printStackTrace();
                                                    Calendar calendar1 = Calendar.getInstance();
                                                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                    String strDate = format.format(calendar1.getTime());
                                                    String sqlr = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sqlr);
                                                }
                                                String ismi = "";
                                                if (!stol_nomer_asos.equals("Saboy")) {
                                                    ismi = Stol_oyna.ofit_ismi;
                                                } else {
                                                    ismi = "saboy";
                                                }
                                                Calendar calendar = Calendar.getInstance();
                                                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                                String ochgan_sana = format.format(calendar.getTime());

                                                String sql_in = "INSERT INTO OTMEN_TAOMLAR VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?,0)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_Otmenlar(id, nomi, txt_soni.getText().toString(), txt_vaqti.getText().toString(),
                                                        ochgan_sana, shot_asos, stol_nomer_asos, ismi, Login_oyna.foydalanuvhi_id, sql_in);

                                                if (BEKOR_PRINT != 0) {
                                                    String BEKOR_SOZ = getString(R.string.bekor_qilindi);

                                                    if (ismi.length() < 36) {
                                                        for (int i = ismi.length(); i < 36; i++) {
                                                            ismi = " " + ismi;
                                                        }
                                                    }
                                                    String shot = shot_asos;
                                                    if (shot.length() < 33) {
                                                        for (int l = shot.length(); l < 33; l++) {
                                                            shot = " " + shot;
                                                        }
                                                    }
                                                    String pechat_shapka = "" +
                                                            "________________________________________________\n\n" +
                                                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                                            " " + getString(R.string.buyur_vaqti) + ":           " + txt_vaqti.getText().toString() + "  \n" +
                                                            " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                                            " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                                                            " " + getString(R.string.buyur_soni) + ":          " + txt_soni.getText().toString() + "  \n" +
                                                            "________________________________________________\n";
                                                    String taom_nomi = nomi;
                                                    if (taom_nomi.length() < 35) {
                                                        for (int j = taom_nomi.length(); j < 35; j++) {
                                                            taom_nomi = taom_nomi + " ";
                                                        }
                                                    }
                                                    String taom = "\n " + taom_nomi + "  " + txt_soni.getText().toString() + "\n";

                                                    if (BEKOR_PRINT == -1) {
                                                        Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE nomi = 'Kassa'");
                                                        if (cursor1.getCount() != 0) {
                                                            cursor1.moveToFirst();
                                                            String print_ip = cursor1.getString(0);
                                                            xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                        }
                                                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + txt_print.getText().toString().trim() + "'");
                                                        if (cursor.getCount() != 0) {
                                                            cursor.moveToFirst();
                                                            String print_ip = cursor.getString(0);
                                                            xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                        }
                                                    } else if (BEKOR_PRINT == -2) {

                                                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + txt_print.getText().toString().trim() + "'");
                                                        if (cursor.getCount() != 0) {
                                                            cursor.moveToFirst();
                                                            String print_ip = cursor.getString(0);
                                                            xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                        }
                                                    } else {
                                                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE Id = '" + BEKOR_PRINT + "'");
                                                        if (cursor.getCount() != 0) {
                                                            cursor.moveToFirst();
                                                            String print_ip = cursor.getString(0);
                                                            xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                                                        }
                                                    }
                                                }
                                                adapter.notifyDataSetChanged();
                                                txt_umum_taom_soni.setText(umumiy_lists.size() + "");
                                                sDialog.cancel();
                                            }
                                        })
                                        .show();
                                return Menu.ITEM_NOTHING;
                            }
                    }
                    break;
                case MenuItem.DIRECTION_RIGHT:
                    switch (buttonPosition) {
                        case 0:
                            if (ozgartirish == 0) {
                                Bosh_oyna.OGOHLANTIRISH_XABAR(Umumiy_oyna.this, getString(R.string.ogohlantirish), getString(R.string.cheki_chiqqanni_ozgartira_olmaysiz));
                            } else {
                                String soni = txt_soni.getText().toString();
                                String narxi = txt_narxi.getText().toString();
                                String print = txt_print.getText().toString();
                                Oyna_ochish(id, nomi, soni, narxi, itemPosition, sot_id, print, 1);
                            }
                            return Menu.ITEM_SCROLL_BACK;
                    }
            }
        }
        return Menu.ITEM_NOTHING;
    }

    @Override
    public void onItemDeleteAnimationFinished(View view, int position) {
        umumiy_lists.remove(position - mListView.getHeaderViewsCount());
        adapter.notifyDataSetChanged();
        txt_umum_taom_soni.setText(umumiy_lists.size() + "");
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        switch (scrollState) {
            case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:
                break;
            case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                break;
            case AbsListView.OnScrollListener.SCROLL_STATE_FLING:
                break;
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount,
                         int totalItemCount) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        return false;
    }

    @Override
    public void onScrollBackAnimationFinished(View view, int position) {

    }
}
