package com.balance.smart_cash.Menu;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

public class Menu_adapter extends BaseAdapter {

    private final Context mContext;
    private ArrayList<Menu_list> stollar;

    // 1
    public Menu_adapter(Context context, ArrayList<Menu_list> stollar) {
        this.mContext = context;
        this.stollar = stollar;
    }

    // 2
    @Override
    public int getCount() {
        return stollar.size();
    }

    // 3
    @Override
    public long getItemId(int position) {
        return 0;
    }

    // 4
    @Override
    public Object getItem(int position) {
        return null;
    }

    // 5
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 1
        Menu_list book = stollar.get(position);

        // 2
        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.menu_item, null);
        }

        // 3
        // 3
        final TextView nameTextView = (TextView) convertView.findViewById(R.id.txt_otdel_item_nomi);
        final TextView id_TextView = (TextView) convertView.findViewById(R.id.txt_otdel_item_id);
        final ImageView imageView = (ImageView) convertView.findViewById(R.id.image_otdel_item);

        nameTextView.setText(book.getNomi());
        id_TextView.setText(book.getId());


        byte[] foodImage = book.getImage();
        if (foodImage.length == 0 || foodImage.length == 1){
            imageView.setImageResource(R.drawable.menu_ico);
        } else {
            Bitmap bitmap = BitmapFactory.decodeByteArray(foodImage, 0, foodImage.length);
            imageView.setImageBitmap(bitmap);
        }

        return convertView;
    }

}