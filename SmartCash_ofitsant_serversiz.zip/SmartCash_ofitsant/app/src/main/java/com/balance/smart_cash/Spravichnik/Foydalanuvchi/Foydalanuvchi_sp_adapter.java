package com.balance.smart_cash.Spravichnik.Foydalanuvchi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 26.08.2018.
 */

public class Foydalanuvchi_sp_adapter extends BaseAdapter{
    private Context context;
    private ArrayList<Foydalanuvchi_sp_list> foydalanuvchi_sp_lists;

    public Foydalanuvchi_sp_adapter(Context context, ArrayList<Foydalanuvchi_sp_list> foydalanuvchi_sp_lists) {
        this.context = context;
        this.foydalanuvchi_sp_lists = foydalanuvchi_sp_lists;
    }

    @Override
    public int getCount() {
        return foydalanuvchi_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return foydalanuvchi_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        TextView foydalan_sp_royhat_item_Num,foydalan_sp_royhat_item_FIO,foydalan_sp_royhat_item_Lavozim,
                foydalan_sp_royhat_item_Id,foydalan_sp_royhat_item_Parol;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;

        Foydalanuvchi_sp_list foydalanuvchiSpList=foydalanuvchi_sp_lists.get(position);
        ViewHolder holder=new ViewHolder();

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.foydalanuvchi_sp_royhat_item,null);
            holder.foydalan_sp_royhat_item_Num=row.findViewById(R.id.foydalan_sp_royhat_item_Num);
            holder.foydalan_sp_royhat_item_FIO=row.findViewById(R.id.foydalan_sp_royhat_item_FIO);
            holder.foydalan_sp_royhat_item_Lavozim=row.findViewById(R.id.foydalan_sp_royhat_item_Lavozim);
            holder.foydalan_sp_royhat_item_Parol=row.findViewById(R.id.foydalan_sp_royhat_item_Parol);
            holder.foydalan_sp_royhat_item_Id=row.findViewById(R.id.foydalan_sp_royhat_item_Id);

            row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
            holder.foydalan_sp_royhat_item_Num.setText(foydalanuvchiSpList.getNum());
            holder.foydalan_sp_royhat_item_Id.setText(foydalanuvchiSpList.getId());
            holder.foydalan_sp_royhat_item_FIO.setText(foydalanuvchiSpList.getFIO());
            holder.foydalan_sp_royhat_item_Parol.setText(foydalanuvchiSpList.getParol());

        return row;
    }
}
