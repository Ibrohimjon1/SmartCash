package com.balance.smart_cash.Ofitsant;

/**
 * Created by Ibrohimjon on 19.08.2018.
 */

public class Ofitsant_list {

    String Id;
    String Ismi;

    public Ofitsant_list(String id, String ismi) {
        Id = id;
        Ismi = ismi;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getIsmi() {
        return Ismi;
    }

    public void setIsmi(String ismi) {
        Ismi = ismi;
    }
}
