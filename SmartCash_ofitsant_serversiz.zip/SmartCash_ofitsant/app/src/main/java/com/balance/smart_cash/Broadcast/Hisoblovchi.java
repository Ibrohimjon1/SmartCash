package com.balance.smart_cash.Broadcast;

/**
 * Created by Ibrohimjon on 11.09.2018.
 */

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Hisoblovchi extends Service {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    public void onCreate() {
        super.onCreate();
        Intent notificationIntent = new Intent(this, Login_oyna.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        Notification notification = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Smart Cash")
                .setContentText(getString(R.string.dastur_ishga_tushir_uchun_bosing))
                .setContentIntent(pendingIntent).build();

        startForeground(1337, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        sharedPreferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        Toast.makeText(this, "Boshlandi", Toast.LENGTH_SHORT).show();

        int tugadi = sharedPreferences.getInt("tugadi", 0);
        if (tugadi == 0) {
            Functsiya();
        } else {
            stopSelf();
        }
        return Service.START_STICKY;
    }

    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopForeground(true);
        Toast.makeText(this, "Service Destroy", Toast.LENGTH_LONG).show();
    }


    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        public void handleMessage(Message msg) {

            Toast.makeText(getApplicationContext(), "Service " + msg.arg1, Toast.LENGTH_SHORT).show();
        }
    };

    public void Functsiya() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                int vaqt = 0, mudat_vaqti = 0;
                vaqt = sharedPreferences.getInt("vaqt", 0);
                String muddat = sharedPreferences.getString("muddat_vaqti", "0");
                if (!muddat.equals("")) {
                    try {
                        mudat_vaqti = Integer.parseInt(muddat) * 60;
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                }
                int iq = 0;
                for (int i = vaqt; i <= mudat_vaqti; i++) {

                    String holat = sharedPreferences.getString("holati", "0");
                    String muddatlimi = sharedPreferences.getString("muddatlimi", "0");
                    if (muddatlimi.equals("1") && holat.equals("1")) {
                        Mal_saqlash("vaqt", i);
//                        Message msg = handler.obtainMessage();
//                        msg.arg1 = i;
//                        handler.sendMessage(msg);
                        try {
                            Thread.sleep(4000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    } else {

                        Mal_saqlash("tugadi", 0);
                        Mal_saqlash("vaqt", 0);
                        stopSelf();
                        return;
                    }
                    iq = i;
                }
                if (iq == mudat_vaqti) {
                    Mal_saqlash("tugadi", 1);
                }
                stopSelf();
            }
        }).start();

    }
}