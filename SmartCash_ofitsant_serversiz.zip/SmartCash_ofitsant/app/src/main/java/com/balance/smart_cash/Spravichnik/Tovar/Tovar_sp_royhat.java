package com.balance.smart_cash.Spravichnik.Tovar;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.smart_cash.Admin.Admin_sp_royhat.Admin_Sp_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 25.08.2018.
 */

public class Tovar_sp_royhat extends Fragment {
    private View parent_view;
    ListView lv;
    static ArrayList<Tovar_sp_list> tovarSpLists = new ArrayList<>();
    static Tovar_sp_adapter tovar_adapte;
    static View txt_otdel_oyna_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.tovar_sp_royhat, container, false);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setVisibility(View.VISIBLE);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String f_id = "";
                Intent intent = new Intent(getContext(), Tovar_sp_QoshishOyna.class);
                intent.putExtra("SESSION_ID", f_id);
                startActivity(intent);
            }
        });

        init();
        return parent_view;
    }

    public void init() {
        txt_otdel_oyna_mal_yoq = parent_view.findViewById(R.id.txt_otdel_oyna_mal_yoq);
        lv = (ListView) parent_view.findViewById(R.id.tovar_sp_royhatList);
        tovar_adapte = new Tovar_sp_adapter(getContext(), tovarSpLists);
        lv.setAdapter(tovar_adapte);
        GetData_Taom();

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
                dialog.setContentView(R.layout.alertdialog_oyna);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.setTitle("O'zgartirish");
                Button btn_change = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ozgartir);
                Button btn_delet = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ochir);
                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextView idd = (TextView) view.findViewById(R.id.tovar_sp_royhat_item_Id);
                        String f_id = idd.getText().toString();
                        Intent intent = new Intent(getContext(), Tovar_sp_QoshishOyna.class);
                        intent.putExtra("SESSION_ID", f_id);
                        startActivity(intent);
                        dialog.dismiss();


                    }
                });

                btn_change.setText(R.string.o_zgartirish);
                btn_delet.setText(R.string.o_chirish);
                btn_delet.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        TextView idd = (TextView) view.findViewById(R.id.tovar_sp_royhat_item_Id);
                        String f_id = idd.getText().toString();
                        Login_oyna.SQLITE_HELPER.deleteData("DELETE FROM TAOMLAR WHERE Id='" + f_id + "'");
                        GetData_Taom();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
    }

    public static void GetData_Taom() {
        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT menu.nomi,taom.* FROM TAOMLAR AS taom INNER JOIN MENU AS menu ON" +
                " taom.menu_id=menu.Id");
        int p = 0;
        if (cursor_2.getCount() != 0) {
            tovarSpLists.clear();
            txt_otdel_oyna_mal_yoq.setVisibility(View.GONE);
            cursor_2.moveToFirst();
            do {
                p++;

                String menu_Nomi = cursor_2.getString(0);
                String id = cursor_2.getString(1);
                String taom_nomi = cursor_2.getString(2);
                String taom_narxi = cursor_2.getString(3);
                String taom_foiz = cursor_2.getString(7);
                byte[] rasm = cursor_2.getBlob(6);
                String num = String.valueOf(p);
                tovarSpLists.add(new Tovar_sp_list(id, num, taom_nomi, taom_narxi, taom_foiz, menu_Nomi, rasm));
            } while (cursor_2.moveToNext());
            tovar_adapte.notifyDataSetChanged();

        } else {
            tovarSpLists.clear();
            txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
            tovar_adapte.notifyDataSetChanged();
        }

    }
}