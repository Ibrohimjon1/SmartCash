package com.balance.smart_cash.Admin.Admin_hisobot;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import me.ithebk.barchart.BarChart;
import me.ithebk.barchart.BarChartModel;

public class Admin_hisobot_taom_diag extends Fragment {

    private View parent_view;
    private static BarChart barChartVertical;
    static TextView txt_mal_yoq, txt_hisob_ofit_nomi;
    FragmentTransaction fragment;
    static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.hisobot_ofitsant, container, false);
        init();
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.hisob_Fregmant, targetFragment)
                .commit();

    }

    public void init() {
        barChartVertical = (BarChart) parent_view.findViewById(R.id.bar_chart_vertical);
        txt_mal_yoq = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_ma_yoq);
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        txt_hisob_ofit_nomi = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_nomi);
        Calendar calendar1 = Calendar.getInstance();
        txt_hisob_ofit_nomi.setText(R.string.sotilgan_taom_diag);
        txt_hisob_ofit_nomi.setVisibility(View.VISIBLE);
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        final String strDate = format.format(calendar1.getTime());
        String sql = "SELECT tovar_id, nomi, SUM(soni), narxi, SUM(soni) * narxi AS summa FROM ZAKAZLAR WHERE vaqti LIKE '" + strDate + "%' GROUP BY tovar_id ORDER BY SUM(soni) ASC";

        Orqa_get_data orqa_get_data = new Orqa_get_data(sql, getContext());
        orqa_get_data.execute();

        barChartVertical.setOnBarClickListener(new BarChart.OnBarClickListener() {
            @Override
            public void onBarClick(BarChartModel barChartModel) {
                String taom_nomi = barChartModel.getBarText();
                String Soni = barChartModel.getBarValue_str();

                if (!taom_nomi.equals("")) {
                    ArrayList<Admin_hisobot_taom_row_list> list_rows = new ArrayList<>();

                    String sql = "SELECT zakaz.ofit_id,SUM(zakaz.soni) FROM ZAKAZLAR AS zakaz WHERE zakaz.vaqti LIKE '" + Admin_Hisobot_oyna.txt_admin_hisob_sana.getText().toString() + "%' AND zakaz.nomi LIKE '" + taom_nomi.replace("'", "''") + "' GROUP BY zakaz.ofit_id";

                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
                    list_rows.clear();
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();

                        int tart = 0;
                        do {
                            tart++;
                            String soni = cursor.getString(1);
                            String ismi = cursor.getString(0);

                            String sql1 = "SELECT ismi FROM OFITSANT WHERE Id = '" + ismi + "'";
                            Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData(sql1);
                            if (cursor1.getCount() != 0) {
                                cursor1.moveToFirst();
                                do {
                                    ismi = cursor1.getString(0);
                                } while (cursor1.moveToNext());
                            }
                            list_rows.add(new Admin_hisobot_taom_row_list("" + tart, ismi, soni));
                        } while (cursor.moveToNext());
                        Shot_dialog(list_rows, taom_nomi, Soni);
                    }
                }
            }
        });

    }

    private void Shot_dialog(ArrayList<Admin_hisobot_taom_row_list> list_rows, String taom, String soni) {

        final Dialog dialog = new Dialog(getContext(), R.style.hisob_ozgart_oyna_di);
        dialog.setContentView(R.layout.hisob_taom_item);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.CENTER;
        wlp.flags &= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        window.setAttributes(wlp);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setTitle("");

        ListView list_hisob_item = dialog.findViewById(R.id.list_hisob_item);
        TextView txt_hisob_item_row_nomi = dialog.findViewById(R.id.txt_hisob_item_row_nomi);
        TextView txt_hisob_item_row_soni = dialog.findViewById(R.id.txt_hisob_item_row_umum_soni);
        Admin_hisobot_taom_adapter_row adapter = new Admin_hisobot_taom_adapter_row(getContext(), list_rows);
        list_hisob_item.setAdapter(adapter);


        txt_hisob_item_row_nomi.setText(String.format(getString(R.string.admin_hisobot_ofitsant_boyicha), taom));
        txt_hisob_item_row_soni.setText(soni);
        ImageView btn_iks = dialog.findViewById(R.id.btn_hisob_item_iks);
        btn_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();

    }


    public static class Orqa_get_data extends AsyncTask<Void, String, Void> {

        BarChartModel barChartModel;
        int KATTASI = 0;
        String sql;
        ProgressDialog dialog;
        Context context;

        public Orqa_get_data(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

//            txt_mal_yoq.setText(R.string.iltimos_mal_yuklanmoqda);
//            txt_mal_yoq.setVisibility(View.VISIBLE);
//            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            barChartVertical.clearAll();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
            if (cursor.getCount() != 0) {
                cursor.moveToLast();
                String son = cursor.getString(2);
                if (!son.equals("")) {
                    try {
                        KATTASI = Integer.parseInt(son);
                        publishProgress("0");
                    } catch (NumberFormatException r) {
                        r.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                    }
                }
                cursor.moveToFirst();
                do {
                    String nomi = cursor.getString(1);
                    String soni = cursor.getString(2);
                    int so = 0;
                    if (!soni.equals("")) {
                        try {
                            so = Integer.parseInt(soni);

                        } catch (NumberFormatException r) {
                            r.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sql);
                        }
                    }
                    barChartModel = new BarChartModel();
                    barChartModel.setBarValue(so);
                    barChartModel.setBarValue_str(soni);
                    Random rnd = new Random();
                    barChartModel.setBarColor(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
                    barChartModel.setBarTag(null);
                    barChartModel.setBarText(nomi);
                    publishProgress("1");
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                } while (cursor.moveToNext());
                int soni = barChartVertical.getChildCount();
                Log.d("dwd", "" + soni);
            } else {
                publishProgress("no");
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            dialog.dismiss();
            if (values[0].equals("1")) {
                barChartVertical.addBar(0, barChartModel);
            } else if (values[0].equals("0")) {
                if (KATTASI < 10) {
                    barChartVertical.setBarMaxValue(KATTASI + 5);
                } else {
                    barChartVertical.setBarMaxValue(KATTASI * 125 / 100);
                }
                layout_ofit_mal_yoq.setVisibility(View.GONE);
                txt_mal_yoq.setVisibility(View.GONE);
            } else if (values[0].equals("no")) {
                txt_mal_yoq.setText(R.string.ushbu_sanada_sotilgan_taomlar_yo_q);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_mal_yoq.setVisibility(View.VISIBLE);
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }

    }

}
