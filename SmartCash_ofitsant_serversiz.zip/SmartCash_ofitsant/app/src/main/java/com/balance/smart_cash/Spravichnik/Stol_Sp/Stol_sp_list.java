package com.balance.smart_cash.Spravichnik.Stol_Sp;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Stol_sp_list {
    String id;
    String num;
    String nomi;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNomi() {
        return nomi;
    }

    public void setNomi(String nomi) {
        this.nomi = nomi;
    }

    public Stol_sp_list(String id, String num, String nomi) {
        this.id = id;
        this.num = num;
        this.nomi = nomi;
    }
}
