package com.balance.smart_cash.Hisobot;

/**
 * Created by Ibrohimjon on 03.09.2018.
 */

public class Hisob_ofit_list {

    String Ismi;
    int Summasi;

    public Hisob_ofit_list(String ismi, int summasi) {
        Ismi = ismi;
        Summasi = summasi;
    }

    public String getIsmi() {
        return Ismi;
    }

    public void setIsmi(String ismi) {
        Ismi = ismi;
    }

    public int getSummasi() {
        return Summasi;
    }

    public void setSummasi(int summasi) {
        Summasi = summasi;
    }
}
