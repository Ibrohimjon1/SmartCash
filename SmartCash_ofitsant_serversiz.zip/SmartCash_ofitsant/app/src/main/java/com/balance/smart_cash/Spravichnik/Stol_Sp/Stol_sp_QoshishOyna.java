package com.balance.smart_cash.Spravichnik.Stol_Sp;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

/**
 * Created by Hunter on 28.08.2018.
 */

public class Stol_sp_QoshishOyna extends AppCompatActivity {
    Button btn_stol_sp_Qoshish, btn_stol_sp_ortga;
    EditText edit_Stol_sp_Soni;
    String sessionId;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stol_sp_oyna);
        init();
        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        btn_stol_sp_Qoshish = (Button) findViewById(R.id.btn_stol_sp_Qoshish);
        btn_stol_sp_ortga = (Button) findViewById(R.id.btn_stol_sp_ortga);
        edit_Stol_sp_Soni = (EditText) findViewById(R.id.edit_Stol_sp_Soni);

        btn_stol_sp_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_stol_sp_Qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!edit_Stol_sp_Soni.getText().toString().equals("")) {

                    if (!sessionId.equals("")) {
                        String soni = edit_Stol_sp_Soni.getText().toString().trim();
                        Login_oyna.SQLITE_HELPER.queryData("UPDATE STOL_SONI SET  soni = '" + soni + "' WHERE Id='" + sessionId + "'");
                        edit_Stol_sp_Soni.setText("");
                        Stol_sp_royhat.GetData_Stol();
                        finish();
                    } else {
                        String sql = "INSERT INTO STOL_SONI VALUES (NULL, ?)";
                        String FIO = edit_Stol_sp_Soni.getText().toString();
                        Login_oyna.SQLITE_HELPER.Ofitsnt_qoshish_2ta(FIO, sql);
                        edit_Stol_sp_Soni.setText("");
                        Stol_sp_royhat.GetData_Stol();
                        finish();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_LONG).show();
                }


            }
        });


    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM STOL_SONI WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edit_Stol_sp_Soni.setText(cursor_2.getString(1));


        }
    }
}
