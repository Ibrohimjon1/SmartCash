package com.balance.smart_cash.Spravichnik.Menu;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Menu_sp_qoshishOyna extends AppCompatActivity {
    Button btn_menu_oyna_saqlash, btn_menu_ortga;
    ImageView img;
    EditText edit_Meun_sp_Qoshish;
    Spinner spinner;
    private static int RESULT_LOAD_IMAGE = 1;
    ArrayList<String> otdel_Nomi = new ArrayList<String>();
    ArrayList<String> otdel_ID = new ArrayList<String>();
    String sessionId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_sp_oyna);
        init();
        loadSpinnerData();
        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        btn_menu_oyna_saqlash = (Button) findViewById(R.id.btn_menu_oyna_saqlash);
        btn_menu_ortga = (Button) findViewById(R.id.btn_menu_ortga);
        img = (ImageView) findViewById(R.id.img_Menu_sp_Qoshish);
        spinner = (Spinner) findViewById(R.id.spinner_Menu_sp_Qoshish);
        edit_Meun_sp_Qoshish = (EditText) findViewById(R.id.edit_Meun_sp_Qoshish);

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        btn_menu_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_menu_oyna_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edit_Meun_sp_Qoshish.getText().toString().equals("")) {

                    if (!sessionId.equals("")) {
                        String sql = "UPDATE MENU SET  nomi = ?, otdel_id=?,rasmi=? WHERE Id='" + sessionId + "'";
                        String Nomi = edit_Meun_sp_Qoshish.getText().toString().trim();
                        int index = spinner.getSelectedItemPosition();
                        String otdelId = otdel_ID.get(index);

                        Login_oyna.SQLITE_HELPER.Menu_qoshish_3ta(Nomi, otdelId, img, sql);

                        edit_Meun_sp_Qoshish.setText("");
                        Menu_sp_royhat.GetData_Menu();
                        finish();

                    } else {
                        String sql = "INSERT INTO MENU VALUES (NULL, ?, ?, ?, 0)";
                        String otdel_nomi = edit_Meun_sp_Qoshish.getText().toString();
                        int index = spinner.getSelectedItemPosition();
                        String OtdelId = otdel_ID.get(index);
                        Login_oyna.SQLITE_HELPER.Menu_qoshish_3ta(otdel_nomi, OtdelId, img, sql);
                        edit_Meun_sp_Qoshish.setText("");
                        Menu_sp_royhat.GetData_Menu();
                        finish();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_LONG).show();
                }


            }
        });

    }

    private void loadSpinnerData() {
        // database handler
        Cursor cursor_1 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM OTDEL");
        if (cursor_1.getCount() != 0) {
            try {
                otdel_ID.clear();
                otdel_Nomi.clear();
                cursor_1.moveToFirst();
                do {
                    otdel_ID.add(cursor_1.getString(0));
                    otdel_Nomi.add(cursor_1.getString(1));

                } while (cursor_1.moveToNext());

            } catch (SQLException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
        }

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.spinner_item, otdel_Nomi);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }


    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM MENU WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edit_Meun_sp_Qoshish.setText(cursor_2.getString(1));
            String otdelID = cursor_2.getString(2);
            byte[] rasm = cursor_2.getBlob(3);
            int indexO = otdel_ID.indexOf(otdelID);

            Bitmap bitmap = BitmapFactory.decodeByteArray(rasm, 0, rasm.length);
            img.setImageBitmap(bitmap);
            spinner.setSelection(indexO);

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(selectedImage);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                img.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
