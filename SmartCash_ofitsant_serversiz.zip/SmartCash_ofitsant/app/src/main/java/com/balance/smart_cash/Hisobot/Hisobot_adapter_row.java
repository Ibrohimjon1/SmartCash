package com.balance.smart_cash.Hisobot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Hisobot_adapter_row extends BaseAdapter {
    Context context;
    private ArrayList<Hisob_list_row> sotilganLists;

    public Hisobot_adapter_row(Context context, ArrayList<Hisob_list_row> sotilganLists) {
        this.context = context;
        this.sotilganLists = sotilganLists;
    }

    @Override
    public int getCount() {
        return sotilganLists.size();
    }

    @Override
    public Object getItem(int position) {
        return sotilganLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_num, txt_sana, txt_shot, txt_taom, txt_xizmat;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;

        ViewHolder holder = new ViewHolder();
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.hisob_ofit_item_row, null);
            holder.txt_num = (TextView) row.findViewById(R.id.txt_hisob_item_row_tartib);
            holder.txt_sana = (TextView) row.findViewById(R.id.txt_hisob_item_row_sana);
            holder.txt_shot = (TextView) row.findViewById(R.id.txt_hisob_item_row_shot);
            holder.txt_taom = (TextView) row.findViewById(R.id.txt_hisob_item_row_taom);
            holder.txt_xizmat = (TextView) row.findViewById(R.id.txt_hisob_item_row_xizmat);

            row.setTag(holder);

        } else {
            holder = (ViewHolder) row.getTag();
        }
        Hisob_list_row sotilgan_list = sotilganLists.get(position);

        holder.txt_num.setText(sotilgan_list.getTartib());
        holder.txt_sana.setText(sotilgan_list.getSana());
        holder.txt_shot.setText(sotilgan_list.getShot());
        holder.txt_taom.setText(sotilgan_list.getTaom());
        holder.txt_xizmat.setText(sotilgan_list.getXizmat());


        return row;
    }
}
