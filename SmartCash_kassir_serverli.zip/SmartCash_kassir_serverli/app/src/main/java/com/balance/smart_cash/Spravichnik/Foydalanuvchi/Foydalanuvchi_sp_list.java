package com.balance.smart_cash.Spravichnik.Foydalanuvchi;

/**
 * Created by Hunter on 26.08.2018.
 */

public class Foydalanuvchi_sp_list {
    String id;
    String Num;
    String FIO;
    String Parol;


    public Foydalanuvchi_sp_list(String id, String num, String FIO, String parol) {
        this.id = id;
        Num = num;
        this.FIO = FIO;
        Parol = parol;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return Num;
    }

    public void setNum(String num) {
        Num = num;
    }

    public String getFIO() {
        return FIO;
    }

    public void setFIO(String FIO) {
        this.FIO = FIO;
    }


    public String getParol() {
        return Parol;
    }

    public void setParol(String parol) {
        Parol = parol;
    }
}
