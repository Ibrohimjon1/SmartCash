package com.balance.smart_cash.Hisobot;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Admin.Admin_hisobot.Admin_Hisobot_oyna;
import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Random;

import me.ithebk.barchart.BarChart;
import me.ithebk.barchart.BarChartModel;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Hisobot_ofitsant extends Fragment {

    private View parent_view;
    private static BarChart barChartVertical;
    static TextView txt_mal_yoq;
    static View layout_ofit_mal_yoq;
    FragmentTransaction fragment;
    public static Statement statement = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.hisobot_ofitsant, container, false);

        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        int oldingi_korish = Bosh_oyna.sharedPreferences.getInt("oldingi_korish", 1);
        if (oldingi_korish == 0) {
            Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
            Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.VISIBLE);
        } else {
            Bosh_oyna.layout_asos_sana.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_lock.setVisibility(View.GONE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.GONE);
        }
        Bosh_oyna.qaysi_oyna = Bosh_oyna.HISOB_OYNA;
        Bosh_oyna.txt_asos_tool.setText(R.string.nav_ofitsant_hisoboti);
        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
//                final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
//                if (ofit_bormi == 0) {
//                    if (stol_bormi == 0) {
                changeFragment(new Saboy1_oyna());
//                    } else {
//                        changeFragment(new Stol_oyna());
//                    }
//                } else if (ofit_bormi == 1) {
//                    changeFragment(new Ofitsant_oyna());
//                }
            }
        });
        init();
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public void init() {
        barChartVertical = (BarChart) parent_view.findViewById(R.id.bar_chart_vertical);
        txt_mal_yoq = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_ma_yoq);
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = format.format(calendar1.getTime());
        SimpleDateFormat format2 = new SimpleDateFormat("dd.MM.yyyy");
        String strDate2 = format2.format(calendar1.getTime());
        Bosh_oyna.txt_sana.setText(strDate2);

        final Calendar calendar = Calendar.getInstance();
        Bosh_oyna.year_x = calendar.get(Calendar.YEAR);
        Bosh_oyna.month_x = calendar.get(Calendar.MONTH);
        Bosh_oyna.day_x = calendar.get(Calendar.DAY_OF_MONTH);


        Orqa_get_data orqa_get_data = new Orqa_get_data(strDate, getContext());
        orqa_get_data.execute();

        barChartVertical.setOnBarClickListener(new BarChart.OnBarClickListener() {
            @Override
            public void onBarClick(BarChartModel barChartModel) {
                String ofit = barChartModel.getBarText();
                if (!ofit.equals("")) {
                    Orqa_tasl orqa_tasl = new Orqa_tasl(getContext(), ofit);
                    orqa_tasl.execute();
                }
            }
        });


    }

    public class Orqa_tasl extends AsyncTask<Void, Void, String> {
        Context context;
        ProgressDialog dialog;
        String ofit;
        String sana = Bosh_oyna.txt_sana.getText().toString();
        ArrayList<Hisob_list_row> list_rows = new ArrayList<>();
        int xizmati = 0, taomsuma = 0;

        public Orqa_tasl(Context context, String ofit) {
            this.context = context;
            this.ofit = ofit;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(context);
            dialog.setTitle(context.getString(R.string.iltimos_mal_yuklanmoqda));
            dialog.setIndeterminate(true);
            dialog.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            String url = "";
            list_rows.clear();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
            Date convertedDate = new Date();
            String sana3 = "";
            try {
                convertedDate = dateFormat.parse(sana);
                SimpleDateFormat sdfnewformat = new SimpleDateFormat("yyyy-MM-dd");
                sana3 = sdfnewformat.format(convertedDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            try {
                url = url_address + Urllar.Php_hisob_ofitsant_details + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_TOLOVLAR, "UTF-8") + "&table2=" + URLEncoder.encode(Login_oyna.TABLE_SHOTLAR, "UTF-8")
                        + "&sana=" + URLEncoder.encode(sana3, "UTF-8")
                        + "&ofit=" + URLEncoder.encode(ofit.replace("'", "`"), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }
                                    if (tugadi) {
                                        String vaqti = "";
                                        try {
                                            vaqti = jsonObject.getString("vaqti");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (vaqti.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String shot_raqam = "";
                                            try {
                                                shot_raqam = jsonObject.getString("shot_raqam");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String taom_sum = "";
                                            try {
                                                taom_sum = jsonObject.getString("taom_sum");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String xizmat_sum = "";
                                            try {
                                                xizmat_sum = jsonObject.getString("xizmat_sum");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }

                                            if (!taom_sum.equals("")) {
                                                try {
                                                    taomsuma += Integer.parseInt(taom_sum.replace(" ", ""));
                                                } catch (NumberFormatException r) {
                                                    r.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(r);
                                                }
                                            }
                                            if (!xizmat_sum.equals("")) {
                                                try {
                                                    xizmati += Integer.parseInt(xizmat_sum.replace(" ", ""));
                                                } catch (NumberFormatException r) {
                                                    r.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(r);
                                                }
                                            }
                                            list_rows.add(new Hisob_list_row("" + i, vaqti, shot_raqam, Bosh_oyna.getDecimalFormattedString(taom_sum), Bosh_oyna.getDecimalFormattedString(xizmat_sum)));
                                        }
                                    }
                                }
                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }

                return xatolik;
            }
            return "";
        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            if (aVoid.equals("off")) {
                Toast.makeText(getContext(), "Serverga ulanishda xatolik bo'ldi!", Toast.LENGTH_SHORT).show();
            } else {
                Nom_dialog(list_rows, ofit, sana, xizmati + "", taomsuma + "");
            }
        }
    }

    private void Nom_dialog(ArrayList<Hisob_list_row> list_rows, String ofit, String sana, String xizm, String taom) {

        final Dialog dialog = new Dialog(getContext(), R.style.hisob_ozgart_oyna_di);
        dialog.setContentView(R.layout.hisob_ofit_item);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.CENTER;
        wlp.flags &= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        window.setAttributes(wlp);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setTitle("");

        ListView list_hisob_item = dialog.findViewById(R.id.list_hisob_item);
        TextView txt_hisob_item_row_nomi = dialog.findViewById(R.id.txt_hisob_item_row_nomi);
        TextView txt_hisob_item_row_umum_taom = dialog.findViewById(R.id.txt_hisob_item_row_umum_taom);
        TextView txt_hisob_item_row_umum_xizm = dialog.findViewById(R.id.txt_hisob_item_row_umum_xizm);
        Hisobot_adapter_row adapter = new Hisobot_adapter_row(getContext(), list_rows);
        list_hisob_item.setAdapter(adapter);

        txt_hisob_item_row_umum_taom.setText(Bosh_oyna.getDecimalFormattedString(taom));
        txt_hisob_item_row_umum_xizm.setText(Bosh_oyna.getDecimalFormattedString(xizm));

        txt_hisob_item_row_nomi.setText(String.format(getString(R.string.admin_hisobot_ning_sanadagi), ofit, sana));
        ImageView btn_iks = dialog.findViewById(R.id.btn_hisob_item_iks);
        btn_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();

    }

    public static class Orqa_get_data extends AsyncTask<Void, String, String> {

        BarChartModel barChartModel;
        String eski_ismi = "";
        int eski_sum = 0;
        ArrayList<Hisob_ofit_list> ofit_lists = new ArrayList<>();
        int KATTASI = 0;
        String sana;
        ProgressDialog dialog;
        Context context;

        public Orqa_get_data(String sana, Context context) {
            this.sana = sana;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            ofit_lists.clear();
            barChartVertical.clearAll();
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

//            txt_mal_yoq.setText(R.string.iltimos_mal_yuklanmoqda);
//            txt_mal_yoq.setVisibility(View.VISIBLE);
//            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(Void... voids) {
            sonlari = 0;
            String url = "";
            try {
                url = url_address + Urllar.Php_hisob_ofitsant + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_TOLOVLAR, "UTF-8") + "&table2=" + URLEncoder.encode(Login_oyna.TABLE_SHOTLAR, "UTF-8")
                        + "&sana=" + URLEncoder.encode(sana, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }
                                    if (tugadi) {
                                        String ofit_id = "";
                                        try {
                                            ofit_id = jsonObject.getString("ofit_id");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (ofit_id.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String xizmat_sum = "";
                                            try {
                                                xizmat_sum = jsonObject.getString("xizmat_sum");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            int xizma = 0;
                                            if (!xizmat_sum.equals("")) {
                                                try {
                                                    xizma = Integer.parseInt(xizmat_sum.replace(" ", ""));
                                                } catch (NumberFormatException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                            }

                                            if (ofit_id.equals(eski_ismi)) {
                                                eski_sum += xizma;
                                            } else {
                                                if (i > 1) {
                                                    ofit_lists.add(new Hisob_ofit_list(eski_ismi, eski_sum));
                                                    eski_ismi = ofit_id;
                                                    eski_sum = xizma;
                                                } else {
                                                    eski_ismi = ofit_id;
                                                    eski_sum = xizma;
                                                }
                                            }

                                        }
                                    }
                                }
                                if (!eski_ismi.equals("")) {
                                    ofit_lists.add(new Hisob_ofit_list(eski_ismi, eski_sum));
                                }
                                Collections.sort(ofit_lists, new Comparator<Hisob_ofit_list>() {
                                    @Override
                                    public int compare(Hisob_ofit_list o1, Hisob_ofit_list o2) {
                                        return o1.getSummasi() - o2.getSummasi();
                                    }
                                });
                                if (ofit_lists.size() > 0) {
                                    KATTASI = ofit_lists.get(ofit_lists.size() - 1).getSummasi();
                                }
                                publishProgress("0");
                                for (int k = 0; k < ofit_lists.size(); k++) {
                                    Hisob_ofit_list list = ofit_lists.get(k);
                                    String ismi = list.getIsmi();
                                    int xizmat_sum = list.getSummasi();

                                    barChartModel = new BarChartModel();
                                    barChartModel.setBarValue(xizmat_sum);
                                    barChartModel.setBarValue_str(Bosh_oyna.getDecimalFormattedString("" + xizmat_sum));
                                    Random rnd = new Random();
                                    barChartModel.setBarColor(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
                                    barChartModel.setBarTag(null);
                                    barChartModel.setBarText(ismi);
                                    publishProgress("1");
                                    try {
                                        Thread.sleep(200);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                }
                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }
            }
            return "";
        }

        int sonlari = 0;

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            dialog.dismiss();
            if (values[0].equals("1")) {
                sonlari++;
                barChartVertical.addBar(0, barChartModel);
            } else if (values[0].equals("0")) {
                if (KATTASI != 0) {
                    barChartVertical.setBarMaxValue(KATTASI * 120 / 100);
                } else {
                    barChartVertical.setBarMaxValue(5);
                }
                txt_mal_yoq.setVisibility(View.GONE);
                layout_ofit_mal_yoq.setVisibility(View.GONE);
            } else if (values[0].equals("no")) {
                txt_mal_yoq.setText(R.string.ushbu_sanada_ofitsantlar_hisoboti_yo_q);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_mal_yoq.setVisibility(View.VISIBLE);
            }
        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            if (aVoid.equals("off")) {
                Toast.makeText(context, "Serverga ulanishda xatolik bo'ldi!", Toast.LENGTH_SHORT).show();
            }
            if (sonlari == 0) {

                txt_mal_yoq.setText(R.string.ushbu_sanada_ofitsantlar_hisoboti_yo_q);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_mal_yoq.setVisibility(View.VISIBLE);
            } else {

                txt_mal_yoq.setVisibility(View.GONE);
                layout_ofit_mal_yoq.setVisibility(View.GONE);
            }
        }

    }
}
