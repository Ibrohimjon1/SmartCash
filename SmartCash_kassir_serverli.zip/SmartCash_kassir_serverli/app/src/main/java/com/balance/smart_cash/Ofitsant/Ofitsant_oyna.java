package com.balance.smart_cash.Ofitsant;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Asosiy.Stol_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;

import java.util.ArrayList;

public class Ofitsant_oyna extends Fragment {

    GridView gridView;
    ArrayList<Ofitsant_list> ofitsant_list = new ArrayList<>();
    private View parentView;
    Ofitsant_adapter adapter;
    FragmentTransaction fragment;
    View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.ofitsant_oyna, container, false);

        Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.package_icon);
        Bosh_oyna.btn_asos_saboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Saboy1_oyna(), "", "");
            }
        });
        Bosh_oyna.Sozlash_qolgan();
        Setup();
        return parentView;
    }

    private void Setup() {
        layout_ofit_mal_yoq = parentView.findViewById(R.id.layout_ofit_mal_yoq);
        gridView = (GridView) parentView.findViewById(R.id.grid_view_stol);
        adapter = new Ofitsant_adapter(getContext(), ofitsant_list);
        gridView.setAdapter(adapter);

        Bosh_oyna.txt_asos_tool.setText(R.string.ofitsantlar_ro_yhati);
        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView txt_id = (TextView) view.findViewById(R.id.txt_ofit_item_id);
                TextView txt_ismi = (TextView) view.findViewById(R.id.txt_ofit_item_ismi);
                changeFragment(new Stol_oyna(), txt_id.getText().toString(), txt_ismi.getText().toString());
            }
        });

        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                changeFragment(new Saboy1_oyna(), "", "");

//                Bosh_oyna.drawer.openDrawer(Gravity.LEFT);

            }
        });

        TaskniTekshirish();
    }


    public void changeFragment(Fragment targetFragment, String id, String ismi) {
        Bundle bundle = new Bundle();
        bundle.putString("id", id);
        bundle.putString("ismi", ismi);
        targetFragment.setArguments(bundle);

        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void TaskniTekshirish() {
        Orqa_fon hozirgi_vaqt = new Orqa_fon();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            hozirgi_vaqt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            hozirgi_vaqt.execute();
        }

    }

    class Orqa_fon extends AsyncTask<Void, String, String> {
//        ProgressDialog loading;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            ofitsant_list.clear();
//            loading = ProgressDialog.show(getContext(), "Tekshirilmoqda...", null, true, true);
        }

        @Override
        protected String doInBackground(Void... voids) {
            String sql = "SELECT * FROM " + Login_oyna.TABLE_OFITSANT;
            Get_ofitsant(sql);

            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (ofitsant_list.size() == 0) {
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            }
            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }

//            loading.dismiss();
        }
    }


    public void Get_ofitsant(String sql) {
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            layout_ofit_mal_yoq.setVisibility(View.GONE);
            do {
                String id = cursor.getString(0);
                String ismi = cursor.getString(1);

                ofitsant_list.add(new Ofitsant_list(id, ismi));
            } while (cursor.moveToNext());
        }
    }
}
