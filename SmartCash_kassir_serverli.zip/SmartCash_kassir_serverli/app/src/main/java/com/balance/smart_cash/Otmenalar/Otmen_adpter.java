package com.balance.smart_cash.Otmenalar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Otmen_adpter extends BaseAdapter {
    Context context;
    private ArrayList<Otmen_list>otmen_lists;

    public Otmen_adpter(Context context, ArrayList<Otmen_list> otmen_lists) {
        this.context = context;
        this.otmen_lists = otmen_lists;
    }

    @Override
    public int getCount() {
        return otmen_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return otmen_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    private class ViewHolder {
        TextView txtBuyurtma_sana,txtBekor_sana,txt_otmen_stol, txt_otmen_shot,txt_otmen_son,txt_otmen_taom,txt_otmen_num;
            LinearLayout layout;
            View view;
    }

    @Override
    public View getView(int position, final View view, ViewGroup parent) {
        Otmen_list ot=otmen_lists.get(position);
        View row = view;

        ViewHolder holder = new ViewHolder();

        if (row == null) {

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.otmen_item, null);
            holder.layout = (LinearLayout) row.findViewById(R.id.layo);
            holder.txtBuyurtma_sana = (TextView) row.findViewById(R.id.txtBuyurtma_sana);
            holder.txtBekor_sana = (TextView) row.findViewById(R.id.txtBekor_sana);
            holder.txt_otmen_stol = (TextView) row.findViewById(R.id.txt_otmen_stol);
            holder.txt_otmen_shot = (TextView) row.findViewById(R.id.txt_otmen_shot);
            holder.txt_otmen_son = (TextView) row.findViewById(R.id.txt_otmen_son);
            holder.txt_otmen_taom = (TextView) row.findViewById(R.id.txt_otmen_taom);
            holder.txt_otmen_num = (TextView) row.findViewById(R.id.txt_otmen_num);

            row.setTag(holder);

        } else {
            holder = (ViewHolder) row.getTag();
        }

        Otmen_list qarzdorlar_list= otmen_lists.get(position);

        holder.txtBuyurtma_sana.setText(qarzdorlar_list.getBuyurtma_sana());
        holder.txtBekor_sana.setText(qarzdorlar_list.getOtmen_sana());
        holder.txt_otmen_stol.setText(qarzdorlar_list.getStol());
        holder.txt_otmen_shot.setText(qarzdorlar_list.getOfit());
        holder.txt_otmen_son.setText(qarzdorlar_list.getSon());
        holder.txt_otmen_taom.setText(qarzdorlar_list.getTaom());
        holder.txt_otmen_num.setText(qarzdorlar_list.getNum());

        return row;
    }
}
