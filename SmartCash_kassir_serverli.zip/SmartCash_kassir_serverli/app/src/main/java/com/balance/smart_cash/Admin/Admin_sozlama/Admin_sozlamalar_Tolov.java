package com.balance.smart_cash.Admin.Admin_sozlama;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_Tolov extends Fragment {
    View parent_view;
    LinearLayout set_foiz, set_tolov_auto;

    Switch switch_set_bonus, switch_set_plastik, switch_set_naqd, switch_set_kop_tolov, switch_set_kam_tolov;
    TextView txt_bonus, txt_naqd, txt_plastik, txt_avto, txt_foizi, txt_kop_olsinmi, txt_kam_olsinmi;
    TextView txt_set_foiz, txt_set_auto_tolov;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_tolov, container, false);
        init();
        return parent_view;
    }

    public void init() {
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        txt_bonus = parent_view.findViewById(R.id.txt_bonus);
        txt_naqd = parent_view.findViewById(R.id.txt_naqd_bormi);
        txt_plastik = parent_view.findViewById(R.id.txt_plastik_bormi);
        txt_avto = parent_view.findViewById(R.id.txt_avto_yozilsinmi);
        txt_foizi = parent_view.findViewById(R.id.txt_xizmat_foiz);
        txt_kop_olsinmi = parent_view.findViewById(R.id.txt_kop_olsinmi);
        txt_kam_olsinmi = parent_view.findViewById(R.id.txt_kam_olsinmi);

        txt_avto.setText(R.string.to_lov_summa_avto_yozilishi);
        txt_naqd.setText(R.string.naqd_bormi);
        txt_plastik.setText(R.string.plastik_bormi);
        txt_bonus.setText(R.string.bonus);
        txt_foizi.setText(R.string.xizmat_foiz);
        txt_kam_olsinmi.setText(R.string.to_lov_summadan_kam_pul_olinsinmi);
        txt_kop_olsinmi.setText(R.string.to_lov_summadan_ko_p_pul_olinsinmi);

        set_foiz = (LinearLayout) parent_view.findViewById(R.id.set_foiz);
        set_tolov_auto = (LinearLayout) parent_view.findViewById(R.id.set_tolov_auto);

        switch_set_kam_tolov = (Switch) parent_view.findViewById(R.id.switch_set_kam_tolov);
        switch_set_kop_tolov = (Switch) parent_view.findViewById(R.id.switch_set_kop_tolov);
        switch_set_naqd = (Switch) parent_view.findViewById(R.id.switch_set_naqd);
        switch_set_plastik = (Switch) parent_view.findViewById(R.id.switch_set_plastik);
        switch_set_bonus = (Switch) parent_view.findViewById(R.id.switch_set_bonus);

        txt_set_auto_tolov = (TextView) parent_view.findViewById(R.id.txt_set_auto_tolov);
        txt_set_foiz = (TextView) parent_view.findViewById(R.id.txt_set_foiz);
        Mal_toldirish();
        switch_set_plastik.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("plastik_tolov", 1);
                } else {
                    Mal_saqlash("plastik_tolov", 0);
                }
            }
        });
        switch_set_bonus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("bonus", 1);
                } else {
                    Mal_saqlash("bonus", 0);
                }
            }
        });
        switch_set_naqd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("naqd_tolov", 1);
                } else {
                    Mal_saqlash("naqd_tolov", 0);
                }
            }
        });

        switch_set_kop_tolov.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("kop_tolov", 1);
                } else {
                    Mal_saqlash("kop_tolov", 0);
                }
            }
        });

        switch_set_kam_tolov.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("kam_tolov", 1);
                } else {
                    Mal_saqlash("kam_tolov", 0);
                }
            }
        });

        set_foiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Foiz_dialog();
            }
        });
        set_tolov_auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tolov_auto_dialog();
            }
        });


    }

    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    private void Mal_toldirish() {
        int plastik_tolov = sharedPreferences.getInt("plastik_tolov", 0);
        int bonus = sharedPreferences.getInt("bonus", 0);
        int naqd_tolov = sharedPreferences.getInt("naqd_tolov", 0);
        int kop_tolov = sharedPreferences.getInt("kop_tolov", 0);
        int kam_tolov = sharedPreferences.getInt("kam_tolov", 0);

        if (kop_tolov == 0) {
            Mal_saqlash("kop_tolov", 0);
            switch_set_kop_tolov.setChecked(false);
        } else if (kop_tolov == 1) {
            switch_set_kop_tolov.setChecked(true);
        }
        if (kam_tolov == 0) {
            Mal_saqlash("kam_tolov", 0);
            switch_set_kam_tolov.setChecked(false);
        } else if (kam_tolov == 1) {
            switch_set_kam_tolov.setChecked(true);
        }
        if (plastik_tolov == 0) {
            Mal_saqlash("plastik_tolov", 0);
            switch_set_plastik.setChecked(false);
        } else if (plastik_tolov == 1) {
            switch_set_plastik.setChecked(true);
        }
        if (bonus == 0) {
            Mal_saqlash("bonus", 0);
            switch_set_bonus.setChecked(false);
        } else if (bonus == 1) {
            switch_set_bonus.setChecked(true);
        }
        if (naqd_tolov == 0) {
            Mal_saqlash("naqd_tolov", 0);
            switch_set_naqd.setChecked(false);
        } else if (naqd_tolov == 1) {
            switch_set_naqd.setChecked(true);
        }

        float foiz = sharedPreferences.getFloat("foiz", -2);
        int auto_tolov = sharedPreferences.getInt("auto_tolov", 0);

        if (foiz == -2) {
            txt_set_foiz.setText(R.string.foiz_olinmaydi);
        } else {
            txt_set_foiz.setText(String.format(getString(R.string.umumiy_summaning_foizi_olinadi), String.valueOf(foiz)));
        }

        if (auto_tolov == 0) {
            txt_set_auto_tolov.setText(R.string.avto_yozilmaydi);
        } else if (auto_tolov == 1) {
            txt_set_auto_tolov.setText(R.string.naqdga_yoziladi);
        } else if (auto_tolov == 2) {
            txt_set_auto_tolov.setText(R.string.plastikka_yoziladi);
        } else if (auto_tolov == 3) {
            txt_set_auto_tolov.setText(R.string.bonusga_yoziladi);
        }

    }

    private void Foiz_dialog() {
        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_xizmat_foizi);
        dialog.setCancelable(true);
        dialog.setTitle("");


        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);
        final EditText edt_foiz = dialog.findViewById(R.id.edt_set_xizmat_foiz);

        double foiz = sharedPreferences.getFloat("foiz", -2);

        ArrayList<String> list = new ArrayList<>();
        list.add("");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);


        if (foiz == -2) {
            spinner.setSelection(0);
            spinner.setEnabled(false);
            swit.setChecked(false);
            edt_foiz.setEnabled(false);
            edt_foiz.setText("");
        } else {
            edt_foiz.setEnabled(true);
            edt_foiz.setTextColor(Color.BLACK);
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
            edt_foiz.setText(String.format("%s", foiz));
            edt_foiz.setSelection(edt_foiz.getText().toString().length());
        }

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    if (swit.isChecked()) {
                        edt_foiz.setEnabled(true);
                        edt_foiz.setTextColor(Color.BLACK);
                        edt_foiz.requestFocus();
                        edt_foiz.setSelection(edt_foiz.getText().toString().length());
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
                if (isChecked) {
                    edt_foiz.setEnabled(true);
                    edt_foiz.setTextColor(Color.BLACK);
                } else {

                    edt_foiz.setEnabled(false);
                    edt_foiz.setTextColor(Color.GRAY);
                }
            }
        });
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
//                    if (spinner.getSelectedItemPosition() == 0) {
//                        editor.putFloat("foiz", -1);
//                        editor.commit();
//                    } else
//                    if (spinner.getSelectedItemPosition() == 0) {
                    String foi = edt_foiz.getText().toString();
                    float so_son = 0;
                    if (!foi.equals("")) {
                        try {
                            so_son = Float.parseFloat(foi);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                        }
                    }
                    editor.putFloat("foiz", so_son);
                    editor.commit();
//                    }
                } else {
                    editor.putFloat("foiz", -2);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();

            }
        });

        dialog.show();
    }

    private void Tolov_auto_dialog() {
        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_tolov_auto);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int auto_tolov = sharedPreferences.getInt("auto_tolov", -1);
        ArrayList<String> list = new ArrayList<>();
        list.add(getString(R.string.naqdga_yoziladi));
        list.add(getString(R.string.plastikka_yoziladi));

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);
        if (auto_tolov == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (auto_tolov == 1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else if (auto_tolov == 2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(1);
        } else if (auto_tolov == 3) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(2);
        }
        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    int index = spinner.getSelectedItemPosition();
                    editor.putInt("auto_tolov", index + 1);
                    editor.commit();
                } else {
                    editor.putInt("auto_tolov", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

}
