package com.balance.smart_cash.Umumiy;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Admin.Admin_hisobot.Admin_hisob_shot_list;
import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Asosiy.Stol_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Menu.Menu_oyna;
import com.balance.smart_cash.Otdel.Otdel_oyna;
import com.balance.smart_cash.Print.Taom_pechat;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;
import com.balance.smart_cash.Security.Security_screen;
import com.balance.smart_cash.Taomlar.Taomlar_oyna;
import com.balance.smart_cash.Tolov.Tolov_oyna;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;
import com.ufreedom.uikit.FloatingText;
import com.yydcdut.sdlv.Menu;
import com.yydcdut.sdlv.MenuItem;
import com.yydcdut.sdlv.SlideAndDragListView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Umumiy_oyna extends FragmentActivity implements AdapterView.OnItemLongClickListener,
        AdapterView.OnItemClickListener, AbsListView.OnScrollListener,
        SlideAndDragListView.OnDragDropListener, SlideAndDragListView.OnSlideListener,
        SlideAndDragListView.OnMenuItemClickListener, SlideAndDragListView.OnItemDeleteListener,
        SlideAndDragListView.OnItemScrollBackListener {

    public static Context context;
    public static Activity activity;
    public static TextView txt_stol_nomer, txt_umum_summa, txt_umum_taom_soni;
    public static ArrayList<Umumiy_list> umumiy_lists = new ArrayList<>();
    public static ArrayList<String> tang_idlar = new ArrayList<>();
    public static ArrayList<Integer> tang_posit = new ArrayList<>();
    private Menu mMenu;
    public static SlideAndDragListView mListView;
    ImageView btn_ortga;
    Button btn_otdel, btn_menu, btn_taom;
    Umumiy_list list;
    FragmentTransaction fragment;
    static ImageView btn_tolov;
    static ImageView btn_pechat;
    public static String shot_asos = "", ofit_id_asos = "", ofit_ismi_umum = "", stol_nomer_asos, vaqti_asos = "";
    RelativeLayout layout;
    LinearLayout linearLayout;
    ImageView btn_yulduz, btn_umum_pop_ortga;
    public static int OTDEL_BORMI, MENU_BORMI, TAOM_PECHAT_BORMI, BEKOR_PRINT;
    SharedPreferences sharedPreferences;
    public static View view_umum_oq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.umumiy_oyna);
        context = Umumiy_oyna.this;
        activity = Umumiy_oyna.this;

        sharedPreferences = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        txt_stol_nomer = (TextView) findViewById(R.id.txt_umum_stol_nomer);
        txt_umum_taom_soni = (TextView) findViewById(R.id.txt_umum_taom_soni);
        txt_umum_summa = (TextView) findViewById(R.id.txt_umum_summa);
        btn_ortga = (ImageView) findViewById(R.id.btn_umum_oyna_ortga);
        view_umum_oq = findViewById(R.id.view_umum_oq);
        btn_taom = (Button) findViewById(R.id.btn_umum_taom);
        btn_menu = (Button) findViewById(R.id.btn_umum_menu);
        btn_pechat = (ImageView) findViewById(R.id.btn_umum_pechat);
        btn_tolov = (ImageView) findViewById(R.id.btn_umum_tolov);
        layout = (RelativeLayout) findViewById(R.id.layout_umum_btn);
        linearLayout = (LinearLayout) findViewById(R.id.layout_umum_ortga);
        btn_yulduz = (ImageView) findViewById(R.id.btn_umum_yulduz);
        btn_umum_pop_ortga = (ImageView) findViewById(R.id.btn_umum_pop_ortga);

        view_umum_oq.setVisibility(View.GONE);

        int yulduz_bormi = sharedPreferences.getInt("yulduz_bormi", 1);
        OTDEL_BORMI = sharedPreferences.getInt("otdel_bormi", 0);
        TAOM_PECHAT_BORMI = sharedPreferences.getInt("taom_print", 0);
        BEKOR_PRINT = sharedPreferences.getInt("bekor_print", 0);
        MENU_BORMI = sharedPreferences.getInt("menu_bormi", 1);
        if (yulduz_bormi == 1) {
            btn_yulduz.setVisibility(View.VISIBLE);
        } else {
            btn_yulduz.setVisibility(View.GONE);
        }
        btn_umum_pop_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Otdel_oyna());
                layout.setVisibility(View.VISIBLE);
                btn_yulduz.setVisibility(View.VISIBLE);
            }
        });

        btn_yulduz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.setVisibility(View.VISIBLE);
                changeFragment_taom(new Taomlar_oyna(), "yulduz");
//                linearLayout.setVisibility(View.VISIBLE);
            }
        });

        btn_tolov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tang_idlar.size() == 0) {
                    if (umumiy_lists.size() > 0) {
                        Intent intent = new Intent(Umumiy_oyna.this, Tolov_oyna.class);
                        startActivity(intent);
                    }
                } else {
                    Pechat_xabar(1);
                }
            }
        });

        linearLayout.setVisibility(View.GONE);
        layout.setVisibility(View.VISIBLE);

        btn_otdel = (Button) findViewById(R.id.btn_umum_otdel);
        Intent intent = getIntent();
        stol_nomer_asos = intent.getExtras().getString("stol");
        ofit_id_asos = intent.getExtras().getString("ofit");
        shot_asos = intent.getExtras().getString("shot");
        ofit_ismi_umum = intent.getExtras().getString("ismi");
        vaqti_asos = intent.getExtras().getString("vaqti");
        initMenu();
        initUiAndListener();
        if (stol_nomer_asos != null) {
            if (!stol_nomer_asos.equals("Saboy")) {
                txt_stol_nomer.setText(String.format(getString(R.string.umum_stol_soz), stol_nomer_asos, ofit_ismi_umum));
            } else {
                txt_stol_nomer.setText(R.string.saboy);
            }
        }
        if (!shot_asos.equals("yangi")) {
            String url = "";
            try {
                url = url_address + Urllar.Php_umum_olish + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_ZAKAZLAR, "UTF-8")
                        + "&shot_raqam=" + URLEncoder.encode(shot_asos, "UTF-8")
                        + "&vaqti=" + URLEncoder.encode(vaqti_asos, "UTF-8")
                        + "&ofit_id=" + URLEncoder.encode(ofit_id_asos.replace("'", "`"), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            Orqa_fon orqa_fon = new Orqa_fon(url);
            orqa_fon.execute();
        } else {
            umumiy_lists.clear();
        }

        btn_otdel.setVisibility(View.GONE);
        btn_menu.setVisibility(View.GONE);
        btn_taom.setVisibility(View.GONE);
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tang_idlar.clear();
        tang_posit.clear();
        if (OTDEL_BORMI != 0) {
            if (savedInstanceState == null) {
                changeFragment(new Otdel_oyna());
            }
        } else {
            if (MENU_BORMI == 1) {
                if (savedInstanceState == null) {
                    changeFragment(new Menu_oyna());
                }
            } else {
                if (savedInstanceState == null) {
                    changeFragment_taom(new Taomlar_oyna(), "");
                }
            }
        }

        btn_pechat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (umumiy_lists.size() > 0 && tang_idlar.size() > 0) {
                    Pechat_xabar(0);
                } else {

                }
            }
        });

    }

    public void Pechat_xabar(final int i) {
        String soz = "";
        if (TAOM_PECHAT_BORMI > 0) {
            soz = getString(R.string.pechat_qilmoqchimisiz);
        } else {
            soz = getString(R.string.buyurtmani_saqlamoqchimisiz);
        }
        new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setContentText(soz)
                .setCancelText(getString(R.string.yoq))
                .setConfirmText(getString(R.string.ha))
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(final SweetAlertDialog sDialog) {
                        sDialog.dismiss();
                        Orqa_Pechat orqa_pechat = new Orqa_Pechat(i);
                        orqa_pechat.execute();
                    }
                })
                .show();
    }


    class Orqa_Pechat extends AsyncTask<Void, String, String> {

        int qaysi = 0;
        ProgressDialog loading;

        public Orqa_Pechat(int qaysi) {
            this.qaysi = qaysi;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            String soz = "";
            if (TAOM_PECHAT_BORMI > 0) {
                soz = getString(R.string.pechat_qilinmoqda);
            } else {
                soz = getString(R.string.saqlanmoqda);
            }
            loading = ProgressDialog.show(Umumiy_oyna.this, soz, null, true, true);
        }

        @Override
        protected String doInBackground(Void... voids) {
            return Qogozga_chiqar();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
            if (!xatolik_soz.equals("")) {
                if (xatolik_soz.equals("off")) {
                    Toast.makeText(context, "Serverga ulanib bo'lmayapti!", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(getApplication(), xatolik_soz, Toast.LENGTH_SHORT).show();
            }
            if (!stol_nomer_asos.equals("Saboy")) {

                Stol_oyna.Get_stol_Async get_stol_async = new Stol_oyna.Get_stol_Async(Umumiy_oyna.this);
                get_stol_async.execute();
            } else {
                Saboy1_oyna.Get_saboy_Async async = new Saboy1_oyna.Get_saboy_Async(Umumiy_oyna.this);
                async.execute();
            }
            String url = "";
            try {
                url = url_address + Urllar.Php_umum_olish + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_ZAKAZLAR, "UTF-8")
                        + "&shot_raqam=" + URLEncoder.encode(s, "UTF-8")
                        + "&vaqti=" + URLEncoder.encode(vaqti_asos, "UTF-8")
                        + "&ofit_id=" + URLEncoder.encode(ofit_id_asos.replace("'", "`"), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            Orqa_fon orqa_fon = new Orqa_fon(url);
            orqa_fon.execute();
            if (qaysi == 1) {
                Intent intent = new Intent(Umumiy_oyna.this, Tolov_oyna.class);
                startActivity(intent);
            }
        }
    }

    String xatolik_soz = "";
    String now_date;

    public String Qogozga_chiqar() {
        String shot_ra = "";
        if (umumiy_lists.size() > 0) {
            Calendar calendar = Calendar.getInstance();
            @SuppressLint("SimpleDateFormat") SimpleDateFormat form = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            @SuppressLint("SimpleDateFormat") SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
            String strDa = form.format(calendar.getTime());
            now_date = format2.format(calendar.getTime());
            if (shot_asos.equals("yangi")) {
                int shot = 0;
                  String url = "";
                try {
                    url = url_address + Urllar.Php_umum_shot_olish + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_SHOTLAR, "UTF-8")
                            + "&vaqti=" + URLEncoder.encode(now_date, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                BufferedReader read = null;
                HttpURLConnection connection = Connector.connection(url);
                if (connection == null) {
                    return context.getString(R.string.internetni_tekshir);
                }
                InputStream inputSt = null;

                String xatoli = "";
                try {
                    if (connection != null && Security_screen.isOnline(context)) {
                        inputSt = new BufferedInputStream(connection.getInputStream());
                        read = new BufferedReader(new InputStreamReader(inputSt));
                        String result = read.readLine();
                        if (result != null) {
                            JSONObject jsonObj = new JSONObject(result);
                            String query_result = jsonObj.getString("query_result");
                            if (query_result.equals("SUCCESS")) {
                                shot = jsonObj.getInt("shot_raqam");
                                shot++;
                            } else {
                                shot = 1;
                            }
                        }
                    }
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatoli = xatoli + " // " + e.getMessage();
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatoli = xatoli + " // " + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatoli = xatoli + " // " + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatoli = xatoli + " // " + e.getMessage();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatoli = xatoli + " // " + e.getMessage();
                } finally {
                    if (read != null) {
                        try {
                            read.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatoli = xatoli + " // " + e.getMessage();
                        }
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }
                    if (shot == 0) {
                        shot = 1;
                    }
                }


                shot_ra = String.valueOf(shot);

                shot_asos = shot_ra;
                vaqti_asos = strDa;
                if (!stol_nomer_asos.equals("Saboy")) {
                    String sql_5 = "INSERT INTO " + Login_oyna.TABLE_SHOTLAR + " VALUES(NULL, '" + shot_ra + "', '" + strDa + "', NULL, '" + ofit_ismi_umum.replace("'", "`") + "', '" + stol_nomer_asos + "', NULL )";
                    String url_delete = "";
                    try {
                        url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_5, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                    }

                    HttpURLConnection con = Connector.connection(url_delete);
                    BufferedReader reader = null;
                    InputStream inputStream = null;
                    String xatolikar = "";
                    try {
                        if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                            inputStream = new BufferedInputStream(con.getInputStream());
                            reader = new BufferedReader(new InputStreamReader(inputStream));
                            String result = reader.readLine();
                        }

                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } finally {
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolikar = xatolikar + " // " + e.getMessage();
                            }
                        }
                        if (con != null) {
                            con.disconnect();
                        }

                    }

                } else {
                    String sql_5 = "INSERT INTO " + Login_oyna.TABLE_SHOTLAR + " VALUES(NULL, '" + shot_ra + "', '" + strDa + "', NULL, 'saboy', '" + stol_nomer_asos + "', NULL )";
                    String url_delete = "";
                    try {
                        url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_5, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                    }

                    HttpURLConnection con = Connector.connection(url_delete);
                    BufferedReader reader = null;
                    InputStream inputStream = null;
                    String xatolikar = "";
                    try {
                        if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                            inputStream = new BufferedInputStream(con.getInputStream());
                            reader = new BufferedReader(new InputStreamReader(inputStream));
                            String result = reader.readLine();
                        }

                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } finally {
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolikar = xatolikar + " // " + e.getMessage();
                            }
                        }
                        if (con != null) {
                            con.disconnect();
                        }

                    }
                }
                if (!stol_nomer_asos.equals("Saboy")) {
                    String sql_4 = "INSERT INTO " + Login_oyna.TABLE_STOLLAR + " VALUES(NULL, '" + stol_nomer_asos + "', 0, '" + ofit_id_asos + "', '" + shot_ra + "', '" + strDa + "')";
                    String url_delete = "";
                    try {
                        url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_4, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                    }

                    HttpURLConnection con = Connector.connection(url_delete);
                    BufferedReader reader = null;
                    InputStream inputStream = null;
                    String xatolikar = "";
                    try {
                        if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                            inputStream = new BufferedInputStream(con.getInputStream());
                            reader = new BufferedReader(new InputStreamReader(inputStream));
                            String result = reader.readLine();
                        }

                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } finally {
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolikar = xatolikar + " // " + e.getMessage();
                            }
                        }
                        if (con != null) {
                            con.disconnect();
                        }

                    }
                }


            } else {
                shot_ra = shot_asos;
            }

            ArrayList<Umumiy_list> pech_qilina = new ArrayList<>();
            pech_qilina.clear();
            for (int i = 0; i < umumiy_lists.size(); i++) {
                Umumiy_list umumiy_list = umumiy_lists.get(i);
                String sotil_id = umumiy_list.getSotil_id();
                if (sotil_id.equals("")) {
                    String tov_id = umumiy_list.getTov_id();
                    String nomi = umumiy_list.getNomi();
                    String soni = umumiy_list.getSoni();
                    String narxi = umumiy_list.getNarxi().replace(" ", "");
                    String summa = umumiy_list.getUmum_summa().replace(" ", "");
                    String foizi = umumiy_list.getFoizi();
                    String print = umumiy_list.getPrinter();
                    String ofit_i = ofit_id_asos;

                    pech_qilina.add(umumiy_list);

                    String sql5 = "INSERT INTO " + Login_oyna.TABLE_ZAKAZLAR + " VALUES(NULL, '" + tov_id + "', '" + nomi + "', '" + narxi + "', '" + soni + "','" + summa + "', '" + foizi + "', '" + shot_ra + "', '" + ofit_i + "', '" + strDa + "', '" + print + "')";
                    String url_delete = "";
                    try {
                        url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql5, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                    }

                    HttpURLConnection con = Connector.connection(url_delete);
                    BufferedReader reader = null;
                    InputStream inputStream = null;
                    String xatolikar = "";
                    try {
                        if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                            inputStream = new BufferedInputStream(con.getInputStream());
                            reader = new BufferedReader(new InputStreamReader(inputStream));
                            String result = reader.readLine();
                        }

                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    } finally {
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolikar = xatolikar + " // " + e.getMessage();
                            }
                        }
                        if (con != null) {
                            con.disconnect();
                        }

                    }
                }

            }

            if (pech_qilina.size() > 0 && TAOM_PECHAT_BORMI == 1) {
                Collections.sort(pech_qilina, new Comparator<Umumiy_list>() {
                    @Override
                    public int compare(Umumiy_list s1, Umumiy_list s2) {
                        return s1.getPrinter().compareTo(s2.getPrinter());
                    }
                });
                String sto = "";
                if (!stol_nomer_asos.equals("Saboy")) {
                    sto = "" + stol_nomer_asos + "-" + getString(R.string.stol) + "\n";
                } else {
                    sto = "" + stol_nomer_asos + "\n";
                }
                String ismi = "";
                if (!stol_nomer_asos.equals("Saboy")) {
                    ismi = ofit_ismi_umum;
                } else {
                    ismi = "saboy";
                }

                String shot = shot_ra;
                if (shot.length() < 33) {
                    for (int l = shot.length(); l < 33; l++) {
                        shot = " " + shot;
                    }
                }
                String pechat_shapka = "";
                if (ismi.equals("Ofitsant yo'q")) {
                    pechat_shapka = "" +
                            "________________________________________________\n\n" +
                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                            " " + getString(R.string.vaqti) + ":                    " + strDa + "  \n" +
                            "________________________________________________\n";
                } else {
                    if (ismi.length() < 36) {
                        for (int i = ismi.length(); i < 36; i++) {
                            ismi = " " + ismi;
                        }
                    }
                    pechat_shapka = "" +
                            "________________________________________________\n\n" +
                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                            " " + getString(R.string.vaqti) + ":                    " + strDa + "  \n" +
                            " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                            "________________________________________________\n";
                }
                String print_id_eski = "";
                String print_eski = "";
                for (int i = 0; i < pech_qilina.size(); i++) {
                    Umumiy_list list = pech_qilina.get(i);
                    String prin_id = list.getPrinter();
                    if (!prin_id.equals(print_id_eski) && !print_id_eski.equals("")) {
                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + print_id_eski.trim() + "'");
                        if (cursor.getCount() != 0) {
                            cursor.moveToFirst();
                            String print_ip = cursor.getString(0);
                            xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, sto, pechat_shapka, print_eski);
                            print_eski = "";
                            String taom = list.getNomi();
                            String soni = list.getSoni();
                            if (taom.length() < 35) {
                                for (int j = taom.length(); j < 35; j++) {
                                    taom = taom + " ";
                                }
                            } else {
                                String taom_boshi = "" + taom.substring(0, 35) + "\n";
                                String oxir = taom.substring(35, taom.length());
                                if (oxir.length() < 35) {
                                    for (int j = oxir.length(); j < 35; j++) {
                                        oxir = oxir + " ";
                                    }
                                }
                                taom = taom_boshi + oxir;
                            }
                            if (soni.length() < 10) {
                                for (int k = soni.length(); k < 10; k++) {
                                    soni = soni + " ";
                                }
                            }
                            print_eski = print_eski + "\n " + taom + "  " + soni + "\n ";
                            print_id_eski = prin_id;
                        }
                    } else {
                        String taom = list.getNomi();
                        String soni = list.getSoni();
                        if (taom.length() < 35) {
                            for (int j = taom.length(); j < 35; j++) {
                                taom = taom + " ";
                            }
                        } else {
                            String taom_boshi = "" + taom.substring(0, 35) + "             \n ";
                            String oxir = taom.substring(35, taom.length());
                            if (oxir.length() < 35) {
                                for (int j = oxir.length(); j < 35; j++) {
                                    oxir = oxir + " ";
                                }
                            }
                            taom = taom_boshi + oxir;
                        }
                        if (soni.length() < 10) {
                            for (int k = soni.length(); k < 10; k++) {
                                soni = soni + " ";
                            }
                        }
                        print_eski = print_eski + "\n " + taom + "  " + soni + "\n";
                        print_id_eski = prin_id;
                    }
                }

                if (pech_qilina.size() > 0) {
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + print_id_eski.trim() + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, sto, pechat_shapka, print_eski);

                    }
                }

            }

        }
        return shot_ra;
    }

    class Orqa_fon extends AsyncTask<Void, String, String> {
        String sql;

        public Orqa_fon(String sql) {
            this.sql = sql;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {

            umumiy_lists.clear();
            tang_posit.clear();
            tang_idlar.clear();
            umum_summa = 0;
            HttpURLConnection con5 = Connector.connection(sql);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }
                                    if (tugadi) {
                                        String id = "";
                                        try {
                                            id = jsonObject.getString("id");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (id.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String tov_id = "";
                                            try {
                                                tov_id = jsonObject.getString("tov_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String nomi = "";
                                            try {
                                                nomi = jsonObject.getString("nomi");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String narxi = "";
                                            try {
                                                narxi = jsonObject.getString("narxi");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String soni = "";
                                            try {
                                                soni = jsonObject.getString("soni");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String summa = "";
                                            try {
                                                summa = jsonObject.getString("summa");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String foizi = "";
                                            try {
                                                foizi = jsonObject.getString("foizi");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String vaqti = "";
                                            try {
                                                vaqti = jsonObject.getString("vaqti");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String print = "";
                                            try {
                                                print = jsonObject.getString("print");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            umumiy_lists.add(new Umumiy_list(id, tov_id, nomi, soni, Bosh_oyna.getDecimalFormattedString(narxi), Bosh_oyna.getDecimalFormattedString(summa), foizi, vaqti, print));
                                            if (!summa.equals("")) {
                                                try {
                                                    int sum = Integer.parseInt(summa.replace(" ", ""));
                                                    umum_summa += sum;
                                                } catch (NumberFormatException w) {
                                                    w.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(w);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }
                return xatolik;
            }

            return "off";

        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
            if (s.equals("off")) {
                Toast.makeText(context, "Serverga ulanib bo'lmayapti!", Toast.LENGTH_SHORT).show();
            }
            txt_umum_taom_soni.setText(umumiy_lists.size() + "");
            txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umum_summa)));
            if (umumiy_lists.size() > 0) {
                mListView.smoothScrollToPositionFromTop(umumiy_lists.size() - 1, 10, 500);
            }
        }

    }

    int umum_summa = 0;


    public static BaseAdapter adapter = new BaseAdapter() {
        @Override
        public int getCount() {
            return umumiy_lists.size();
        }

        @Override
        public Object getItem(int position) {
            return umumiy_lists.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        class ViewHolder {
            TextView txt_id, txt_nomi, txt_print, txt_soni, txt_narxi, txt_summa, txt_sotil_id, txt_foizi, txt_vaqti;

            View layout;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {

            View row = view;
            ViewHolder holder = new ViewHolder();

            if (row == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                row = inflater.inflate(R.layout.umum_items, null);

                holder.txt_sotil_id = (TextView) row.findViewById(R.id.txt_umum_item_sotil_id);
                holder.txt_id = (TextView) row.findViewById(R.id.txt_umum_item_id);
                holder.txt_nomi = (TextView) row.findViewById(R.id.txt_umum_item_nomi);
                holder.txt_soni = (TextView) row.findViewById(R.id.txt_umum_item_soni);
                holder.txt_print = (TextView) row.findViewById(R.id.txt_umum_item_printer);
                holder.txt_narxi = (TextView) row.findViewById(R.id.txt_umum_item_narxi);
                holder.txt_summa = (TextView) row.findViewById(R.id.txt_umum_item_umum_summa);
                holder.txt_foizi = (TextView) row.findViewById(R.id.txt_umum_item_foizi);
                holder.txt_vaqti = (TextView) row.findViewById(R.id.txt_umum_item_vaqti);
                holder.layout = (View) row.findViewById(R.id.layout_umum_item);

                row.setTag(holder);
            } else {
                holder = (ViewHolder) row.getTag();
            }
            try {

                Umumiy_list qarzdorlar_list = umumiy_lists.get(position);

                holder.txt_sotil_id.setText(qarzdorlar_list.getSotil_id());
                holder.txt_id.setText(qarzdorlar_list.getTov_id());
                holder.txt_nomi.setText(qarzdorlar_list.getNomi());
                holder.txt_soni.setText(qarzdorlar_list.getSoni());
                holder.txt_print.setText(qarzdorlar_list.getPrinter());
                holder.txt_narxi.setText(Bosh_oyna.getDecimalFormattedString(qarzdorlar_list.getNarxi()));
                holder.txt_foizi.setText(qarzdorlar_list.getFoizi());
                holder.txt_vaqti.setText(qarzdorlar_list.getVaqti());
                holder.txt_summa.setText(Bosh_oyna.getDecimalFormattedString(qarzdorlar_list.getUmum_summa()));
                if (!holder.txt_sotil_id.getText().toString().equals("")) {
                    holder.layout.setBackgroundColor(Color.rgb(172, 222, 241));
                } else {
                    holder.layout.setBackgroundColor(Color.rgb(255, 255, 255));
                }
            } catch (IndexOutOfBoundsException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            return row;
        }
    };

    public void Oyna_ochish(final String id, final String nomi, final String esk_soni, String narxi, final int position, final String sot_id, final String printer_id, final int holati) {

        final Dialog dialog = new Dialog(Umumiy_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.ozgart_oyna);
        dialog.setCancelable(false);
        dialog.setTitle(getString(R.string.o_zgartirish));

        Button btn_ortga = (Button) dialog.findViewById(R.id.btn_umum_ozg_ortga);
        Button btn_saqlash = (Button) dialog.findViewById(R.id.btn_umum_ozg_saqlash);
        Button btn_plus = (Button) dialog.findViewById(R.id.btn_umum_ozg_plus);
        Button btn_minus = (Button) dialog.findViewById(R.id.btn_umum_ozg_minus);
        final TextView txt_soni = (TextView) dialog.findViewById(R.id.txt_umum_ozg_soni);
        final TextView txt_narxi = (TextView) dialog.findViewById(R.id.txt_umum_ozg_narxi);
        final TextView txt_nomi = (TextView) dialog.findViewById(R.id.txt_umum_ozg_nomi);

        txt_soni.setText(esk_soni);
        txt_nomi.setText(nomi);
        txt_narxi.setText(String.format(getString(R.string.ozgar_som), narxi));

        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String soni = txt_soni.getText().toString();
                if (!soni.equals("")) {
                    int eski_soni = 0;
                    try {
                        eski_soni = Integer.parseInt(soni);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                    }
                    if (eski_soni > 0) {
                        eski_soni--;
                        txt_soni.setText(String.valueOf(eski_soni));
                    }
                }
            }
        });
        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String soni = txt_soni.getText().toString();
                if (!soni.equals("")) {
                    int eski_soni = 0;
                    try {
                        eski_soni = Integer.parseInt(soni);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                    }
                    int eski = 0;
                    try {
                        eski = Integer.parseInt(esk_soni);
                    } catch (NumberFormatException r) {
                        r.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(r);
                    }
                    eski_soni++;

                    if (holati == 1) {
                        if (eski_soni <= eski) {
                            txt_soni.setText(String.valueOf(eski_soni));
                        }
                    } else {
                        txt_soni.setText(String.valueOf(eski_soni));
                    }
                }

            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String soni = txt_soni.getText().toString();

                if (!soni.equals("")) {

                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat form = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    final String ochgan_sana = form.format(calendar.getTime());
                    final String narxi = txt_narxi.getText().toString().replace(" ", "");

                    if (!soni.equals("0")) {
                        dialog.cancel();
                        uiHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                Orqa_ozgartirish orqa_ozgartirish = new Orqa_ozgartirish(position, soni, esk_soni, holati, ochgan_sana, nomi, printer_id,narxi);
                                orqa_ozgartirish.execute();
                            }
                        });

                    } else {

                        new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                .setTitleText(getString(R.string.ogohlantirish))
                                .setContentText(getString(R.string.taomdan_o_ta_tanlayapsiz_ochirilsinmi))
                                .setCancelText(getString(R.string.yoq_ochirilmasin))
                                .setConfirmText(getString(R.string.ha_ochirilsin))
                                .showCancelButton(true)
                                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        // reuse previous dialog instance, keep widget user state, reset them if you need
                                        sDialog.cancel();
                                    }
                                })
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(final SweetAlertDialog sDialog) {
                                        sDialog.cancel();
                                        dialog.cancel();
                                        uiHandler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                String narxi = txt_narxi.getText().toString().replace(" ", "");

                                                Orqa_ozgar_ochir orqa_ozgartirish = new Orqa_ozgar_ochir(position, id, esk_soni, holati, ochgan_sana, nomi, printer_id,narxi);
                                                orqa_ozgartirish.execute();
                                            }
                                        });

                                    }
                                })
                                .show();
                    }
                }
//                } else {
//                    dialog.cancel();
//                }
                txt_umum_taom_soni.setText(umumiy_lists.size() + "");
            }
        });
        dialog.show();
    }

    @Override
    public void onBackPressed() {
//        Stol_oyna.Get_stol();
        if (tang_idlar.size() > 0 && umumiy_lists.size() > 0) {
            Xabar();
        } else {
            finish();
//            if (!stol_nomer_asos.equals("Saboy")) {
//
//                Stol_oyna.Get_stol_Async get_stol_async = new Stol_oyna.Get_stol_Async(Umumiy_oyna.this);
//                get_stol_async.execute();
//            } else {
//                Saboy1_oyna.Get_saboy_Async async = new Saboy1_oyna.Get_saboy_Async(Umumiy_oyna.this);
//                async.execute();
//            }
        }
    }

    public void Xabar() {
        new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.ogohlantirish))
                .setContentText(getString(R.string.chiqishni_hohlaysizmi))
                .setCancelText(getString(R.string.yoq))
                .setConfirmText(getString(R.string.ha))
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.cancel();
                        finish();
                        if (!stol_nomer_asos.equals("Saboy")) {

                            Stol_oyna.Get_stol_Async get_stol_async = new Stol_oyna.Get_stol_Async(Umumiy_oyna.this);
                            get_stol_async.execute();
                        } else {
                            Saboy1_oyna.Get_saboy_Async async = new Saboy1_oyna.Get_saboy_Async(Umumiy_oyna.this);
                            async.execute();
                        }
                    }
                })
                .show();
    }


    public void initMenu() {
        mMenu = new Menu(true);
        mMenu.addItem(new MenuItem.Builder().setWidth((int) getResources().getDimension(R.dimen.slv_item_bg_btn_width) + 30)
                .setBackground(Utils.getDrawable(Umumiy_oyna.this, R.drawable.btn_right0))
                .setDirection(MenuItem.DIRECTION_LEFT)
                .setTextColor(Color.BLACK)
                .setTextSize(14)
                .setIcon(getResources().getDrawable(R.drawable.delete_umum))
                .build());
        mMenu.addItem(new MenuItem.Builder().setWidth((int) getResources().getDimension(R.dimen.slv_item_bg_btn_width_img))
                .setBackground(Utils.getDrawable(Umumiy_oyna.this, R.drawable.btn_left1))
                .setDirection(MenuItem.DIRECTION_RIGHT)
                .setTextColor(Color.BLACK)
                .setIcon(getResources().getDrawable(R.drawable.edit_umum))
                .build());
    }


    public void initUiAndListener() {
        mListView = (SlideAndDragListView) findViewById(R.id.lv_edit);
        mListView.setMenu(mMenu);
        mListView.setAdapter(adapter);
        mListView.setOnScrollListener(this);
        mListView.setOnDragDropListener(null);
        mListView.setOnItemClickListener(this);
        mListView.setOnSlideListener(this);
        mListView.setOnMenuItemClickListener(this);
        mListView.setOnItemDeleteListener(this);
        mListView.setOnItemLongClickListener(this);
        mListView.setOnItemScrollBackListener(this);
    }

    public static void Mal_qoshish(String tov_id, String nomi, String narxi, String fozi, String printer) {
        int indez = tang_idlar.indexOf(tov_id);
        if (!narxi.equals("")) {
            int narx = 0;
            int umu_narx = 0;
            if (!txt_umum_summa.getText().toString().equals("")) {
                try {
                    umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
            }
            try {

                narx = Integer.parseInt(narxi.replace(" ", ""));
                final FloatingText translateFloatingText = new FloatingText.FloatingTextBuilder(activity)
                        .textColor(Color.RED)
                        .textSize(50)
                        .textContent("+" + Bosh_oyna.getDecimalFormattedString(narxi))
                        .build();
                translateFloatingText.attach2Window();
                translateFloatingText.startFloating(txt_umum_summa);
                umu_narx = umu_narx + narx;
                txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
        }
        if (indez > -1) {
            int index = tang_posit.get(indez);
            Umumiy_list umumiy_list = umumiy_lists.get(index);
            String eski_soni = umumiy_list.getSoni();
            String narx = umumiy_list.getNarxi();
            int eeskisi = 0;
            int es_narx = 0;
            int umu_sum = 0;
            try {
                eeskisi = Integer.parseInt(eski_soni.replace(" ", ""));
                es_narx = Integer.parseInt(narx.replace(" ", ""));
                eeskisi++;
                umu_sum = eeskisi * es_narx;
            } catch (NumberFormatException w) {
                w.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(w);
            }
            umumiy_lists.get(index).setSoni(String.valueOf(eeskisi));
            umumiy_lists.get(index).setUmum_summa(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_sum)));

            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }

            View txt = getViewByPosition(index, mListView);
            if (txt != null) {
                final FloatingText translateFloatingText = new FloatingText.FloatingTextBuilder(activity)
                        .textColor(Color.RED)
                        .textSize(50)
                        .textContent("+1")
                        .build();
                translateFloatingText.attach2Window();
                TextView txt_son = (TextView) txt.findViewById(R.id.txt_umum_item_soni);
                translateFloatingText.startFloating(txt_son);
                int h1 = mListView.getHeight();
                int h2 = mListView.getChildAt(0).getHeight();

                mListView.smoothScrollToPositionFromTop(index, h1 / 2 - h2 / 2, 500);
            }
        } else {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String strDate = format.format(calendar.getTime());
            umumiy_lists.add(new Umumiy_list("", tov_id, nomi, "1", narxi, narxi, fozi, strDate, printer));
            tang_idlar.add(tov_id);
            tang_posit.add(umumiy_lists.size() - 1);

            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
            if (umumiy_lists.size() > 0) {
                mListView.smoothScrollToPositionFromTop(umumiy_lists.size() - 1, 10, 500);
            }
        }

        txt_umum_taom_soni.setText(umumiy_lists.size() + "");
    }

    public static View getViewByPosition(int position, ListView listView) {
        final int firstListItemPosition = listView.getFirstVisiblePosition();
        final int lastListItemPosition = firstListItemPosition + listView.getChildCount() - 1;

        if (position < firstListItemPosition || position > lastListItemPosition) {
            return listView.getAdapter().getView(position, null, listView);
        } else {
            final int childIndex = position - firstListItemPosition;
            return listView.getChildAt(childIndex);
        }
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }

    public void changeFragment_taom(Fragment targetFragment, String nomi) {
        Bundle bundle = new Bundle();
        bundle.putString("otdel", nomi);
        targetFragment.setArguments(bundle);

        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }

    @Override
    public void onDragViewStart(int beginPosition) {
        list = umumiy_lists.get(beginPosition);
    }

    @Override
    public void onDragDropViewMoved(int fromPosition, int toPosition) {
//        Umumiy_list applicationInfo = umumiy_lists.remove(fromPosition);
//        umumiy_lists.add(toPosition, applicationInfo);
    }

    @Override
    public void onDragViewDown(int finalPosition) {
        umumiy_lists.set(finalPosition, list);
    }

    @Override
    public void onSlideOpen(View view, View parentView, int position, int direction) {
    }

    @Override
    public void onSlideClose(View view, View parentView, int position, int direction) {
//        toast("onSlideClose   position--->" + position + "  direction--->" + direction);
    }

    String sot_id = "";
    TextView txt_um_summ, txt_vaqti, txt_print, txt_narxi, txt_soni, txt_nomi, txt_id, txt_sot_id;

    @Override
    public int onMenuItemClick(View vi, final int itemPosition, int buttonPosition, int direction) {
//        toast("onMenuItemClick   itemPosition--->" + itemPosition + "  buttonPosition-->" + buttonPosition + "  direction-->" + direction);
        View txt = getViewByPosition(itemPosition, mListView);
        View view = txt.findViewById(R.id.layout_umum_item);
        txt_sot_id = (TextView) view.findViewById(R.id.txt_umum_item_sotil_id);
        sot_id = txt_sot_id.getText().toString();

        txt_id = (TextView) view.findViewById(R.id.txt_umum_item_id);
        txt_nomi = (TextView) view.findViewById(R.id.txt_umum_item_nomi);
        txt_soni = (TextView) view.findViewById(R.id.txt_umum_item_soni);
        txt_narxi = (TextView) view.findViewById(R.id.txt_umum_item_narxi);
        txt_print = (TextView) view.findViewById(R.id.txt_umum_item_printer);
        txt_vaqti = (TextView) view.findViewById(R.id.txt_umum_item_vaqti);
        txt_um_summ = (TextView) view.findViewById(R.id.txt_umum_item_umum_summa);
        final String id = txt_id.getText().toString();
        final String nomi = txt_nomi.getText().toString();
        //Update
        if (sot_id.equals("")) {
            switch (direction) {
                case MenuItem.DIRECTION_LEFT:
                    switch (buttonPosition) {
                        case 0:

                            new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                    .setContentText(getString(R.string.ushbu_taomni_ochirmoqchimisiz))
                                    .setCancelText(getString(R.string.yoq))
                                    .setConfirmText(getString(R.string.ha))
                                    .showCancelButton(true)
                                    .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            // reuse previous dialog instance, keep widget user state, reset them if you need

                                            sDialog.cancel();

                                        }
                                    })
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(final SweetAlertDialog sDialog) {
                                            String umu_sum = txt_um_summ.getText().toString();
                                            int qosh_summa;
                                            if (!umu_sum.equals("")) {
                                                try {
                                                    qosh_summa = Integer.parseInt(umu_sum.replace(" ", ""));
                                                    int umu_narx = 0;
                                                    if (!txt_umum_summa.getText().toString().equals("")) {
                                                        try {
                                                            umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                                                            umu_narx = umu_narx - qosh_summa;
                                                            txt_umum_summa.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                                                        } catch (NumberFormatException e) {
                                                            e.printStackTrace();
                                                            Login_oyna.XATOLIK_YOZISH(e);
                                                        }
                                                    }
                                                } catch (NumberFormatException r) {
                                                    r.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(r);
                                                }
                                            }
                                            int index = tang_idlar.indexOf(txt_id.getText().toString());
                                            try {
                                                tang_idlar.remove(index);
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            try {
                                                tang_posit.remove(tang_idlar.size());
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            try {
                                                umumiy_lists.remove(itemPosition);
                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            try {
                                                adapter.notifyDataSetChanged();
                                            } catch (IllegalStateException e) {
                                                e.printStackTrace();
                                            }

                                            txt_umum_taom_soni.setText(umumiy_lists.size() + "");
                                            sDialog.cancel();
                                        }
                                    })
                                    .show();
                            return Menu.ITEM_NOTHING;
                    }
                    break;
                case MenuItem.DIRECTION_RIGHT:
                    switch (buttonPosition) {
                        case 0:
                            String soni = txt_soni.getText().toString();
                            String narxi = txt_narxi.getText().toString();
                            String print = txt_print.getText().toString();
                            Oyna_ochish(id, nomi, soni, narxi, itemPosition, sot_id, print, 0);
                            return Menu.ITEM_SCROLL_BACK;
                    }
            }
        } else {

            int ozgartirish = sharedPreferences.getInt("ozgartirish", 1);
            int ochirish = sharedPreferences.getInt("ochirish", 1);
            switch (direction) {
                case MenuItem.DIRECTION_LEFT:
                    switch (buttonPosition) {
                        case 0:
                            if (ochirish == 0) {
                                Bosh_oyna.OGOHLANTIRISH_XABAR(Umumiy_oyna.this, getString(R.string.ogohlantirish), getString(R.string.cheki_chiq_mal_ochir_yoq));
                            } else {
                                new SweetAlertDialog(Umumiy_oyna.this, SweetAlertDialog.WARNING_TYPE)
                                        .setContentText(getString(R.string.taom_cheki_chiqqan_ochirmoqchimisiz))
                                        .setCancelText(getString(R.string.yoq))
                                        .setConfirmText(getString(R.string.ha))
                                        .showCancelButton(true)
                                        .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                            @Override
                                            public void onClick(SweetAlertDialog sDialog) {
                                                // reuse previous dialog instance, keep widget user state, reset them if you need

                                                sDialog.cancel();

                                            }
                                        })
                                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                            @Override
                                            public void onClick(final SweetAlertDialog sDialog) {
                                                uiHandler.post(new Runnable() {
                                                    public void run() {

                                                        sDialog.cancel();
                                                        //Do whatever you want here...
                                                        //You will have looper.prepare here, as it will run on main thread as soon as possible.
                                                        Orqa_ochirish orqa_ochirish = new Orqa_ochirish(itemPosition);
                                                        orqa_ochirish.execute();
                                                    }
                                                });

                                            }
                                        })
                                        .show();
                                return Menu.ITEM_NOTHING;
                            }
                    }
                    break;
                case MenuItem.DIRECTION_RIGHT:
                    switch (buttonPosition) {
                        case 0:
                            if (ozgartirish == 0) {
                                Bosh_oyna.OGOHLANTIRISH_XABAR(Umumiy_oyna.this, getString(R.string.ogohlantirish), getString(R.string.cheki_chiqqanni_ozgartira_olmaysiz));
                            } else {
                                String soni = txt_soni.getText().toString();
                                String narxi = txt_narxi.getText().toString();
                                String print = txt_print.getText().toString();
                                Oyna_ochish(id, nomi, soni, narxi, itemPosition, sot_id, print, 1);
                            }
                            return Menu.ITEM_SCROLL_BACK;
                    }
            }
        }
        return Menu.ITEM_NOTHING;
    }

    final Handler uiHandler = new Handler();

    class Orqa_ochirish extends AsyncTask<Void, String, Void> {

        int itemPosition;

        public Orqa_ochirish(int itemPosition) {
            this.itemPosition = itemPosition;
        }

        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(Umumiy_oyna.this);
            dialog.setTitle(getString(R.string.iltimos_tekshirilmoqda));
            dialog.setCancelable(false);
            dialog.setIndeterminate(true);
            dialog.show();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            if (values[0].equals("1")) {
                txt_umum_summa.setText(values[1]);
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            String umu_sum = txt_um_summ.getText().toString();
            final String id = txt_id.getText().toString();
            final String nomi = txt_nomi.getText().toString();
            int qosh_summa;
            if (!umu_sum.equals("")) {
                try {
                    qosh_summa = Integer.parseInt(umu_sum.replace(" ", ""));
                    int umu_narx = 0;
                    if (!txt_umum_summa.getText().toString().equals("")) {
                        try {
                            umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                            umu_narx = umu_narx - qosh_summa;
                            publishProgress("1", Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                        }
                    }
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
            }
            String ismi = "";
            if (!stol_nomer_asos.equals("Saboy")) {
                ismi = ofit_ismi_umum;
            } else {
                ismi = "saboy";
            }
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat form = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            SimpleDateFormat form_1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String ochgan_sana = form.format(calendar.getTime());
            String ochgan_sa = form_1.format(calendar.getTime());

            String sql_in = "INSERT INTO " + Login_oyna.TABLE_OTMEN_TAOMLAR + " VALUES(NULL, '" + id + "', '" + nomi + "', '" + txt_soni.getText().toString() + "', '" + txt_vaqti.getText().toString() + "', '" + ochgan_sa + "', '" + shot_asos + "', '" + stol_nomer_asos + "', '" + ismi + "', '" + Login_oyna.foydalanuvhi_id + "' )";
            String sql_1 = "DELETE FROM " + Login_oyna.TABLE_ZAKAZLAR + " WHERE Id ='" + sot_id + "'";
            String url_delete = "", url_add_2 = "";
            try {
                url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_1, "UTF-8");
                url_add_2 = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_in, "UTF-8");

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            HttpURLConnection con = Connector.connection(url_delete);
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            InputStream inputStream = null;
            String xatolikar = "";
            try {
                if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                    inputStream = new BufferedInputStream(con.getInputStream());
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    String result = reader.readLine();
                }
                connection = Connector.connection(url_add_2);
                if (connection != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                    inputStream = new BufferedInputStream(connection.getInputStream());
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    String result = reader.readLine();
                }
                if (connection != null) {
                    connection.disconnect();
                }

            } catch (UnknownHostException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
                xatolikar = xatolikar + " // " + e.getMessage();
            } catch (SocketException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
                xatolikar = xatolikar + " // " + e.getMessage();
            } catch (SocketTimeoutException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
                xatolikar = xatolikar + " // " + e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
                xatolikar = xatolikar + " // " + e.getMessage();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolikar = xatolikar + " // " + e.getMessage();
                    }
                }
                if (con != null) {
                    con.disconnect();
                }

                if (connection != null) {
                    connection.disconnect();
                }
            }

            try {
                umumiy_lists.remove(itemPosition);
            } catch (ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            if (BEKOR_PRINT != 0) {
                String BEKOR_SOZ = getString(R.string.bekor_qilindi);

                if (ismi.length() < 36) {
                    for (int i = ismi.length(); i < 36; i++) {
                        ismi = " " + ismi;
                    }
                }
                String shot = shot_asos;
                if (shot.length() < 33) {
                    for (int l = shot.length(); l < 33; l++) {
                        shot = " " + shot;
                    }
                }
                String pechat_shapka = "" +
                        "________________________________________________\n\n" +
                        " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                        " " + getString(R.string.buyur_vaqti) + ":           " + txt_vaqti.getText().toString() + "  \n" +
                        " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                        " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                        " " + getString(R.string.buyur_soni) + ":          " + txt_soni.getText().toString() + "  \n" +
                        "________________________________________________\n";
                String taom_nomi = nomi;
                if (taom_nomi.length() < 35) {
                    for (int j = taom_nomi.length(); j < 35; j++) {
                        taom_nomi = taom_nomi + " ";
                    }
                }
                String taom = "\n " + taom_nomi + "  " + txt_soni.getText().toString() + "\n";

                if (BEKOR_PRINT == -1) {
                    Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE nomi = 'Kassa'");
                    if (cursor1.getCount() != 0) {
                        cursor1.moveToFirst();
                        String print_ip = cursor1.getString(0);
                        xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + txt_print.getText().toString().trim() + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                } else if (BEKOR_PRINT == -2) {

                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + txt_print.getText().toString().trim() + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                } else {
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + BEKOR_PRINT + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
            txt_umum_taom_soni.setText(umumiy_lists.size() + "");

        }
    }

    class Orqa_ozgartirish extends AsyncTask<Void, String, Void> {

        int position;
        String soni;
        String esk_soni;
        int holati;
        String ochgan_sana;
        String nomi;
        String printer_id;
        String narxi;
        public Orqa_ozgartirish(int position, String soni, String esk_soni, int holati, String ochgan_sana, String nomi, String printer_id,String narxi) {
            this.position = position;
            this.soni = soni;
            this.esk_soni = esk_soni;
            this.holati = holati;
            this.ochgan_sana = ochgan_sana;
            this.nomi = nomi;
            this.printer_id = printer_id;
            this.narxi = narxi;
        }

        ProgressDialog dialog;

        @Override
        protected Void doInBackground(Void... voids) {

            int narx = 0, son = 0, eski_soni = 0, qosh_son = 0, qosh_summa = 0, umum = 0;
            if (!narxi.equals("")) {
                try {
                    narx = Integer.parseInt(narxi.substring(0, narxi.length() - 4));
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
                try {
                    son = Integer.parseInt(soni);
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
                try {
                    eski_soni = Integer.parseInt(esk_soni.replace(" ", ""));
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
                qosh_son = son - eski_soni;
                qosh_summa = qosh_son * narx;
                int umu_narx = 0;
                try {
                    if (!txt_umum_summa.getText().toString().equals("")) {
                        try {
                            umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                            umu_narx = umu_narx + qosh_summa;
                            publishProgress("1", Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                        }
                    }
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
                umum = narx * son;
                umumiy_lists.get(position).setUmum_summa(Bosh_oyna.getDecimalFormattedString(String.valueOf(umum)));
            }

            if (holati == 1) {

                Umumiy_list u = umumiy_lists.get(position);
                String tov_id = u.getTov_id();
                String vaqti = u.getVaqti();
                String och_Soni = "";
                if (qosh_son < 0) {
                    och_Soni = "" + (qosh_son * (-1));
                } else {
                    och_Soni = "" + qosh_son;
                }
                String ofit_s = "";
                if (!ofit_id_asos.equals("Saboy")) {
                    ofit_s = ofit_ismi_umum;
                } else {
                    ofit_s = "saboy";
                }
                String sql_in = "INSERT INTO " + Login_oyna.TABLE_OTMEN_TAOMLAR + " VALUES(NULL, '" + tov_id + "', '" + txt_nomi.getText().toString() + "', '" + och_Soni + "', '" + vaqti + "', '" + ochgan_sana + "', '" + shot_asos + "', '" + stol_nomer_asos + "', '" + ofit_s + "', '" + Login_oyna.foydalanuvhi_id + "' )";
                String sql_1 = "UPDATE " + Login_oyna.TABLE_ZAKAZLAR + " SET soni = '" + soni + "', summasi = '" + Bosh_oyna.getDecimalFormattedString(String.valueOf(umum)) + "' WHERE Id = '" + sot_id + "'";

                String url_delete = "", url_add_2 = "";
                try {
                    url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_1, "UTF-8");
                    url_add_2 = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_in, "UTF-8");

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con = Connector.connection(url_delete);
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                InputStream inputStream = null;
                String xatolikar = "";
                try {
                    if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                        inputStream = new BufferedInputStream(con.getInputStream());
                        reader = new BufferedReader(new InputStreamReader(inputStream));
                        String result = reader.readLine();
                    }
                    connection = Connector.connection(url_add_2);
                    if (connection != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                        inputStream = new BufferedInputStream(connection.getInputStream());
                        reader = new BufferedReader(new InputStreamReader(inputStream));
                        String result = reader.readLine();
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }

                } catch (UnknownHostException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolikar = xatolikar + " // " + e.getMessage();
                        }
                    }
                    if (con != null) {
                        con.disconnect();
                    }

                    if (connection != null) {
                        connection.disconnect();
                    }
                }

                if (BEKOR_PRINT != 0) {
                    String BEKOR_SOZ = getString(R.string.bekor_qilindi);
                    String ismi = ofit_s;

                    String shot = shot_asos;
                    if (shot.length() < 33) {
                        for (int l = shot.length(); l < 33; l++) {
                            shot = " " + shot;
                        }
                    }
                    String pechat_shapka = "";
                    if (ismi.equals("Ofitsant yo'q")) {
                        pechat_shapka = "" +
                                "________________________________________________\n\n" +
                                " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                                " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                " " + getString(R.string.bekor_vaqti) + ":          " + esk_soni + "  \n" +
                                "________________________________________________\n";
                    } else {

                        if (ismi.length() < 36) {
                            for (int i = ismi.length(); i < 36; i++) {
                                ismi = " " + ismi;
                            }
                        }
                        pechat_shapka = "" +
                                "________________________________________________\n\n" +
                                " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                                " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                                " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                                " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                                " " + getString(R.string.bekor_vaqti) + ":          " + esk_soni + "  \n" +
                                "________________________________________________\n";
                    }
                    String taom_nomi = nomi;
                    if (taom_nomi.length() < 35) {
                        for (int j = taom_nomi.length(); j < 35; j++) {
                            taom_nomi = taom_nomi + " ";
                        }
                    }
                    String taom = "\n " + taom_nomi + "  " + och_Soni + "    \n";

                    if (BEKOR_PRINT == -1) {
                        Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE nomi = 'Kassa'");
                        if (cursor1.getCount() != 0) {
                            cursor1.moveToFirst();
                            String print_ip = cursor1.getString(0);
                            xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                        }
                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + printer_id.trim() + "'");
                        if (cursor.getCount() != 0) {
                            cursor.moveToFirst();
                            String print_ip = cursor.getString(0);
                            xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                        }
                    } else if (BEKOR_PRINT == -2) {

                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + printer_id.trim() + "'");
                        if (cursor.getCount() != 0) {
                            cursor.moveToFirst();
                            String print_ip = cursor.getString(0);
                            xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                        }
                    } else {
                        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + BEKOR_PRINT + "'");
                        if (cursor.getCount() != 0) {
                            cursor.moveToFirst();
                            String print_ip = cursor.getString(0);
                            xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                        }
                    }
                }
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(Umumiy_oyna.this);
            dialog.setTitle(getString(R.string.iltimos_tekshirilmoqda));
            dialog.setCancelable(false);
            dialog.setIndeterminate(true);
            dialog.show();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            if (values[0].equals("1")) {
                txt_umum_summa.setText(values[1]);
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            umumiy_lists.get(position).setSoni(soni);
            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
            txt_umum_taom_soni.setText(umumiy_lists.size() + "");


        }
    }

    class Orqa_ozgar_ochir extends AsyncTask<Void, String, Void> {

        int position;
        String soni;
        String esk_soni;
        int holati;
        String ochgan_sana;
        String nomi;
        String printer_id;
        String narxi;

        public Orqa_ozgar_ochir(int position, String soni, String esk_soni, int holati, String ochgan_sana, String nomi, String printer_id,String narxi) {
            this.position = position;
            this.soni = soni;
            this.esk_soni = esk_soni;
            this.holati = holati;
            this.ochgan_sana = ochgan_sana;
            this.nomi = nomi;
            this.printer_id = printer_id;
            this.narxi = narxi;
        }

        ProgressDialog dialog;

        @Override
        protected Void doInBackground(Void... voids) {
             int narx = 0, son = 0, eski_soni = 0, qosh_son = 0, qosh_summa;
            int umu_narx = 0;

            if (!narxi.equals("")) {
                try {
                    narx = Integer.parseInt(narxi.substring(0, narxi.length() - 4));
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
                try {
                    eski_soni = Integer.parseInt(esk_soni.replace(" ", ""));
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
                try {
                    qosh_son = son - eski_soni;
                    qosh_summa = qosh_son * narx;
                    if (!txt_umum_summa.getText().toString().equals("")) {
                        try {
                            umu_narx = Integer.parseInt(txt_umum_summa.getText().toString().replace(" ", ""));
                            umu_narx = umu_narx + qosh_summa;
                            publishProgress("1", Bosh_oyna.getDecimalFormattedString(String.valueOf(umu_narx)));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                        }
                    }
                } catch (NumberFormatException r) {
                    r.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(r);
                }
            }
            if (holati == 1) {

                Umumiy_list u = umumiy_lists.get(position);
                String tov_id = u.getTov_id();
                String vaqti = u.getVaqti();
                String ismi = "";
                if (stol_nomer_asos.equals("Saboy")) {
                    ismi = "saboy";
                } else {
                    ismi = ofit_ismi_umum;
                }

                String sql_1 = "DELETE FROM " + Login_oyna.TABLE_ZAKAZLAR + " WHERE Id = '" + sot_id + "'";
                String sql_in = "INSERT INTO " + Login_oyna.TABLE_OTMEN_TAOMLAR + " VALUES(NULL, '" + tov_id + "', '" + txt_nomi.getText().toString() + "', '" + esk_soni + "', '" + vaqti + "', '" + ochgan_sana + "', '" + shot_asos + "', '" + stol_nomer_asos + "', '" + ismi + "', '" + Login_oyna.foydalanuvhi_id + "' )";
                String url_delete = "", url_add_2 = "";
                try {
                    url_delete = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_1, "UTF-8");
                    url_add_2 = url_address + Urllar.Php_query_data + ".php?sql=" + URLEncoder.encode(sql_in, "UTF-8");

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con = Connector.connection(url_delete);
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                InputStream inputStream = null;
                String xatolikar = "";
                try {
                    if (con != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                        inputStream = new BufferedInputStream(con.getInputStream());
                        reader = new BufferedReader(new InputStreamReader(inputStream));
                        String result = reader.readLine();
                    }
                    connection = Connector.connection(url_add_2);
                    if (connection != null && Security_screen.isOnline(Umumiy_oyna.this)) {
                        inputStream = new BufferedInputStream(connection.getInputStream());
                        reader = new BufferedReader(new InputStreamReader(inputStream));
                        String result = reader.readLine();
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }

                } catch (UnknownHostException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolikar = xatolikar + " // " + e.getMessage();
                        }
                    }
                    if (con != null) {
                        con.disconnect();
                    }

                    if (connection != null) {
                        connection.disconnect();
                    }
                }

                String BEKOR_SOZ = getString(R.string.bekor_qilindi);

                String shot = shot_asos;
                if (shot.length() < 33) {
                    for (int l = shot.length(); l < 33; l++) {
                        shot = " " + shot;
                    }
                }
                String pechat_shapka = "";
                if (ismi.equals("Ofitsant yo'q")) {
                    pechat_shapka = "" +
                            "________________________________________________\n\n" +
                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                            " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                            " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                            " " + getString(R.string.buyur_soni) + ":          " + esk_soni + "  \n" +
                            "________________________________________________\n";
                } else {

                    if (ismi.length() < 36) {
                        for (int i = ismi.length(); i < 36; i++) {
                            ismi = " " + ismi;
                        }
                    }
                    pechat_shapka = "" +
                            "________________________________________________\n\n" +
                            " " + getString(R.string.shot_raqam) + ": " + shot + "  \n" +
                            " " + getString(R.string.buyur_vaqti) + ":           " + vaqti + "  \n" +
                            " " + getString(R.string.bekor_vaqti) + ":              " + ochgan_sana + "  \n" +
                            " " + getString(R.string.admin_ofitsant) + ":" + ismi + "  \n" +
                            " " + getString(R.string.buyur_soni) + ":          " + esk_soni + "  \n" +
                            "________________________________________________\n";
                }

                String taom_nomi = nomi;
                if (taom_nomi.length() < 35) {
                    for (int j = taom_nomi.length(); j < 35; j++) {
                        taom_nomi = taom_nomi + " ";
                    }
                }
                String taom = "\n " + taom_nomi + "  " + esk_soni + "\n";

                if (BEKOR_PRINT == -1) {
                    Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE nomi = 'Kassa'");
                    if (cursor1.getCount() != 0) {
                        cursor1.moveToFirst();
                        String print_ip = cursor1.getString(0);
                        xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + printer_id.trim() + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz += "\n" + Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                } else if (BEKOR_PRINT == -2) {

                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + printer_id.trim() + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                } else {
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + BEKOR_PRINT + "'");
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String print_ip = cursor.getString(0);
                        xatolik_soz = Taom_pechat.Pechat_qilish(print_ip, BEKOR_SOZ, pechat_shapka, taom);
                    }
                }

            } else {
                int index = tang_idlar.indexOf(soni);
                try {
                    tang_idlar.remove(index);
                } catch (ArrayIndexOutOfBoundsException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                try {
                    tang_posit.remove(index);
                } catch (ArrayIndexOutOfBoundsException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(Umumiy_oyna.this);
            dialog.setTitle(getString(R.string.iltimos_tekshirilmoqda));
            dialog.setCancelable(false);
            dialog.setIndeterminate(true);
            dialog.show();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            if (values[0].equals("1")) {
                txt_umum_summa.setText(values[1]);
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            umumiy_lists.remove(position);

            try {
                adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
            txt_umum_taom_soni.setText(umumiy_lists.size() + "");


        }
    }

    @Override
    public void onItemDeleteAnimationFinished(View view, int position) {
        umumiy_lists.remove(position - mListView.getHeaderViewsCount());
        try {
            adapter.notifyDataSetChanged();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        txt_umum_taom_soni.setText(umumiy_lists.size() + "");
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        switch (scrollState) {
            case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:
                break;
            case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                break;
            case AbsListView.OnScrollListener.SCROLL_STATE_FLING:
                break;
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount,
                         int totalItemCount) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        return false;
    }

    @Override
    public void onScrollBackAnimationFinished(View view, int position) {

    }
}
