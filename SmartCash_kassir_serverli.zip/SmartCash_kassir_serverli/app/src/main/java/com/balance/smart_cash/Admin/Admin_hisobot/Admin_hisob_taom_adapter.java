package com.balance.smart_cash.Admin.Admin_hisobot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Admin_hisob_taom_adapter extends BaseAdapter {
    Context context;
    private ArrayList<Admin_hisob_taom_list> sotilganLists;

    public Admin_hisob_taom_adapter(Context context, ArrayList<Admin_hisob_taom_list> sotilganLists) {
        this.context = context;
        this.sotilganLists = sotilganLists;
    }

    @Override
    public int getCount() {
        return sotilganLists.size();
    }

    @Override
    public Object getItem(int position) {
        return sotilganLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_id, txt_tartib, txt_nomi, txt_soni, txt_narxi, txt_summa;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;

        ViewHolder holder = new ViewHolder();
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.admin_hisob_taom_item, null);
            holder.txt_id = (TextView) row.findViewById(R.id.txt_admin_hisob_taom_item_id);
            holder.txt_tartib = (TextView) row.findViewById(R.id.txt_admin_hisob_taom_item_raqam);
            holder.txt_nomi = (TextView) row.findViewById(R.id.txt_admin_hisob_taom_item_nomi);
            holder.txt_soni = (TextView) row.findViewById(R.id.txt_admin_hisob_taom_item_soni);
            holder.txt_narxi = (TextView) row.findViewById(R.id.txt_admin_hisob_taom_item_narxi);
            holder.txt_summa = (TextView) row.findViewById(R.id.txt_admin_hisob_taom_item_summa);

            row.setTag(holder);

        } else {
            holder = (ViewHolder) row.getTag();
        }
        try {

            Admin_hisob_taom_list sotilgan_list = sotilganLists.get(position);
            holder.txt_id.setText(sotilgan_list.getId());
            holder.txt_tartib.setText(sotilgan_list.getTartib());
            holder.txt_nomi.setText(sotilgan_list.getNomi());
            holder.txt_soni.setText(sotilgan_list.getSoni());
            holder.txt_narxi.setText(sotilgan_list.getNarxi());
            holder.txt_summa.setText(sotilgan_list.getSumma());
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        }

        return row;
    }
}
