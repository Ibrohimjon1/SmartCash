package com.balance.smart_cash.Otdel;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Menu.Menu_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Umumiy.Umumiy_oyna;

import java.util.ArrayList;

public class Otdel_oyna extends Fragment {

    GridView gridView;
    ArrayList<Otdel_list> otdel_list = new ArrayList<>();
    private View parentView;
    Button btn_otdel, btn_menu, btn_taom;
    Otdel_adapter adapter;
    FragmentTransaction fragment;
    View txt_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.otdel_oyna, container, false);
        Setup();
        return parentView;
    }

    private void Setup() {
        gridView = (GridView) parentView.findViewById(R.id.grid_view_otdel);
        otdel_list.clear();

        btn_taom = (Button) getActivity().findViewById(R.id.btn_umum_taom);
        btn_menu = (Button) getActivity().findViewById(R.id.btn_umum_menu);
        btn_otdel = (Button) getActivity().findViewById(R.id.btn_umum_otdel);
        txt_mal_yoq = parentView.findViewById(R.id.txt_otdel_oyna_mal_yoq);
        adapter = new Otdel_adapter(getContext(), otdel_list);
        gridView.setAdapter(adapter);
        Get_otdel();

        if (Umumiy_oyna.OTDEL_BORMI == 0) {
            btn_otdel.setVisibility(View.GONE);
            Umumiy_oyna.view_umum_oq.setVisibility(View.VISIBLE);
        } else {
            btn_otdel.setVisibility(View.VISIBLE);
        }
        if (Umumiy_oyna.MENU_BORMI == 0) {
            btn_menu.setVisibility(View.INVISIBLE);
        } else {
            btn_menu.setVisibility(View.GONE);
        }
        btn_taom.setVisibility(View.GONE);

        btn_otdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Otdel_oyna(), "");
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView txt_id = view.findViewById(R.id.txt_otdel_item_id);
                changeFragment(new Menu_oyna(), txt_id.getText().toString());
            }
        });


    }

    public void Get_otdel() {
        if (Umumiy_oyna.OTDEL_BORMI != 0) {

            String sql = "";
            if (Umumiy_oyna.OTDEL_BORMI == -1) {
                sql = "SELECT * FROM " + Login_oyna.TABLE_OTDEL;
            } else {
                sql = "SELECT * FROM " + Login_oyna.TABLE_OTDEL+ " WHERE Id = '" + Umumiy_oyna.OTDEL_BORMI + "'";
            }

            Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                otdel_list.clear();
                do {
                    String id = cursor.getString(0);
                    String nomi = cursor.getString(1);
                    byte[] image = cursor.getBlob(2);

                    otdel_list.add(new Otdel_list(id, image, nomi));
                } while (cursor.moveToNext());
                try {
                    adapter.notifyDataSetChanged();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
                txt_mal_yoq.setVisibility(View.GONE);
            } else {
                txt_mal_yoq.setVisibility(View.VISIBLE);
                otdel_list.clear();
                try {
                    adapter.notifyDataSetChanged();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    public void changeFragment(Fragment targetFragment, String id) {
        Bundle bundle = new Bundle();
        bundle.putString("otdel", id);
        targetFragment.setArguments(bundle);

        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }
}
