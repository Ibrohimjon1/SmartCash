package com.balance.smart_cash.Admin.Admin_sozlama;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_Pechat extends Fragment {
    View parent_view;
    LinearLayout set_tolov_printer, set_bekor_printer;
    Switch switch_set_taom_pechat;
    TextView txt_set_tolov_print, txt_set_bekor_print, txt_tolov_print, txt_taom_print, txt_bekor_print;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_pechat, container, false);
        init();
        return parent_view;
    }

    public void init() {
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        set_tolov_printer = (LinearLayout) parent_view.findViewById(R.id.set_tolov_printer);
        set_bekor_printer = (LinearLayout) parent_view.findViewById(R.id.set_bekor_printer);
        txt_tolov_print = parent_view.findViewById(R.id.txt_tolov_pechat);
        txt_bekor_print = parent_view.findViewById(R.id.txt_bekor_print);
        txt_taom_print = parent_view.findViewById(R.id.txt_taom_pechat);

        txt_bekor_print.setText(R.string.bekor_qilingan_taom_pechat);
        txt_taom_print.setText(R.string.taom_pechat);
        txt_tolov_print.setText(R.string.to_lov_pechat);

        switch_set_taom_pechat = (Switch) parent_view.findViewById(R.id.switch_set_taom_pechat);
        txt_set_tolov_print = (TextView) parent_view.findViewById(R.id.txt_set_tolov_print);
        txt_set_bekor_print = (TextView) parent_view.findViewById(R.id.txt_set_bekor_print);

        switch_set_taom_pechat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("taom_print", 1);
                } else {
                    Mal_saqlash("taom_print", 0);
                }
            }
        });
        set_tolov_printer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tolov_print_dialog();
            }
        });

        set_bekor_printer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bekor_dialog();
            }
        });
        Mal_toldirish();
    }

    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    private void Mal_toldirish() {

        int tolov_print = sharedPreferences.getInt("tolov_print", -1);
        int taom_print = sharedPreferences.getInt("taom_print", 0);
        int bekor_print = sharedPreferences.getInt("bekor_print", 0);

        if (tolov_print == -1) {
            Mal_saqlash("tolov_print", -1);
            txt_set_tolov_print.setText(R.string.tolov_cheki_chiqarilmaydi);
        } else {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT nomi FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + tolov_print + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                String print_nomi = cursor.getString(0);
                txt_set_tolov_print.setText(print_nomi);
            }
        }

        if (taom_print == 0) {
            Mal_saqlash("taom_print", 0);
            switch_set_taom_pechat.setChecked(false);
        } else {
            switch_set_taom_pechat.setChecked(true);
        }

        if (bekor_print == 0) {
            Mal_saqlash("bekor_print", 0);
            txt_set_bekor_print.setText(R.string.bekor_taom_cheki_chiqmaydi);
        } else if (bekor_print == -1) {
            txt_set_bekor_print.setText(R.string.kassa_va_taom_otdelidan);
        } else if (bekor_print == -2) {
            txt_set_bekor_print.setText(R.string.taom_otdelidan);
        } else {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT nomi FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id = '" + bekor_print + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                String print_nomi = cursor.getString(0);
                txt_set_bekor_print.setText(print_nomi);
            }
        }
    }


    private void Bekor_dialog() {
        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_otmen_taom_print);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int bekor_print = sharedPreferences.getInt("bekor_print", -1);

        ArrayList<String> list = new ArrayList<>();
        final ArrayList<String> list_id = new ArrayList<>();
        list.clear();
        list_id.clear();
        list_id.add("");
        list_id.add("");
        list.add(getString(R.string.kassa_va_taom_otdelidan));
        list.add(getString(R.string.taom_otdelidan));
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_PRINTER);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String prin_id = cursor.getString(0);
                String prin_nomi = cursor.getString(1);
                list.add(prin_nomi);
                list_id.add(prin_id);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (bekor_print == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (bekor_print == -1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else if (bekor_print == -2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(1);
        } else {
            int index = list_id.indexOf("" + bekor_print);
            spinner.setSelection(index);
            swit.setChecked(true);
            spinner.setEnabled(true);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    if (spinner.getSelectedItemPosition() == 0) {
                        editor.putInt("bekor_print", -1);
                        editor.commit();
                    } else if (spinner.getSelectedItemPosition() == 1) {
                        editor.putInt("bekor_print", -2);
                        editor.commit();
                    } else {
                        int index = spinner.getSelectedItemPosition();
                        String id = list_id.get(index);
                        try {
                            int is = Integer.parseInt(id);
                            editor.putInt("bekor_print", is);
                            editor.commit();
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                        }
                    }
                } else {
                    editor.putInt("bekor_print", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Tolov_print_dialog() {
        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_tolov_print);
        dialog.setCancelable(true);
        dialog.setTitle("");

        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int tolov_print = sharedPreferences.getInt("tolov_print", -1);

        ArrayList<String> list = new ArrayList<>();
        final ArrayList<String> list_id = new ArrayList<>();
        list.clear();
        list_id.clear();
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_PRINTER);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String prin_id = cursor.getString(0);
                String prin_nomi = cursor.getString(1);
                list_id.add(prin_id);
                list.add(prin_nomi);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (tolov_print == -1) {
            spinner.setEnabled(false);
            swit.setChecked(false);
        } else {
            int index = list_id.indexOf("" + tolov_print);
            spinner.setSelection(index);
            swit.setChecked(true);
            spinner.setEnabled(true);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    if (spinner.getSelectedItemPosition() > -1) {

                        int index = spinner.getSelectedItemPosition();
                        String id = list_id.get(index);
                        try {
                            int is = Integer.parseInt(id);
                            editor.putInt("tolov_print", is);
                            editor.commit();
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                        }
                    }
                } else {
                    editor.putInt("tolov_print", -1);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }
}
