package com.balance.smart_cash.Print;

import com.balance.smart_cash.Login.Login_oyna;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by Ibrohimjon on 28.08.2018.
 */

public class Tolov_pechat {

    public static byte[] normal = new byte[]{0x1B, 0x21, 0x03};  // 0- normal size text
    public static byte[] bold = new byte[]{0x1B, 0x21, 0x08};  // 1- only bold text
    public static byte[] large = new byte[]{0x1B, 0x21, 0x10}; // 3- bold with large text
    public static byte[] shapkas = new byte[]{0x1B, 0x21, 0x20}; // 2- bold with medium text
    public static byte[] stols = {29, 33, 35}; // manipulate your font size in the second parameter
    public static byte[] center = {0x1b, 'a', 0x01};

    public static byte[] arrayOfByte1 = {27, 33, 0};
    public static Socketmanager mSockManager;
    public static byte[] format = {27, 33, 0};
    // Bold
    //                format[2] = ((byte) (0x8 | arrayOfByte1[2]));
    // Height
    //                format[2] = ((byte) (0x10 | arrayOfByte1[2]));
    // Width
    //                format[2] = ((byte) (0x20 | arrayOfByte1[2]));

    public static String Pechat_qilish(String ip, String nomi, String shapka, String asosiy, String padval) {
        mSockManager = new Socketmanager();
        if (conTest(ip)) {
            try {
                byte[] bol = bold;
                bol[2] = ((byte) (0x8 | arrayOfByte1[2]));
                if (UMUMIY_pechat(ip, stols, (nomi).getBytes("cp866"), bol, (shapka).getBytes("cp866"), (asosiy).getBytes("cp866"), (padval).getBytes("cp866"))) {
                    return "Muvaffaqqiyatli pechat bo'ldi";
                } else {
                    return "Xatolik bo'ldi!";
                }
            } catch (UnsupportedEncodingException q) {
                q.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(q);
                try {
                    byte[] bol = bold;
                    bol[2] = ((byte) (0x8 | arrayOfByte1[2]));
                    if (UMUMIY_pechat(ip, stols, (nomi).getBytes("GBK"), bol, (shapka).getBytes("GBK"), (asosiy).getBytes("GBK"), (padval).getBytes("GBK"))) {
                        return "Muvaffaqqiyatli pechat bo'ldi";
                    } else {
                        return "Xatolik bo'ldi!";
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
            }
        } else {
            return "Printer ipsiga ulanishda xatolik bo'ldi!\n" + ip;
        }
        return "UnsupportedEncodingException bo'ldi!";
    }


    public static boolean UMUMIY_pechat(String ip, byte[] tip_stol, byte[] stol, byte[] tip_shapka, byte[] shapka, byte[] tip_asos, byte[] asos) {
        mSockManager = new Socketmanager();
        if (conTest(ip)) {

            if (PrintfData_umum(tip_stol, stol, tip_shapka, shapka, tip_asos, asos)) {
                return true;
            } else {
                return false;
            }

        } else {
            return false;
        }
    }

//        byte SendCut[] = {0x0a, 0x0a, 0x1d, 0x56, 0x01};


    public static boolean PrintfData_umum(byte[] tip_stol, byte[] stol, byte[] tip_shapka, byte[] shapka, byte[] tip_asos, byte[] asos) {
        mSockManager.threadconnectwrite_umum(tip_stol, stol, tip_shapka, shapka, tip_asos, asos);
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        }
        if (mSockManager.getIstate()) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean conTest(String printerIp) {
        mSockManager.mPort = 9100;
        mSockManager.mstrIp = printerIp;
        mSockManager.threadconnect();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        }
        if (mSockManager.getIstate()) {
            return true;
        } else {
            return false;
        }
    }


    public static class Socketmanager {
        public static final boolean MESSAGE_CONNECTED = true;
        public static final boolean MESSAGE_CONNECTED_ERROR = false;
        public static final boolean MESSAGE_WRITE_SUCCESS = true;
        public static final boolean MESSAGE_WRITE_ERROR = false;
        public Socket mMyWifiSocket = null;
        public BufferedReader BufReader = null;
        public OutputStream PriOut = null;
        public boolean iState = false;

        public String mstrIp = "192.168.1.248";
        public int mPort = 9100;

        public int TimeOut = 1300;

        public boolean getIstate() {
            return iState;
        }

        public void SetState(Boolean state) {
            iState = state;
        }

        public void threadconnect() {
            new ConnectThread();
        }

        public boolean connect() {
            close();
            try {
                mMyWifiSocket = new Socket();
                mMyWifiSocket.connect(new InetSocketAddress(mstrIp, mPort), TimeOut);
                PriOut = mMyWifiSocket.getOutputStream();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
                SetState(MESSAGE_CONNECTED_ERROR);
                return false;
            }

        }

        public void close() {
            if (mMyWifiSocket != null) {
                try {
                    mMyWifiSocket.close();
                    mMyWifiSocket = null;
                } catch (IOException e1) {
                    e1.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e1);
                }
            }
            if (BufReader != null) {
                try {
                    BufReader.close();
                    BufReader = null;
                } catch (IOException e2) {
                    e2.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e2);
                }
            }
            if (PriOut != null) {
                try {
                    PriOut.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                PriOut = null;
            }
        }

        private class ConnectThread extends Thread {
            public ConnectThread() {
                start();
            }

            public void run() {
                if (connect()) {
                    SetState(MESSAGE_CONNECTED);
                }
                close();
            }
        }


        public void threadconnectwrite_umum(byte[] tip_stol, byte[] stol, byte[] tip_shapka, byte[] shapka, byte[] tip_asos, byte[] asos) {
            new WriteThread_UMUM(tip_stol, stol, tip_shapka, shapka, tip_asos, asos);
        }

        private class WriteThread_UMUM extends Thread {
            byte[] tip_stol, stol, tip_shapka, shapka, tip_asos, asos;

            public WriteThread_UMUM(byte[] tip_stol, byte[] stol, byte[] tip_shapka, byte[] shapka, byte[] tip_asos, byte[] asos) {
                this.tip_stol = tip_stol;
                this.stol = stol;
                this.tip_shapka = tip_shapka;
                this.shapka = shapka;
                this.tip_asos = tip_asos;
                this.asos = asos;
                start();
            }

            public void run() {
                if (ConnectAndWrite_umu(tip_stol, stol, tip_shapka, shapka, tip_asos, asos)) {
                    SetState(MESSAGE_WRITE_SUCCESS);
                }
            }
        }


        public boolean ConnectAndWrite_umu(byte[] tip_stol, byte[] stol, byte[] tip_shapka, byte[] shapka, byte[] tip_asos, byte[] asos) {
            if (connect()) {
                write_UMUM(tip_stol, stol, tip_shapka, shapka, tip_asos, asos);
                close();
                SetState(MESSAGE_WRITE_SUCCESS);
                return true;
            } else {
                SetState(MESSAGE_CONNECTED_ERROR);
                return false;
            }
        }

        public void resetPrint() {
            try {
                PriOut.write(PrinterCommands.ESC_FONT_COLOR_DEFAULT);
                PriOut.write(PrinterCommands.FS_FONT_ALIGN);
                PriOut.write(PrinterCommands.ESC_ALIGN_LEFT);
                PriOut.write(PrinterCommands.ESC_CANCEL_BOLD);
                PriOut.write(PrinterCommands.LF);
                PriOut.write(new byte [] { 27, 116, 9 });
            } catch (IOException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
        }

        public boolean write_UMUM(byte[] tip_stol, byte[] stol, byte[] tip_shapka, byte[] shapka, byte[] asos, byte[] padval) {
            if (PriOut != null) {
                try {
                    String soz = "________________________________________________\n.\n.";

                    byte SendCut[] = {0x0a, 0x0a, 0x1d, 0x56, 0x01};
                    resetPrint();

                    PriOut.write(center);
                    PriOut.write(bold);
                    PriOut.write(large);
                    PriOut.write(stol);
                    PriOut.write(new Formatter().bold().underlined().get());
                    PriOut.write(shapka);
                    PriOut.write(new Formatter().bold().underlined().get());
                    PriOut.write(asos);
                    PriOut.write(bold);
                    PriOut.write(large);
                    PriOut.write(center);
                    PriOut.write(padval);
                    PriOut.write((soz).getBytes("GBK"));
                    PriOut.write(SendCut);
                    PriOut.flush();
                    return true;
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    return false;
                }
            } else

            {
                return false;
            }
        }
    }
}

