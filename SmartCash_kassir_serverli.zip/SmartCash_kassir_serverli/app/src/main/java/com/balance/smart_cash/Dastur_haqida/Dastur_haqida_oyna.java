package com.balance.smart_cash.Dastur_haqida;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;

public class Dastur_haqida_oyna extends Fragment {

    private View parent_view;
    FragmentTransaction fragment;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.biz_haqimizda, container, false);
        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);

        Bosh_oyna.txt_asos_tool.setText(R.string.dastur_haqida);
        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
                final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
//                if (ofit_bormi == 0) {
//                    if (stol_bormi == 0) {
                        changeFragment(new Saboy1_oyna());
//                    } else {
//                        changeFragment(new Stol_oyna());
//                    }
//                } else if (ofit_bormi == 1) {
//                    changeFragment(new Ofitsant_oyna());
//                }

            }
        });
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }
}
