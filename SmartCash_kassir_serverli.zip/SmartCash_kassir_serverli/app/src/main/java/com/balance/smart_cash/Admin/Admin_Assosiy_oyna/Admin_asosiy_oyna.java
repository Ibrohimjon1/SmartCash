package com.balance.smart_cash.Admin.Admin_Assosiy_oyna;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.balance.smart_cash.Admin.Admin_hisobot.Admin_Hisobot_oyna;
import com.balance.smart_cash.Admin.Admin_sozlama.Admin_sozlamalar_royhati;
import com.balance.smart_cash.Admin.Admin_sp_royhat.Admin_Sp_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Sozlamalar.Sozlama_oyna;
import com.balance.smart_cash.Yuklamalar.Yuklama_oyna;

public class Admin_asosiy_oyna extends AppCompatActivity {
    CardView admin_sp, admin_Hisobot, admin_Sittings, admin_Synch;
    String Admin_;
    TextView txt_spr, txt_sozlama, txt_hisob, txt_yuklama;
    RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_asosiy_oyna);
        layout = findViewById(R.id.layout);
        Intent intent = getIntent();
        Admin_ = intent.getStringExtra("Admin");
        init();
    }

    private void init() {
        admin_Hisobot = (CardView) findViewById(R.id.Admin_Hisobot);
        admin_Sittings = (CardView) findViewById(R.id.Admin_Sittings);
        admin_sp = (CardView) findViewById(R.id.Admin_sp);
        admin_Synch = (CardView) findViewById(R.id.Admin_Synch);
        txt_spr = findViewById(R.id.txt_admin_spr);
        txt_sozlama = findViewById(R.id.txt_admin_settings);
        txt_hisob = findViewById(R.id.txt_admin_hisobot);
        txt_yuklama = findViewById(R.id.txt_admin_sych);
        boshqaOyanagaOtish(admin_Hisobot, Admin_Hisobot_oyna.class);
        boshqaOyanagaOtish(admin_sp, Admin_Sp_oyna.class);
        boshqaOyanagaOtish(admin_Synch, Yuklama_oyna.class);

        admin_Sittings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Admin_.equals("1")) {
                    Intent intent = new Intent(Admin_asosiy_oyna.this, Sozlama_oyna.class);
                    startActivity(intent);
                } else if (Admin_.equals("0")) {
                    Intent intent = new Intent(Admin_asosiy_oyna.this, Admin_sozlamalar_royhati.class);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        txt_hisob.setText(R.string.admin_hisobot);
        txt_sozlama.setText(R.string.admin_sozlamalar);
        txt_spr.setText(R.string.admin_ro_yhatlar);
        txt_yuklama.setText(R.string.yuklamalar);
    }

    public void boshqaOyanagaOtish(CardView cardView, final Class url) {
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Admin_asosiy_oyna.this, url);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Admin_asosiy_oyna.this, Login_oyna.class);
        startActivity(intent);
    }
}
