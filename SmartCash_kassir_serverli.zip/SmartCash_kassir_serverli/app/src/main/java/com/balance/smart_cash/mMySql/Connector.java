package com.balance.smart_cash.mMySql;

import com.balance.smart_cash.Login.Login_oyna;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Connector {

    public static HttpURLConnection connection(String urlAdres) {
        try {
            URL url = new URL(urlAdres);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(15000);
            con.setReadTimeout(15000);
            con.setDoInput(true);
//            con.setDoOutput(true);
//            con.connect();
            return con;
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        } catch (IOException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        }
        return null;
    }
}
