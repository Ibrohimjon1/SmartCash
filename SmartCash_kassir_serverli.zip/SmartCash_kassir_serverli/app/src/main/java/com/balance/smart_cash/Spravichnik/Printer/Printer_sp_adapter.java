package com.balance.smart_cash.Spravichnik.Printer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Printer_sp_adapter extends BaseAdapter {

    private Context context;
    private ArrayList<Printer_sp_list> printer_sp_lists;

    public Printer_sp_adapter(Context context, ArrayList<Printer_sp_list> printer_sp_lists) {
        this.context = context;
        this.printer_sp_lists = printer_sp_lists;
    }

    @Override
    public int getCount() {
        return printer_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return printer_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView printer_sp_royhat_item_ID, printer_sp_royhat_item_Num, printer_sp_royhat_item_Nomi, printer_sp_royhat_item_Url,
                printer_sp_royhat_item_tipi;

    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;
        ViewHolder holder = new ViewHolder();
        Printer_sp_list printer_sp_list = printer_sp_lists.get(position);

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.printer_sp_royhat_item, null);

            holder.printer_sp_royhat_item_ID = (TextView) row.findViewById(R.id.printer_sp_royhat_item_ID);
            holder.printer_sp_royhat_item_Num = (TextView) row.findViewById(R.id.printer_sp_royhat_item_Num);
            holder.printer_sp_royhat_item_Nomi = (TextView) row.findViewById(R.id.printer_sp_royhat_item_Nomi);
            holder.printer_sp_royhat_item_Url = (TextView) row.findViewById(R.id.printer_sp_royhat_item_Url);
            holder.printer_sp_royhat_item_tipi = (TextView) row.findViewById(R.id.printer_sp_royhat_item_tipi);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }
        holder.printer_sp_royhat_item_ID.setText(printer_sp_list.getId());
        holder.printer_sp_royhat_item_Num.setText(printer_sp_list.getNum());
        holder.printer_sp_royhat_item_Nomi.setText(printer_sp_list.getNomi());
        holder.printer_sp_royhat_item_Url.setText(printer_sp_list.getUrl());
        holder.printer_sp_royhat_item_tipi.setText(printer_sp_list.getTipi());


        return row;
    }
}
