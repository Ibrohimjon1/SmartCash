package com.balance.smart_cash.Spravichnik.Ofitsant;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Ofitsant_sp_oynaQoshish extends AppCompatActivity {
    Button btn_ofitsant_oynaQoshish_saqlash, btn_ofitsant_oynaQoshish_ortga;
    ImageView ofitsant_sp_img;
    private static int RESULT_LOAD_IMAGE = 1;
    EditText edt_ofitsant_sp_FIO, edt_ofitsant_sp_foizi;
    String sessionId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ofitsant_sp_oyna);
        init();

        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        btn_ofitsant_oynaQoshish_saqlash = (Button) findViewById(R.id.btn_ofitsant_oynaQoshish_saqlash);
        btn_ofitsant_oynaQoshish_ortga = (Button) findViewById(R.id.btn_ofitsant_oynaQoshish_ortga);
        ofitsant_sp_img = (ImageView) findViewById(R.id.ofitsant_sp_img);
        edt_ofitsant_sp_FIO = (EditText) findViewById(R.id.edt_ofitsant_sp_FIO);
        edt_ofitsant_sp_foizi = (EditText) findViewById(R.id.edt_ofitsant_sp_foizi);

        btn_ofitsant_oynaQoshish_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_ofitsant_oynaQoshish_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Fio = edt_ofitsant_sp_FIO.getText().toString().trim();
                String foizi = edt_ofitsant_sp_foizi.getText().toString().trim();

                if (!Fio.equals("")) {
                    if (!sessionId.equals("")) {

                        Login_oyna.SQLITE_HELPER.queryData("UPDATE " + Login_oyna.TABLE_OFITSANT + " SET ismi = '" + Fio + "', foiz = '" + foizi + "' WHERE Id='" + sessionId + "'");
                        finish();
                        Ofitsant_sp_royhat.GetData_Ofitsant();
                    } else {
                        String sql = "INSERT INTO " + Login_oyna.TABLE_OFITSANT + " VALUES (NULL, ?, ?)";
                        String FIO = edt_ofitsant_sp_FIO.getText().toString();
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(FIO, foizi, sql);
                        edt_ofitsant_sp_FIO.setText("");
                        finish();
                        Ofitsant_sp_royhat.GetData_Ofitsant();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_OFITSANT + " WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edt_ofitsant_sp_FIO.setText(cursor_2.getString(1));
            edt_ofitsant_sp_foizi.setText(cursor_2.getString(2));


        }
    }

}