package com.balance.smart_cash.Yuklamalar;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.balance.smart_cash.R;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Yuklama_oyna extends AppCompatActivity {

    View btn_upload, btn_download;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yuklama_oyna);

        btn_download = findViewById(R.id.btn_yuklama_oyna_download);
        btn_upload = findViewById(R.id.btn_yuklama_oyna_upload);

        btn_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Upload_Xabar();
            }
        });

        btn_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Download_Xabar();
            }
        });

    }

    private void Download_Xabar() {
        new SweetAlertDialog(Yuklama_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.sorovnoma))
                .setContentText(getString(R.string.onlinedan_malumot_yuklamoqchimisiz))
                .setCancelText(getString(R.string.yoq))
                .setConfirmText(getString(R.string.ha))
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.cancel();
                        SharedPreferences preferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
                        String holat = preferences.getString("filial_id", "0");
                        Download_tekshir(holat);
                    }
                })
                .show();
    }

    private void Upload_Xabar() {
        new SweetAlertDialog(Yuklama_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.sorovnoma))
                .setContentText(getString(R.string.onlinega_mal_jonatmoq))
                .setCancelText("Yo'q")
                .setConfirmText("Ha")
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.cancel();
                        SharedPreferences preferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
                        SharedPreferences preferen_Sozlama = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
                        String holat = preferences.getString("filial_id", "0");
                        int auto_delete = preferen_Sozlama.getInt("auto_delete", 0);
                        if (auto_delete == 1) {
                            auto_delete = 1;
                        } else if (auto_delete == 2) {
                            auto_delete = 0;
                        } else if (auto_delete == 3) {
                            auto_delete = -1;
                        } else if (auto_delete == 4) {
                            auto_delete = -2;
                        } else if (auto_delete == 5) {
                            auto_delete = -6;
                        } else if (auto_delete == 0){
                            auto_delete = 2;
                        }

                        Upload_tekshir(holat, auto_delete);
                    }
                })
                .

                        show();

    }

    CheckBox check_hammasi;
    CheckBox check_foyda;
    CheckBox check_stol;
    CheckBox check_otdel;
    CheckBox check_menu;
    CheckBox check_taom;
    CheckBox check_printer;
    CheckBox check_sotilgan;
    CheckBox check_tolov;
    CheckBox check_shot;
    CheckBox check_otmen;

    private void Ruchnoy_delete_dialog() {
        final Dialog dialog = new Dialog(Yuklama_oyna.this, R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.upload_sorov);
        dialog.setCancelable(true);
        dialog.setTitle("");
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);
        check_hammasi = dialog.findViewById(R.id.check_upload_hammasi);
        check_foyda = dialog.findViewById(R.id.check_upload_foyda);
        check_stol = dialog.findViewById(R.id.check_upload_stol);
        check_otdel = dialog.findViewById(R.id.check_upload_otdel);
        check_menu = dialog.findViewById(R.id.check_upload_menu);
        check_taom = dialog.findViewById(R.id.check_upload_taom);
        check_printer = dialog.findViewById(R.id.check_upload_printer);
        check_sotilgan = dialog.findViewById(R.id.check_upload_sotilgan);
        check_tolov = dialog.findViewById(R.id.check_upload_tolov);
        check_shot = dialog.findViewById(R.id.check_upload_shot);
        check_otmen = dialog.findViewById(R.id.check_upload_otmen);

        check_hammasi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                check_foyda.setChecked(isChecked);
                check_stol.setChecked(isChecked);
                check_otdel.setChecked(isChecked);
                check_menu.setChecked(isChecked);
                check_taom.setChecked(isChecked);
                check_printer.setChecked(isChecked);
                check_sotilgan.setChecked(isChecked);
                check_tolov.setChecked(isChecked);
                check_shot.setChecked(isChecked);
                check_otmen.setChecked(isChecked);
            }
        });

        check_stol.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });
        check_otdel.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });
        check_menu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });

        check_taom.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });

        check_printer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });

        check_sotilgan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });

        check_tolov.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });
        check_shot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });
        check_otmen.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });
        check_foyda.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Belgini_tekshir();
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
                SharedPreferences preferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
                String holat = preferences.getString("klent_id", "0");
                Upload_tekshir(holat, 0);
            }
        });

        dialog.show();
    }

    public void Belgini_tekshir() {
        if (check_foyda.isChecked() &&
                check_stol.isChecked() &&
                check_otdel.isChecked() &&
                check_taom.isChecked() &&
                check_menu.isChecked() &&
                check_printer.isChecked() &&
                check_sotilgan.isChecked() &&
                check_tolov.isChecked() &&
                check_shot.isChecked() &&
                check_otmen.isChecked()) {
            check_hammasi.setChecked(true);
        } else {
            check_hammasi.setChecked(false);
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void Upload_tekshir(String url, int ayuto) {
        Upload jonatuvchi = new Upload(Yuklama_oyna.this, url, ayuto);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            jonatuvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            jonatuvchi.execute();
        }

    }

    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void Download_tekshir(String url) {
        Download jonatuvchi = new Download(Yuklama_oyna.this, url);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            jonatuvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            jonatuvchi.execute();
        }

    }
}
