package com.balance.smart_cash.Spravichnik.Printer;


import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.smart_cash.Admin.Admin_sp_royhat.Admin_Sp_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 25.08.2018.
 */

public class Printer_sp_royhat extends Fragment {

    private View parent_view;
    ListView lv;
    static ArrayList<Printer_sp_list> printer_sp_lists = new ArrayList<>();
    static Printer_sp_adapter menu_adapter;
    static View txt_otdel_oyna_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.printer_sp_royhat, container, false);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setVisibility(View.VISIBLE);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String f_id = "";
                Intent intent = new Intent(getContext(), Printer_sp_QoshishOyna.class);
                intent.putExtra("SESSION_ID", f_id);
                startActivity(intent);
            }
        });
        init();
        return parent_view;
    }

    public void init() {
        lv = (ListView) parent_view.findViewById(R.id.printer_sp_royhatList);
        txt_otdel_oyna_mal_yoq = parent_view.findViewById(R.id.txt_otdel_oyna_mal_yoq);
        menu_adapter = new Printer_sp_adapter(getContext(), printer_sp_lists);
        lv.setAdapter(menu_adapter);

        GetData_Printer();


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
                dialog.setContentView(R.layout.alertdialog_oyna);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.setTitle("O'zgartirish");
                Button btn_change = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ozgartir);
                Button btn_delet = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ochir);
                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextView idd = (TextView) view.findViewById(R.id.printer_sp_royhat_item_ID);
                        String f_id = idd.getText().toString();
                        Intent intent = new Intent(getContext(), Printer_sp_QoshishOyna.class);
                        intent.putExtra("SESSION_ID", f_id);
                        startActivity(intent);
                        dialog.dismiss();


                    }
                });

                btn_change.setText(R.string.o_zgartirish);
                btn_delet.setText(R.string.o_chirish);

                btn_delet.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        TextView idd = (TextView) view.findViewById(R.id.printer_sp_royhat_item_ID);
                        String f_id = idd.getText().toString();
                        Login_oyna.SQLITE_HELPER.deleteData("DELETE FROM " + Login_oyna.TABLE_PRINTER + " WHERE Id='" + f_id + "'");
                        GetData_Printer();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
    }


    public static void GetData_Printer() {
        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_PRINTER);
        int p = 0;
        if (cursor_2.getCount() != 0) {
            printer_sp_lists.clear();
            cursor_2.moveToFirst();
            txt_otdel_oyna_mal_yoq.setVisibility(View.GONE);
            do {
                p++;
                String id = cursor_2.getString(0);
                String nomi = cursor_2.getString(1);
                String url = cursor_2.getString(2);
                String tipi = cursor_2.getString(3);
                String num = String.valueOf(p);
                printer_sp_lists.add(new Printer_sp_list(id, num, nomi, url, tipi));

            } while (cursor_2.moveToNext());
            try {
                menu_adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }

        } else {
            printer_sp_lists.clear();
            txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
            try {
                menu_adapter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        }

    }

}