package com.balance.smart_cash.mMySql;

import android.os.StrictMode;

import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by Ibrohimjon on 25.09.2018.
 */

public class ConnectionClass {
    String classss = "com.mysql.jdbc.Driver";
    String url = "jdbc:mysql://192.168.1.113/wacdonald_smart_cash";
    String un = "admin";
    String pass = "123";

    public Connection CONN() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String COnnUrl = null;
        try {
            Class.forName(classss);
            connection = DriverManager.getConnection(url, un, pass);
//            connection = DriverManager.getConnection(COnnUrl);


        } catch (CommunicationsException w) {
            w.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

}
