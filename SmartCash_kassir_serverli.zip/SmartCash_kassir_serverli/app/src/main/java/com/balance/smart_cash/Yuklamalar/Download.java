package com.balance.smart_cash.Yuklamalar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;
import com.harlan.progressbar.LineProgressBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Download extends AsyncTask<Void, Integer, String> {

    Activity context;
    String urlAddre;
    Dialog dialog;
    View customProgress;
    View view, view2;
    TextView txt_malum;

    int MAX_SONI = 0;
    int ket_soni = 0;

    public Download(Activity context, String urlAddre) {
        this.context = context;
        this.urlAddre = urlAddre;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog = new Dialog(context, R.style.hisob_ozgart_oyna_di);
        customProgress = LayoutInflater.from(context).inflate(R.layout.progress_dialog, null, false);
        dialog.setContentView(customProgress);
        dialog.setCancelable(false);
        txt_malum = customProgress.findViewById(R.id.txt_upload_mal);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        view = customProgress.findViewById(R.id.layout_upload_prog);
        view2 = customProgress.findViewById(R.id.layout_upload_success);
        view.setVisibility(View.VISIBLE);
        view2.setVisibility(View.GONE);
        txt_malum.setText(R.string.malumot_toplanmoqda);
    }

    @Override
    protected String doInBackground(Void... voids) {
        MAX_SONI = 0;
        ket_soni = 0;
        String klent_id = urlAddre;
        if (isOnline(context)) {
            String url_soni = "";
            try {
                url_soni = url_address + Urllar.Download_soni + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            String soni = downloadData(url_soni);
            if (soni.equals("0") || soni.equals("")) {
                return "no";
            } else {
                try {
                    MAX_SONI = Integer.parseInt(soni);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                String sql = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_FOYDALANUVCHI;
                Login_oyna.SQLITE_HELPER.queryData(sql);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_FOYDALANUVCHI + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, ismi VARCHAR,dostup VARCHAR, parol VARCHAR, yuklandi INTEGER DEFAULT 0)");
                String url_foyda = "";
                try {
                    url_foyda = url_address + Urllar.Download_foydalanuvchi + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con = Connector.connection(url_foyda);
                if (con != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-1);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Ismi = "";
                                                try {
                                                    Ismi = jsonObject.getString("Ismi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Dostup = "";
                                                try {
                                                    Dostup = jsonObject.getString("Dostup");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Parol = "";
                                                try {
                                                    Parol = jsonObject.getString("Parol");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_FOYDALANUVCHI + " VALUES (?, ?, ?, ?, 1)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_4ta(Spr_id, Ismi, Dostup, Parol, sqlq);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con != null) {
                            con.disconnect();
                        }
                    }
                }

                String sql1 = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_OTDEL;
                Login_oyna.SQLITE_HELPER.queryData(sql1);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_OTDEL + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, rasmi BLOB, printer VARCHAR, yuklandi INTEGER DEFAULT 0)");

                String url_otdel = "";
                try {
                    url_otdel = url_address + Urllar.Download_otdel + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con1 = Connector.connection(url_otdel);
                if (con1 != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con1 != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con1.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-2);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Nomi = "";
                                                try {
                                                    Nomi = jsonObject.getString("Nomi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Rasm = "";
                                                try {
                                                    Rasm = jsonObject.getString("Rasm");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Printer = "";
                                                try {
                                                    Printer = jsonObject.getString("Printer");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                byte[] rasmi = new byte[0];
                                                if (!Rasm.equals("")) {
                                                    try {
                                                        rasmi = downloadImage(url_address +
                                                                Rasm.replace(" ", "%20"));
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        Login_oyna.XATOLIK_YOZISH(e);
                                                    }
                                                }
                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_OTDEL + " VALUES (?, ?, ?, ?, 1)";
                                                Login_oyna.SQLITE_HELPER.Otdel_qoshish(Spr_id, Nomi, rasmi, Printer, sqlq);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con1 != null) {
                            con1.disconnect();
                        }
                    }
                }

                String sql2 = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_MENU;
                Login_oyna.SQLITE_HELPER.queryData(sql2);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_MENU + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, otdel_id VARCHAR, rasmi BLOB, yuklandi INTEGER DEFAULT 0)");

                String url_menu = "";
                try {
                    url_menu = url_address + Urllar.Download_menu + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con2 = Connector.connection(url_menu);
                if (con2 != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con2 != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con2.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-3);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Nomi = "";
                                                try {
                                                    Nomi = jsonObject.getString("Nomi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Rasm = "";
                                                try {
                                                    Rasm = jsonObject.getString("Rasm");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Otdel_id = "";
                                                try {
                                                    Otdel_id = jsonObject.getString("Otdel_id");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                byte[] rasmi = new byte[0];
                                                if (!Rasm.equals("")) {
                                                    try {
                                                        rasmi = downloadImage(url_address +
                                                                Rasm.replace(" ", "%20"));
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        Login_oyna.XATOLIK_YOZISH(e);
                                                    }
                                                }
                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_MENU + " VALUES (?, ?, ?, ?, 1)";
                                                Login_oyna.SQLITE_HELPER.Menu_qoshish(Spr_id, Nomi, rasmi, Otdel_id, sqlq);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con2 != null) {
                            con2.disconnect();
                        }
                    }
                }

                String sql3 = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_TAOMLAR;
                Login_oyna.SQLITE_HELPER.queryData(sql3);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_TAOMLAR + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, narxi VARCHAR, otdel_id VARCHAR, menu_id VARCHAR, rasmi BLOB, foizi VARCHAR, populyar INTEGER DEFAULT 0, printer VARCHAR, yuklandi INTEGER DEFAULT 0)");

                String url_taom = "";
                try {
                    url_taom = url_address + Urllar.Download_taom + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con3 = Connector.connection(url_taom);
                if (con3 != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con3 != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con3.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-4);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Nomi = "";
                                                try {
                                                    Nomi = jsonObject.getString("Nomi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Narxi = "";
                                                try {
                                                    Narxi = jsonObject.getString("Narxi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Otdel_id = "";
                                                try {
                                                    Otdel_id = jsonObject.getString("Otdel_id");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Menu_id = "";
                                                try {
                                                    Menu_id = jsonObject.getString("Menu_id");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Rasm = "";
                                                try {
                                                    Rasm = jsonObject.getString("Rasm");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Foiz = "";
                                                try {
                                                    Foiz = jsonObject.getString("Foiz");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String populyar = "";
                                                try {
                                                    populyar = jsonObject.getString("populyar");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String printer = "";
                                                try {
                                                    printer = jsonObject.getString("printer");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                byte[] rasmi = new byte[0];
                                                if (!Rasm.equals("")) {
                                                    try {
                                                        rasmi = downloadImage(url_address +
                                                                Rasm.replace(" ", "%20"));
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        Login_oyna.XATOLIK_YOZISH(e);
                                                    }
                                                }
                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_TAOMLAR + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
                                                Login_oyna.SQLITE_HELPER.Taom_qoshish_down(Spr_id, Nomi, Narxi, Otdel_id, Menu_id, rasmi, Foiz, populyar, printer, sqlq);

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con3 != null) {
                            con3.disconnect();
                        }
                    }
                }


                String sql4 = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_STOL_SONI;
                Login_oyna.SQLITE_HELPER.queryData(sql4);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_STOL_SONI + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, soni INTEGER DEFAULT 1)");

                String url_stol = "";
                try {
                    url_stol = url_address + Urllar.Download_stol + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con4 = Connector.connection(url_stol);
                if (con4 != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con4 != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con4.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-5);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Soni = null;
                                                try {
                                                    Soni = jsonObject.getString("Soni");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }

                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_STOL_SONI + " VALUES (?, ?)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(Spr_id, Soni, sqlq);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con4 != null) {
                            con4.disconnect();
                        }
                    }
                }


                String sql10 = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_OFITSANT;
                Login_oyna.SQLITE_HELPER.queryData(sql10);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_OFITSANT + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, ismi VARCHAR, foiz VARCHAR, paroli VARCHAR)");


                String url_ofitsant = "";
                try {
                    url_ofitsant = url_address + Urllar.Download_ofitsant + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con10 = Connector.connection(url_ofitsant);
                if (con10 != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con10 != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con10.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-7);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Ismi = "";
                                                try {
                                                    Ismi = jsonObject.getString("Ismi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Foizi = "";
                                                try {
                                                    Foizi = jsonObject.getString("Foizi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Paroli = "";
                                                try {
                                                    Paroli = jsonObject.getString("Paroli");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }

                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_OFITSANT + " VALUES (?, ?,? ,?)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_4ta(Spr_id, Ismi, Foizi, Paroli, sqlq);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con10 != null) {
                            con10.disconnect();
                        }
                    }
                }

                String sql5 = "DROP TABLE IF EXISTS " + Login_oyna.TABLE_PRINTER;
                Login_oyna.SQLITE_HELPER.queryData(sql5);
                Login_oyna.SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + Login_oyna.TABLE_PRINTER + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, url VARCHAR, tipi VARCHAR, yuklandi INTEGER DEFAULT 0)");

                String url_printer = "";
                try {
                    url_printer = url_address + Urllar.Download_printer + ".php?klent_id=" +
                            URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }

                HttpURLConnection con5 = Connector.connection(url_printer);
                if (con5 != null) {
                    InputStream inputStream = null;
                    String xatolik = "";
                    try {
                        if (con5 != null && isOnline(context)) {
                            inputStream = new BufferedInputStream(con5.getInputStream());
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                            String resulr = reader.readLine();
                            if (resulr != null) {
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(resulr);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                if (json != null) {
                                    JSONObject object = null;
                                    try {
                                        object = json.getJSONObject("qiymat");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    boolean tugadi = true;
                                    int sonlari = 0;

                                    try {
                                        sonlari = json.getInt("soni");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                    }
                                    publishProgress(-5);
                                    for (int i = 1; i < sonlari; i++) {
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = object.getJSONObject("qiy_" + i);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                            tugadi = false;
                                        }
                                        if (tugadi) {
                                            String Spr_id = "";
                                            try {
                                                Spr_id = jsonObject.getString("Spr_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            if (Spr_id.equals("mal_yoq")) {
                                                tugadi = false;
                                            } else {
                                                ket_soni++;
                                                String Nomi = "";
                                                try {
                                                    Nomi = jsonObject.getString("Nomi");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }
                                                String Url = "";
                                                try {
                                                    Url = jsonObject.getString("Url");
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(e);
                                                }

                                                publishProgress(ket_soni);
                                                String sqlq = "INSERT INTO " + Login_oyna.TABLE_PRINTER + " VALUES (?, ?, ?, 1, 1)";
                                                Login_oyna.SQLITE_HELPER.Mal_qoshish_3ta(Spr_id, Nomi, Url, sqlq);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (SocketException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Login_oyna.XATOLIK_YOZISH(e);
                        xatolik += "\n" + e.getMessage();
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                                xatolik += "\n" + e.getMessage();
                            }
                        }
                        if (con5 != null) {
                            con5.disconnect();
                        }
                    }
                }
            }
        } else {
            return "non";
        }
        return "";
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        int progress = values[0];
        if (progress == -1) {
            txt_malum.setText(R.string.foydala_yuklan);
        } else if (progress == -2) {
            txt_malum.setText(R.string.otdel_yuklan);
        } else if (progress == -3) {
            txt_malum.setText(R.string.menu_yuklan);
        } else if (progress == -4) {
            txt_malum.setText(R.string.taom_yuklan);
        } else if (progress == -5) {
            txt_malum.setText(R.string.stol_yuklan);
        } else if (progress == -6) {
            txt_malum.setText(R.string.printer_yuklan);
        } else if (progress == -7) {
            txt_malum.setText("Ofitsantlar yuklanmoqda!");
        } else {
            double prog = (double) progress / (double) MAX_SONI;
            double pr = (prog * 100);
            LineProgressBar line1 = (LineProgressBar) customProgress.findViewById(R.id.line1);
            line1.setProgress((int) pr);
        }
    }

    Animation animation, animation1;

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        animation = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        animation1 = AnimationUtils.loadAnimation(context, R.anim.hide);
        TextView txt_ok = customProgress.findViewById(R.id.txt_upload_ok);
        view.setAnimation(animation1);
        view.setVisibility(View.GONE);
        view2.setVisibility(View.VISIBLE);
        view2.setAnimation(animation);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


    }

    public byte[] downloadImage(String urlImg) throws Exception {

        URL url = new URL(urlImg);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setReadTimeout(10000);
        con.setConnectTimeout(10000);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            Bitmap b = BitmapFactory.decodeStream(con.getInputStream());
            b.compress(Bitmap.CompressFormat.PNG, 50, bos);
        } finally {
            con.disconnect();
        }

        return bos.toByteArray();
    }

    private BufferedReader reader = null;

    private String downloadData(String url) {
        HttpURLConnection con = Connector.connection(url);
        if (con == null) {
            return context.getString(R.string.internetni_tekshir);
        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null && isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
                        String soni = jsonObj.getString("soni");
                        return soni;
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return context.getString(R.string.internetni_tekshir) + "  " + xatolikar;
    }
}
