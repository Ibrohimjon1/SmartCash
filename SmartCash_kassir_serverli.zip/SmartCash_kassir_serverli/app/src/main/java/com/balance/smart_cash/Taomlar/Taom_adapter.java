package com.balance.smart_cash.Taomlar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Umumiy.Umumiy_oyna;

import java.util.ArrayList;

import xyz.hanks.library.bang.SmallBangView;

public class Taom_adapter extends BaseAdapter {

    private final Context mContext;
    private ArrayList<Taom_list> stollar;
    int  yuldu = 0;

    // 1
    public Taom_adapter(Context context, ArrayList<Taom_list> stollar, int yuldu) {
        this.mContext = context;
        this.stollar = stollar;
        this.yuldu = yuldu;
    }

    // 2
    @Override
    public int getCount() {
        return stollar.size();
    }

    // 3
    @Override
    public long getItemId(int position) {
        return 0;
    }

    // 4
    @Override
    public Object getItem(int position) {
        return null;
    }

    // 5
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 1
        Taom_list taom_list = stollar.get(position);

        // 2
        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.taom_item, null);
        }

        // 3
        CardView cardView = (CardView) convertView.findViewById(R.id.layout);
        final TextView foiz_TextView = (TextView) convertView.findViewById(R.id.txt_taom_item_foizi);
        final TextView print_TextView = (TextView) convertView.findViewById(R.id.txt_taom_item_print);
        final TextView id_TextView = (TextView) convertView.findViewById(R.id.txt_taom_item_id);
        final TextView nameTextView = (TextView) convertView.findViewById(R.id.txt_taom_item_nomi);
        final TextView narx_txt = (TextView) convertView.findViewById(R.id.txt_taom_item_narxi);
        final ImageView imageView = (ImageView) convertView.findViewById(R.id.image_taom_item);
        final ImageView imageView_orqa = (ImageView) convertView.findViewById(R.id.image_taom_item_orqa);


        foiz_TextView.setText(taom_list.getFoizi());
        id_TextView.setText(taom_list.getId());
        nameTextView.setText(taom_list.getNomi());
        narx_txt.setText(taom_list.getNarxi());
        print_TextView.setText(taom_list.getPrinter());

        byte[] foodImage = taom_list.getImage();
        if (foodImage.length == 0 || foodImage.length == 1) {
            imageView.setImageResource(R.drawable.rasm_6);
        } else {
            Bitmap bitmap = BitmapFactory.decodeByteArray(foodImage, 0, foodImage.length);
            imageView.setImageBitmap(bitmap);
        }


        final SmallBangView like_heart = convertView.findViewById(R.id.like_heart);

        like_heart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (like_heart.isSelected()) {
                    String id = id_TextView.getText().toString();
                    String sql = "UPDATE " + Login_oyna.TABLE_TAOMLAR + " SET populyar = 0 WHERE Id = '" + id + "'";
                    Login_oyna.SQLITE_HELPER.queryData(sql);
                    like_heart.setSelected(false);
                } else {
                    like_heart.setSelected(true);
                    String id = id_TextView.getText().toString();
                    String sql = "UPDATE " + Login_oyna.TABLE_TAOMLAR + " SET populyar = 1 WHERE Id = '" + id + "'";
                    Login_oyna.SQLITE_HELPER.queryData(sql);
                    like_heart.likeAnimation(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            super.onAnimationEnd(animation);
                        }
                    });

                }
            }
        });
        if (yuldu == 0){
            like_heart.setVisibility(View.GONE);
        } else {
            like_heart.setVisibility(View.VISIBLE);
            int yulduz = taom_list.getYulduz();

            if (yulduz == 1) {
                like_heart.setSelected(true);
            } else if (yulduz == 0) {
                like_heart.setSelected(false);
            }
        }
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Umumiy_oyna.Mal_qoshish(id_TextView.getText().toString(), nameTextView.getText().toString(), narx_txt.getText().toString(), foiz_TextView.getText().toString(), print_TextView.getText().toString());
            }
        });
        return convertView;
    }

}