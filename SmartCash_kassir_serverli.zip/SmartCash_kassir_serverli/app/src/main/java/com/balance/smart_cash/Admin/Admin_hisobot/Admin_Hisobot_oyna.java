package com.balance.smart_cash.Admin.Admin_hisobot;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Admin_Hisobot_oyna extends FragmentActivity {
    LinearLayout btn_admin_hisob_ofit, btn_admin_hisob_otmen, btn_admin_hisob_shot, btn_admin_hisob_stol, btn_admin_hisob_taom, btn_admin_hisob_taom_diag, btn_admin_hisob_otdel;
    FragmentTransaction fragment;
    ImageView btn_admin_hisob_ortga;
    public static TextView txt_admin_hisob_sana;
    public static int year_x, month_x, day_x;
    int qaysi_oyna = 0;
    final int HISOB_OFIT = 1, HISOB_SHOT = 2, HISOB_OTDEL = 3, HISOB_OTMEN = 4, HISOB_STOL = 5, HISOB_TAOM = 6, HISOB_TAOM_DIAG = 7;
    TextView txt_shot, txt_taom_royh, txt_taom_diag, txt_otmen, txt_ofit, txt_asos_toolbar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_hisobot_oynasi);

        btn_admin_hisob_ofit = findViewById(R.id.btn_admin_hisob_ofit);
        btn_admin_hisob_otdel = findViewById(R.id.btn_admin_hisob_otdel);
        btn_admin_hisob_otmen = findViewById(R.id.btn_admin_hisob_otmen_taom);
        btn_admin_hisob_shot = findViewById(R.id.btn_admin_hisob_shot);
        btn_admin_hisob_stol = findViewById(R.id.btn_admin_hisob_stol);
        btn_admin_hisob_taom = findViewById(R.id.btn_admin_hisob_taom);
        btn_admin_hisob_taom_diag = findViewById(R.id.btn_admin_hisob_taom_diag);
        btn_admin_hisob_ortga = findViewById(R.id.btn_admin_hisob_ortga);
        txt_admin_hisob_sana = findViewById(R.id.txt_admin_hisob_sana);

        txt_shot = findViewById(R.id.txt_hisob_shot);
        txt_taom_royh = findViewById(R.id.txt_hisob_taom_royh);
        txt_taom_diag = findViewById(R.id.txt_hisob_taom_diag);
        txt_otmen = findViewById(R.id.txt_hisob_otmen);
        txt_ofit = findViewById(R.id.txt_hisob_ofitsant);
        txt_asos_toolbar = findViewById(R.id.txt_asos_toolbar);

        txt_shot.setText(R.string.admin_shotlar);
        txt_taom_royh.setText(R.string.admin_taom_ro_yhat);
        txt_taom_diag.setText(R.string.admin_taom_diagramma);
        txt_otmen.setText(R.string.admin_bekor_ovqatlar);
        txt_ofit.setText(R.string.admin_ofitsant);
        txt_asos_toolbar.setText(R.string.admin_hisobot_oyna);

        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        String strDate = format.format(calendar1.getTime());
        txt_admin_hisob_sana.setText(strDate);

        final Calendar calendar = Calendar.getInstance();
        year_x = calendar.get(Calendar.YEAR);
        month_x = calendar.get(Calendar.MONTH);
        day_x = calendar.get(Calendar.DAY_OF_MONTH);

        txt_admin_hisob_sana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDialog(2);
            }
        });

        btn_admin_hisob_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_admin_hisob_ofit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_SHOT) {
                    btn_admin_hisob_shot.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    btn_admin_hisob_otdel.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    btn_admin_hisob_otmen.setSelected(false);
                } else if (qaysi_oyna == HISOB_STOL) {
                    btn_admin_hisob_stol.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM) {
                    btn_admin_hisob_taom.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {
                    btn_admin_hisob_taom_diag.setSelected(false);
                }
                btn_admin_hisob_ofit.setSelected(true);
                qaysi_oyna = HISOB_OFIT;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
                changeFragment(new Admin_hisobot_ofitsant());
            }
        });
        btn_admin_hisob_otdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_SHOT) {
                    btn_admin_hisob_shot.setSelected(false);
                } else if (qaysi_oyna == HISOB_OFIT) {
                    btn_admin_hisob_ofit.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    btn_admin_hisob_otmen.setSelected(false);
                } else if (qaysi_oyna == HISOB_STOL) {
                    btn_admin_hisob_stol.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM) {
                    btn_admin_hisob_taom.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {
                    btn_admin_hisob_taom_diag.setSelected(false);
                }
                btn_admin_hisob_otdel.setSelected(true);
                qaysi_oyna = HISOB_OTDEL;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
                changeFragment(new Admin_hisobot_otdel());
            }
        });
        btn_admin_hisob_otmen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_SHOT) {
                    btn_admin_hisob_shot.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    btn_admin_hisob_otdel.setSelected(false);
                } else if (qaysi_oyna == HISOB_OFIT) {
                    btn_admin_hisob_ofit.setSelected(false);
                } else if (qaysi_oyna == HISOB_STOL) {
                    btn_admin_hisob_stol.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM) {
                    btn_admin_hisob_taom.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {
                    btn_admin_hisob_taom_diag.setSelected(false);
                }
                btn_admin_hisob_otmen.setSelected(true);
                qaysi_oyna = HISOB_OTMEN;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
                changeFragment(new Admin_hisobot_otmen());
            }
        });
        btn_admin_hisob_shot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_OFIT) {
                    btn_admin_hisob_ofit.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    btn_admin_hisob_otdel.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    btn_admin_hisob_otmen.setSelected(false);
                } else if (qaysi_oyna == HISOB_STOL) {
                    btn_admin_hisob_stol.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM) {
                    btn_admin_hisob_taom.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {
                    btn_admin_hisob_taom_diag.setSelected(false);
                }
                btn_admin_hisob_shot.setSelected(true);
                qaysi_oyna = HISOB_SHOT;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
                changeFragment(new Admin_hisobot_shot());
            }
        });
        btn_admin_hisob_stol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_SHOT) {
                    btn_admin_hisob_shot.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    btn_admin_hisob_otdel.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    btn_admin_hisob_otmen.setSelected(false);
                } else if (qaysi_oyna == HISOB_OFIT) {
                    btn_admin_hisob_ofit.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM) {
                    btn_admin_hisob_taom.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {
                    btn_admin_hisob_taom_diag.setSelected(false);
                }
                btn_admin_hisob_stol.setSelected(true);
                qaysi_oyna = HISOB_STOL;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
            }
        });
        btn_admin_hisob_taom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_SHOT) {
                    btn_admin_hisob_shot.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    btn_admin_hisob_otdel.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    btn_admin_hisob_otmen.setSelected(false);
                } else if (qaysi_oyna == HISOB_STOL) {
                    btn_admin_hisob_stol.setSelected(false);
                } else if (qaysi_oyna == HISOB_OFIT) {
                    btn_admin_hisob_ofit.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {
                    btn_admin_hisob_taom_diag.setSelected(false);
                }
                btn_admin_hisob_taom.setSelected(true);
                qaysi_oyna = HISOB_TAOM;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
                changeFragment(new Admin_hisobot_taom());
            }
        });
        btn_admin_hisob_taom_diag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (qaysi_oyna == HISOB_SHOT) {
                    btn_admin_hisob_shot.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    btn_admin_hisob_otdel.setSelected(false);
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    btn_admin_hisob_otmen.setSelected(false);
                } else if (qaysi_oyna == HISOB_STOL) {
                    btn_admin_hisob_stol.setSelected(false);
                } else if (qaysi_oyna == HISOB_OFIT) {
                    btn_admin_hisob_ofit.setSelected(false);
                } else if (qaysi_oyna == HISOB_TAOM) {
                    btn_admin_hisob_taom.setSelected(false);
                }
                btn_admin_hisob_taom_diag.setSelected(true);
                qaysi_oyna = HISOB_TAOM_DIAG;
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
                String strDate = format.format(calendar1.getTime());
                txt_admin_hisob_sana.setText(strDate);

                final Calendar calendar = Calendar.getInstance();
                year_x = calendar.get(Calendar.YEAR);
                month_x = calendar.get(Calendar.MONTH);
                day_x = calendar.get(Calendar.DAY_OF_MONTH);
                changeFragment(new Admin_hisobot_taom_diag());
            }
        });
    }

    int qa = 0;

    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == 2) {
            return new DatePickerDialog(Admin_Hisobot_oyna.this, dpickerListener1, year_x, month_x, day_x);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener dpickerListener1 = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(android.widget.DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String oy, kun;
            if (monthOfYear < 10) {
                oy = "0" + String.valueOf(monthOfYear + 1);
            } else {
                oy = String.valueOf(monthOfYear + 1);
            }
            if (dayOfMonth < 10) {
                kun = "0" + String.valueOf(dayOfMonth);
            } else {
                kun = String.valueOf(dayOfMonth);
            }

            String stri = kun + "." + oy + "." + String.valueOf(year);
            String string =String.valueOf(year)+ "-" + oy + "-" + kun;

            if (!stri.equals(txt_admin_hisob_sana.getText().toString())) {
                txt_admin_hisob_sana.setText(stri);
                if (qaysi_oyna == HISOB_OFIT) {
                    String sql = "SELECT shot.ofit_id AS ofit_id, tolov.xizmat_sum AS xizmat_sum FROM " + Login_oyna.TABLE_TOLOVLAR + " AS tolov INNER JOIN " + Login_oyna.TABLE_SHOTLAR + " AS shot ON tolov.shot_raqam = shot.shot_raqam WHERE tolov.vaqti LIKE '" + string + "%' ORDER BY shot.ofit_id ASC";

                    Admin_hisobot_ofitsant.Orqa_get_data orqa_get_data = new Admin_hisobot_ofitsant.Orqa_get_data(string, Admin_Hisobot_oyna.this);
                    orqa_get_data.execute();
                } else if (qaysi_oyna == HISOB_SHOT) {
                    Admin_hisobot_shot.Yangilash yangilash = new Admin_hisobot_shot.Yangilash(string, Admin_Hisobot_oyna.this);
                    yangilash.execute();
                } else if (qaysi_oyna == HISOB_OTDEL) {
                    String otdel_id = Admin_hisobot_otdel.otdel_ID.get(Admin_hisobot_otdel.spinner_otdel.getSelectedItemPosition());
                    Admin_hisobot_otdel.Yangilash yangilash = new Admin_hisobot_otdel.Yangilash(otdel_id, Admin_Hisobot_oyna.this);
                    yangilash.execute();
                } else if (qaysi_oyna == HISOB_OTMEN) {
                    Admin_hisobot_otmen.Yangilash yangilash = new Admin_hisobot_otmen.Yangilash(string, Admin_Hisobot_oyna.this);
                    yangilash.execute();
                } else if (qaysi_oyna == HISOB_STOL) {

                } else if (qaysi_oyna == HISOB_TAOM) {

                    Admin_hisobot_taom.Yangilash yangilash = new Admin_hisobot_taom.Yangilash(string, Admin_Hisobot_oyna.this);
                    yangilash.execute();
                } else if (qaysi_oyna == HISOB_TAOM_DIAG) {

                    Admin_hisobot_taom_diag.Orqa_get_data orqa_get_data = new Admin_hisobot_taom_diag.Orqa_get_data(string, Admin_Hisobot_oyna.this);
                    orqa_get_data.execute();
                }

            }
        }
    };

    public void changeFragment(Fragment targetFragment) {
        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.hisob_Fregmant, targetFragment)
                .commit();

    }
}
