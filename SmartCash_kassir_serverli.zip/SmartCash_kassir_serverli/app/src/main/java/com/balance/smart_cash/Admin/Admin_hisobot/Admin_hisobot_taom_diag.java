package com.balance.smart_cash.Admin.Admin_hisobot;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import me.ithebk.barchart.BarChart;
import me.ithebk.barchart.BarChartModel;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Admin_hisobot_taom_diag extends Fragment {

    private View parent_view;
    private static BarChart barChartVertical;
    static TextView txt_mal_yoq, txt_hisob_ofit_nomi;
    FragmentTransaction fragment;
    static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.hisobot_ofitsant, container, false);
        init();
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.hisob_Fregmant, targetFragment)
                .commit();

    }

    public void init() {
        barChartVertical = (BarChart) parent_view.findViewById(R.id.bar_chart_vertical);
        txt_mal_yoq = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_ma_yoq);
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        txt_hisob_ofit_nomi = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_nomi);
        Calendar calendar1 = Calendar.getInstance();
        txt_hisob_ofit_nomi.setText(R.string.sotilgan_taom_diag);
        txt_hisob_ofit_nomi.setVisibility(View.VISIBLE);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        final String strDate = format.format(calendar1.getTime());

        Orqa_get_data orqa_get_data = new Orqa_get_data(strDate, getContext());
        orqa_get_data.execute();

        barChartVertical.setOnBarClickListener(new BarChart.OnBarClickListener() {
            @Override
            public void onBarClick(BarChartModel barChartModel) {
                String taom_nomi = barChartModel.getBarText();
                String Soni = barChartModel.getBarValue_str();
                if (!taom_nomi.equals("")) {
                    Orqa_tasl orqa_tasl = new Orqa_tasl(getContext(), taom_nomi, Soni);
                    orqa_tasl.execute();
                }

            }
        });

    }

    public class Orqa_tasl extends AsyncTask<Void, Void, String> {
        Context context;
        ProgressDialog dialog;
        String taom_nomi, soni;
        String sana = Admin_Hisobot_oyna.txt_admin_hisob_sana.getText().toString();
        int xizmati = 0, taomsuma = 0;
        ArrayList<Admin_hisobot_taom_row_list> list_rows = new ArrayList<>();

        public Orqa_tasl(Context context, String ofit, String soni) {
            this.context = context;
            this.soni = soni;
            this.taom_nomi = ofit;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(context);
            dialog.setTitle(context.getString(R.string.iltimos_mal_yuklanmoqda));
            dialog.setIndeterminate(true);
            dialog.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            list_rows.clear();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
            Date convertedDate = new Date();
            String sana3 = "";
            try {
                convertedDate = dateFormat.parse(sana);
                SimpleDateFormat sdfnewformat = new SimpleDateFormat("yyyy-MM-dd");
                sana3 = sdfnewformat.format(convertedDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String url = "";
            list_rows.clear();
            try {
                url = url_address + Urllar.Php_hisob_taom_details + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_ZAKAZLAR, "UTF-8")
                        + "&sana1=" + URLEncoder.encode(sana3, "UTF-8")
                        + "&taom=" + URLEncoder.encode(taom_nomi.replace("'", "`"), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }
                                    if (tugadi) {
                                        String ofit_id = "";
                                        try {
                                            ofit_id = jsonObject.getString("ofit_id");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (ofit_id.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String soni = "";
                                            try {
                                                soni = jsonObject.getString("soni");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }


                                            String sql1 = "SELECT ismi FROM " + Login_oyna.TABLE_OFITSANT + " WHERE Id = '" + ofit_id + "'";
                                            Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData(sql1);
                                            if (cursor1.getCount() != 0) {
                                                cursor1.moveToFirst();
                                                do {
                                                    ofit_id = cursor1.getString(0);
                                                } while (cursor1.moveToNext());
                                            }
                                            list_rows.add(new Admin_hisobot_taom_row_list("" + i, ofit_id, soni));
                                        }
                                    }
                                }
                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }

                return xatolik;
            }
            return "";
        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            dialog.dismiss();
            if (aVoid.equals("off")) {
                Toast.makeText(getContext(), "Serverga ulanishda xatolik bo'ldi!", Toast.LENGTH_SHORT).show();
            } else {
                Shot_dialog(list_rows, taom_nomi, soni);
            }
        }
    }

    private void Shot_dialog(ArrayList<Admin_hisobot_taom_row_list> list_rows, String taom, String soni) {

        final Dialog dialog = new Dialog(getContext(), R.style.hisob_ozgart_oyna_di);
        dialog.setContentView(R.layout.hisob_taom_item);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.CENTER;
        wlp.flags &= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        window.setAttributes(wlp);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setTitle("");

        ListView list_hisob_item = dialog.findViewById(R.id.list_hisob_item);
        TextView txt_hisob_item_row_nomi = dialog.findViewById(R.id.txt_hisob_item_row_nomi);
        TextView txt_hisob_item_row_soni = dialog.findViewById(R.id.txt_hisob_item_row_umum_soni);
        Admin_hisobot_taom_adapter_row adapter = new Admin_hisobot_taom_adapter_row(getContext(), list_rows);
        list_hisob_item.setAdapter(adapter);


        txt_hisob_item_row_nomi.setText(String.format(getString(R.string.admin_hisobot_ofitsant_boyicha), taom));
        txt_hisob_item_row_soni.setText(soni);
        ImageView btn_iks = dialog.findViewById(R.id.btn_hisob_item_iks);
        btn_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();

    }


    public static class Orqa_get_data extends AsyncTask<Void, String, String> {

        BarChartModel barChartModel;
        int KATTASI = 0;
        String sql;
        ProgressDialog dialog;
        Context context;

        public Orqa_get_data(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);
            sonlari = 0;
            barChartVertical.clearAll();
        }

        @Override
        protected String doInBackground(Void... voids) {
            sonlari = 0;
            String url = "";
            try {

                url = url_address + Urllar.Php_hisob_taom_diag + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_ZAKAZLAR, "UTF-8")
                        + "&sana1=" + URLEncoder.encode(sql, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }


            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;
                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                try {
                                    KATTASI = json.getInt("max");
                                    publishProgress("0");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }

                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }
                                    if (tugadi) {
                                        String tovar_id = "";
                                        try {
                                            tovar_id = jsonObject.getString("tovar_id");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (tovar_id.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String nomi = "";
                                            try {
                                                nomi = jsonObject.getString("nomi");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String soni = "";
                                            try {
                                                soni = jsonObject.getString("soni");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }

                                            int so = 0;
                                            if (!soni.equals("")) {
                                                try {
                                                    so = Integer.parseInt(soni);

                                                } catch (NumberFormatException r) {
                                                    r.printStackTrace();
                                                    Login_oyna.XATOLIK_YOZISH(r);
                                                }
                                            }
                                            barChartModel = new BarChartModel();
                                            barChartModel.setBarValue(so);
                                            barChartModel.setBarValue_str(soni);
                                            Random rnd = new Random();
                                            barChartModel.setBarColor(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
                                            barChartModel.setBarTag(null);
                                            barChartModel.setBarText(nomi);
                                            publishProgress("1");
                                            try {
                                                Thread.sleep(200);
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                        }
                                    }
                                }

                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }
            }
            return "off";

        }

        int sonlari = 0;

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            dialog.dismiss();
            if (values[0].equals("1")) {
                sonlari++;
                barChartVertical.addBar(0, barChartModel);
            } else if (values[0].equals("0")) {
                if (KATTASI < 10) {
                    barChartVertical.setBarMaxValue(KATTASI + 5);
                } else {
                    barChartVertical.setBarMaxValue(KATTASI * 125 / 100);
                }
                layout_ofit_mal_yoq.setVisibility(View.GONE);
                txt_mal_yoq.setVisibility(View.GONE);
            } else if (values[0].equals("no")) {
                txt_mal_yoq.setText(R.string.ushbu_sanada_sotilgan_taomlar_yo_q);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_mal_yoq.setVisibility(View.VISIBLE);
            } else if (values[0].equals("off")) {
                Toast.makeText(context, "Serverga ulanishda xatolik bo'ldi", Toast.LENGTH_SHORT).show();
            }

        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            if (sonlari == 0) {
                txt_mal_yoq.setText(R.string.ushbu_sanada_sotilgan_taomlar_yo_q);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_mal_yoq.setVisibility(View.VISIBLE);
            } else {
                layout_ofit_mal_yoq.setVisibility(View.GONE);
                txt_mal_yoq.setVisibility(View.GONE);
            }
        }

    }

}
