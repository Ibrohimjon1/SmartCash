package com.balance.smart_cash.Spravichnik.Stol_Sp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Stol_sp_adapter extends BaseAdapter{
    private Context context;
    private ArrayList<Stol_sp_list>stol_sp_lists;

    public Stol_sp_adapter(Context context, ArrayList<Stol_sp_list> stol_sp_lists) {
        this.context = context;
        this.stol_sp_lists = stol_sp_lists;
    }

    @Override
    public int getCount() {
        return stol_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return stol_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    private class ViewHolder{
        TextView stol_sp_royhat_item_Num,stol_sp_royhat_item_id,stol_sp_royhat_item_Nomi;

    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        ViewHolder holder=new ViewHolder();
        Stol_sp_list stol_sp_list=stol_sp_lists.get(position);

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.stol_sp_royhat_item,null);

            holder.stol_sp_royhat_item_id=(TextView)row.findViewById(R.id.stol_sp_royhat_item_id);
            holder.stol_sp_royhat_item_Num=(TextView)row.findViewById(R.id.stol_sp_royhat_item_Num);
            holder.stol_sp_royhat_item_Nomi=(TextView)row.findViewById(R.id.stol_sp_royhat_item_Nomi);
            row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
        holder.stol_sp_royhat_item_id.setText(stol_sp_list.getId());
        holder.stol_sp_royhat_item_Num.setText(stol_sp_list.getNum());
        holder.stol_sp_royhat_item_Nomi.setText(stol_sp_list.getNomi());



        return row;
    }
}
