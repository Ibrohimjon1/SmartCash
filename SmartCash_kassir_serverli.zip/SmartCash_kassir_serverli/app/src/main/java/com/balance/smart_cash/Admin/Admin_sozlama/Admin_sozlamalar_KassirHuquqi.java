package com.balance.smart_cash.Admin.Admin_sozlama;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.smart_cash.R;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_KassirHuquqi extends Fragment {
    View parent_view;

    Switch switch_set_taom_ochirish, switch_set_ozgatirish_taom, switch_set_ochir_korish, switch_set_shot_korish, switch_set_pul_hisob_korish,
            switch_set_ofitsant_korish, switch_set_oldingi_korish;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    TextView txt_ochirish, txt_ozgartirish, ochir_korish, shot_korish, pul_korish, oldingi_korish, ofit_hisob_korish;

    @SuppressLint("CommitPrefEdits")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_kassirhuquqi, container, false);
        init();
        return parent_view;
    }

    public void init() {
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        txt_ochirish = parent_view.findViewById(R.id.cheki_ochirish);
        txt_ozgartirish = parent_view.findViewById(R.id.cheki_ozgartirish);
        ochir_korish = parent_view.findViewById(R.id.ochir_korish);
        shot_korish = parent_view.findViewById(R.id.shot_korsinmi);
        pul_korish = parent_view.findViewById(R.id.hisob_korsinmi);
        oldingi_korish = parent_view.findViewById(R.id.oldingi_korsinmi);
        ofit_hisob_korish = parent_view.findViewById(R.id.ofit_hisob_korsinmi);

        txt_ochirish.setText(R.string.cheki_chiqqan_taomni_o_chirsinmi);
        txt_ozgartirish.setText(R.string.cheki_chiqqan_taomni_o_zgartirsinmi);
        ochir_korish.setText(R.string.o_chirilgan_taomlar_ro_yhatini_ko_rsinmi);
        shot_korish.setText(R.string.to_lov_qilingan_shotlarni_ko_rsinmi);
        pul_korish.setText(R.string.kunlik_pul_hisobotini_ko_rsinmi);
        oldingi_korish.setText(R.string.oldingi_hisobotlarni_ko_rsinmi);
        ofit_hisob_korish.setText(R.string.ofitsantlar_hisobotini_ko_rsinmi);

        switch_set_taom_ochirish = (Switch) parent_view.findViewById(R.id.switch_set_taom_ochirish);
        switch_set_ozgatirish_taom = (Switch) parent_view.findViewById(R.id.switch_set_ozgatirish_taom);
        switch_set_ochir_korish = (Switch) parent_view.findViewById(R.id.switch_set_ochir_korish);
        switch_set_shot_korish = (Switch) parent_view.findViewById(R.id.switch_set_shot_korish);
        switch_set_pul_hisob_korish = (Switch) parent_view.findViewById(R.id.switch_set_pul_hisob_korish);
        switch_set_ofitsant_korish = (Switch) parent_view.findViewById(R.id.switch_set_ofitsant_korish);
        switch_set_oldingi_korish = (Switch) parent_view.findViewById(R.id.switch_set_oldingi_korish);
        Mal_toldirish();

        switch_set_ozgatirish_taom.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ozgartirish", 1);
                } else {
                    Mal_saqlash("ozgartirish", 0);
                }
            }
        });

        switch_set_taom_ochirish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ochirish", 1);
                } else {
                    Mal_saqlash("ochirish", 0);
                }
            }
        });

        switch_set_ochir_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ochir_royh_korish", 1);
                } else {
                    Mal_saqlash("ochir_royh_korish", 0);
                }
            }
        });

        switch_set_shot_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("tolov_korish", 1);
                } else {
                    Mal_saqlash("tolov_korish", 0);
                }
            }
        });
        switch_set_pul_hisob_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("pul_korish", 1);
                } else {
                    Mal_saqlash("pul_korish", 0);
                }
            }
        });

        switch_set_ofitsant_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ofitsant_korish", 1);
                } else {
                    Mal_saqlash("ofitsant_korish", 0);
                }
            }
        });
        switch_set_oldingi_korish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("oldingi_korish", 1);
                } else {
                    Mal_saqlash("oldingi_korish", 0);
                }
            }
        });

    }

    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    private void Mal_toldirish() {
        int ochirish = sharedPreferences.getInt("ochirish", 0);
        int ozgartirish = sharedPreferences.getInt("ozgartirish", 0);
        int ochir_royh_korish = sharedPreferences.getInt("ochir_royh_korish", 0);
        int tolov_korish = sharedPreferences.getInt("tolov_korish", 0);
        int pul_korish = sharedPreferences.getInt("pul_korish", 0);
        int ofitsant_korish = sharedPreferences.getInt("ofitsant_korish", 0);
        int oldingi_korish = sharedPreferences.getInt("oldingi_korish", 0);

        if (ozgartirish == 0) {
            Mal_saqlash("ozgartirish", 0);
            switch_set_ozgatirish_taom.setChecked(false);
        } else if (ozgartirish == 1) {
            switch_set_ozgatirish_taom.setChecked(true);
        }
        if (ochirish == 0) {
            Mal_saqlash("ochirish", 0);
            switch_set_taom_ochirish.setChecked(false);
        } else if (ochirish == 1) {
            switch_set_taom_ochirish.setChecked(true);
        }
        if (ochir_royh_korish == 0) {
            Mal_saqlash("ochir_royh_korish", 0);
            switch_set_ochir_korish.setChecked(false);
        } else if (ochir_royh_korish == 1) {
            switch_set_ochir_korish.setChecked(true);
        }
        if (tolov_korish == 0) {
            Mal_saqlash("tolov_korish", 0);
            switch_set_shot_korish.setChecked(false);
        } else if (tolov_korish == 1) {
            switch_set_shot_korish.setChecked(true);
        }
        if (pul_korish == 0) {
            Mal_saqlash("pul_korish", 0);
            switch_set_pul_hisob_korish.setChecked(false);
        } else if (pul_korish == 1) {
            switch_set_pul_hisob_korish.setChecked(true);
        }
        if (ofitsant_korish == 0) {
            Mal_saqlash("ofitsant_korish", 0);
            switch_set_ofitsant_korish.setChecked(false);
        } else if (ofitsant_korish == 1) {
            switch_set_ofitsant_korish.setChecked(true);
        }
        if (oldingi_korish == 0) {
            Mal_saqlash("oldingi_korish", 0);
            switch_set_oldingi_korish.setChecked(false);
        } else if (oldingi_korish == 1) {
            switch_set_oldingi_korish.setChecked(true);
        }

    }


}
