package com.balance.smart_cash.Otmenalar;

import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Otmena_oyna extends Fragment {

    private View parent_view;
    ListView listV;
    static ArrayList<Otmen_list> otmen_lists = new ArrayList<>();
    ImageView btn_yangilash;
    static Otmen_adpter otmen_adpter;
    static TextView txt_otmenaoyna_yoq;
    FragmentTransaction fragment;
    static View txt_otdel_oyna_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.otmena_oyna, container, false);

        Bosh_oyna.txt_asos_tool.setText(R.string.qaytarilgan_taom_royh);
        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);
        int oldingi_korish = Bosh_oyna.sharedPreferences.getInt("oldingi_korish", 1);
        if (oldingi_korish == 0) {
            Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
            Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.VISIBLE);
        } else {
            Bosh_oyna.layout_asos_sana.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_lock.setVisibility(View.GONE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.GONE);
        }

        Bosh_oyna.qaysi_oyna = Bosh_oyna.OTMEN_OYNA;
        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
//                final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
//                if (ofit_bormi == 0) {
//                    if (stol_bormi == 0) {
                changeFragment(new Saboy1_oyna());
//                    } else {
//                        changeFragment(new Stol_oyna());
//                    }
//                } else if (ofit_bormi == 1) {
//                    changeFragment(new Ofitsant_oyna());
//                }
            }
        });
        init();
        return parent_view;

    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public void init() {
        btn_yangilash = (ImageView) getActivity().findViewById(R.id.btn_asos_yangilash);
        txt_otmenaoyna_yoq = (TextView) parent_view.findViewById(R.id.txt_otmenaoyna_yoq);
        listV = (ListView) parent_view.findViewById(R.id.otmen_listview);
        txt_otdel_oyna_mal_yoq = parent_view.findViewById(R.id.txt_otdel_oyna_mal_yoq);
        otmen_adpter = new Otmen_adpter(getContext(), otmen_lists);
        listV.setAdapter(otmen_adpter);

        Calendar calendar1 = Calendar.getInstance();

        SimpleDateFormat format2 = new SimpleDateFormat("dd.MM.yyyy");
        String strDate2 = format2.format(calendar1.getTime());
        Bosh_oyna.txt_sana.setText(strDate2);

        final Calendar calendar = Calendar.getInstance();
        Bosh_oyna.year_x = calendar.get(Calendar.YEAR);
        Bosh_oyna.month_x = calendar.get(Calendar.MONTH);
        Bosh_oyna.day_x = calendar.get(Calendar.DAY_OF_MONTH);

        String sana = Bosh_oyna.txt_sana.getText().toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        Date convertedDate = new Date();
        String sana3 = "" ;
        try {
            convertedDate = dateFormat.parse(sana);
            SimpleDateFormat sdfnewformat = new SimpleDateFormat("yyyy-MM-dd");
            sana3 = sdfnewformat.format(convertedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
          Yangilash yangilash = new Yangilash(sana3, getContext());
        yangilash.execute();
        btn_yangilash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sana = Bosh_oyna.txt_sana.getText().toString();

                if (!sana.equals("")) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
                    Date convertedDate = new Date();
                    String sana3 = "" ;
                    try {
                        convertedDate = dateFormat.parse(sana);
                        SimpleDateFormat sdfnewformat = new SimpleDateFormat("yyyy-MM-dd");
                        sana3 = sdfnewformat.format(convertedDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    String sql = "SELECT * FROM " + Login_oyna.TABLE_OTMEN_TAOMLAR + " WHERE ochirilgan_sana LIKE '" + sana + "%'";
                    Yangilash yangilash = new Yangilash(sana3, getContext());
                    yangilash.execute();
                }
            }
        });

    }

    public static class Yangilash extends AsyncTask<Void, Void, String> {

        String sql;
        Context context;
        ProgressDialog dialog;

        public Yangilash(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

            otmen_lists.clear();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {
            String url = "";
            try {
                url = url_address + Urllar.Php_hisob_otmen + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_OTMEN_TAOMLAR, "UTF-8")
                        + "&sana=" + URLEncoder.encode(sql, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }
                                    if (tugadi) {
                                        String nomi = "";
                                        try {
                                            nomi = jsonObject.getString("nomi");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (nomi.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String soni = "";
                                            try {
                                                soni = jsonObject.getString("soni");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String buyurtma_sana = "";
                                            try {
                                                buyurtma_sana = jsonObject.getString("buyurtma_sana");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String ochirilgan_sana = "";
                                            try {
                                                ochirilgan_sana = jsonObject.getString("ochirilgan_sana");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String shot_raqam = "";
                                            try {
                                                shot_raqam = jsonObject.getString("shot_raqam");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String stol_raqam = "";
                                            try {
                                                stol_raqam = jsonObject.getString("stol_raqam");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String ofit_ismi = "";
                                            try {
                                                ofit_ismi = jsonObject.getString("ofit_ismi");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }

                                            otmen_lists.add(new Otmen_list(buyurtma_sana, ochirilgan_sana, stol_raqam, shot_raqam, soni, nomi, "" + i, ofit_ismi));
                                        }
                                    }
                                }

                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }
            }
            return "off";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                otmen_adpter.notifyDataSetChanged();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
            if (s.equals("ok")) {
                txt_otmenaoyna_yoq.setVisibility(View.GONE);
                txt_otdel_oyna_mal_yoq.setVisibility(View.GONE);
            } else {
                if (s.equals("off")) {
                    Toast.makeText(context, "Serverga ulanishda xatolik bo'ldi", Toast.LENGTH_SHORT).show();
                } else {
                    txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
                    txt_otmenaoyna_yoq.setVisibility(View.VISIBLE);

                }
                txt_otmenaoyna_yoq.setText(R.string.ushbu_sanada_qaytarilgan_yoq);
            }
            if (otmen_lists.size() == 0) {
                txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
                txt_otmenaoyna_yoq.setVisibility(View.VISIBLE);
                txt_otmenaoyna_yoq.setText(R.string.ushbu_sanada_qaytarilgan_yoq);
            } else {
                txt_otmenaoyna_yoq.setVisibility(View.GONE);
                txt_otdel_oyna_mal_yoq.setVisibility(View.GONE);
            }
        }
    }

}
