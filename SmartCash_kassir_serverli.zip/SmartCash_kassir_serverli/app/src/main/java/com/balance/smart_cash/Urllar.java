package com.balance.smart_cash;

/**
 * Created by Ibrohimjon on 12.09.2018.
 */

public class Urllar {
    public static String Check_user = "Check_user";
    public static String Tekshiruvchi = "Tekshiruvchi";
    public static String Tekshit_holat = "Tekshit_holat";

    public static String Download_soni = "Download_soni";
    public static String Download_foydalanuvchi = "Download_foydalanuvchi";
    public static String Download_otdel = "Download_otdel";
    public static String Download_menu = "Download_menu";
    public static String Download_taom= "Download_taom";
    public static String Download_stol = "Download_stol";
    public static String Download_ofitsant = "Download_ofitsant";
    public static String Download_printer= "Download_printer";

    public static String Upload_foydalanuvchi = "Upload_foydalanuvchi";
    public static String Upload_otdel = "Upload_otdel";
    public static String Upload_menu = "Upload_menu";
    public static String Upload_taom = "Upload_taom";
    public static String Upload_stol = "Upload_stol";
    public static String Upload_ofitsant = "Upload_ofitsant";
    public static String Upload_printer = "Upload_printer";
    public static String Upload_zakaz = "Upload_zakaz";
    public static String Upload_tolov = "Upload_tolov";
    public static String Upload_otmen = "Upload_otmen";
    public static String Upload_shot = "Upload_shot";
    public static String Spr_tozalash = "Spr_tozalash";
    public static String Spr_tozalash_rasmli = "Spr_tozalash_rasmli";

    public static String Php_hisob_ofitsant_details = "php_hisob_ofitsant_details";
    public static String Php_hisob_ofitsant  = "php_hisob_ofitsant";
    public static String Php_hisob_otdel_details = "php_hisob_otdel_details";
    public static String Php_hisob_otdel  = "php_hisob_otdel";
    public static String Php_hisob_otmen  = "php_hisob_otmen";
    public static String Php_hisob_shot_details  = "php_hisob_shot_details";
    public static String Php_hisob_shot  = "php_hisob_shot";
    public static String Php_hisob_taom_details = "php_hisob_taom_details";
    public static String Php_hisob_taom  = "php_hisob_taom";
    public static String Php_hisob_taom_diag  = "php_hisob_taom_diag";
    public static String Php_stol_olish= "php_stol_olish";
    public static String Php_saboy_olish= "php_saboy_olish";
    public static String Php_umum_shot_olish= "php_umum_shot_olish";
    public static String Php_umum_olish= "php_umum_olish";
    public static String Php_query_data= "php_query_data";
}
