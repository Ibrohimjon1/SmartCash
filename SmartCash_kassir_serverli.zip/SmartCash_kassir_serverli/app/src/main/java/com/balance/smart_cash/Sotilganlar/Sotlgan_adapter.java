package com.balance.smart_cash.Sotilganlar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Sotlgan_adapter extends BaseAdapter {
    Context context;
    private ArrayList<Sotilgan_list> sotilganLists;

    public Sotlgan_adapter(Context context, ArrayList<Sotilgan_list> sotilganLists) {
        this.context = context;
        this.sotilganLists = sotilganLists;
    }

    @Override
    public int getCount() {
        return sotilganLists.size();
    }

    @Override
    public Object getItem(int position) {
        return sotilganLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_num, txt_och_sana, txt_yop_sana, txt_stol, txt_shot, txt_sum, txt_ofit;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;

        ViewHolder holder = new ViewHolder();
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.yopilgan_shotlar_item, null);
            holder.txt_num = (TextView) row.findViewById(R.id.txt_yopiqShot_num);
            holder.txt_och_sana = (TextView) row.findViewById(R.id.txt_yopiqShot_och_sana);
            holder.txt_yop_sana = (TextView) row.findViewById(R.id.txt_yopiqShot_yop_sana);
            holder.txt_stol = (TextView) row.findViewById(R.id.txt_yopiqShot_stol);
            holder.txt_shot = (TextView) row.findViewById(R.id.txt_yopiqShot_shot);
            holder.txt_sum = (TextView) row.findViewById(R.id.txt_yopiqShot_sum);
            holder.txt_ofit = (TextView) row.findViewById(R.id.txt_yopiqShot_ofitsant);

            row.setTag(holder);

        } else {
            holder = (ViewHolder) row.getTag();
        }
        Sotilgan_list sotilgan_list = sotilganLists.get(position);

        holder.txt_num.setText(sotilgan_list.getNum());
        holder.txt_och_sana.setText(sotilgan_list.getOchil_sana());
        holder.txt_yop_sana.setText(sotilgan_list.getYop_sana());
        holder.txt_stol.setText(sotilgan_list.getStol());
        holder.txt_shot.setText(sotilgan_list.getShot());
        holder.txt_sum.setText(sotilgan_list.getSumm());
        holder.txt_ofit.setText(sotilgan_list.getOfit());


        return row;
    }
}
