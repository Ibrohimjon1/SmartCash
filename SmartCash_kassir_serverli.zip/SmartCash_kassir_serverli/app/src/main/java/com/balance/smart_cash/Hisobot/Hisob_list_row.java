package com.balance.smart_cash.Hisobot;

/**
 * Created by Ibrohimjon on 05.09.2018.
 */

public class Hisob_list_row {

    String Tartib;
    String Sana;
    String Shot;
    String Taom;
    String Xizmat;

    public Hisob_list_row(String tartib, String sana, String shot, String taom, String xizmat) {
        Tartib = tartib;
        Sana = sana;
        Shot = shot;
        Taom = taom;
        Xizmat = xizmat;
    }

    public String getTartib() {
        return Tartib;
    }

    public void setTartib(String tartib) {
        Tartib = tartib;
    }

    public String getSana() {
        return Sana;
    }

    public void setSana(String sana) {
        Sana = sana;
    }

    public String getShot() {
        return Shot;
    }

    public void setShot(String shot) {
        Shot = shot;
    }

    public String getTaom() {
        return Taom;
    }

    public void setTaom(String taom) {
        Taom = taom;
    }

    public String getXizmat() {
        return Xizmat;
    }

    public void setXizmat(String xizmat) {
        Xizmat = xizmat;
    }
}
