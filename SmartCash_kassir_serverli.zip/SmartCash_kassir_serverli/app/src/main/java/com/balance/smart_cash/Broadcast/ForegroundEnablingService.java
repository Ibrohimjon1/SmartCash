package com.balance.smart_cash.Broadcast;

/**
 * Created by Ibrohimjon on 16.09.2018.
 */

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;


public class ForegroundEnablingService extends Service {

    static ForegroundEnablingService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        if (startService(new Intent(this, Tekshiruvchi.class)) == null) {
        }


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
