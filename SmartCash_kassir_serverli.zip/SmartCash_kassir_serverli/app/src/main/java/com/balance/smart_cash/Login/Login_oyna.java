package com.balance.smart_cash.Login;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Admin.Admin_Assosiy_oyna.Admin_asosiy_oyna;
import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Broadcast.ForegroundEnablingService;
import com.balance.smart_cash.Broadcast.Hisoblovchi;
import com.balance.smart_cash.Broadcast.Tekshiruvchi;
import com.balance.smart_cash.DB.Sqlite_helper;
//import com.balance.smart_cash.Login.ui.NbButton;
import com.balance.smart_cash.Login.ui.NbButton;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Security.Security_screen;
import com.balance.smart_cash.mMySql.ConnectionClass;
import com.lb.auto_fit_textview.AutoResizeTextView;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Login_oyna extends AppCompatActivity implements View.OnClickListener {

    public static Sqlite_helper SQLITE_HELPER;
    AutoResizeTextView btn_0, btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9;
    ImageButton btn_c;
    NbButton btn_ok;
    ImageView edt_1, edt_2, edt_3, edt_4;
    TextView txt_loading;

    String birinchi = "", ikkinchi = "", uchinchi = "", tort = "";
    private Handler handler;
    private RelativeLayout rlContent;
    private Animator animator;
    public static String parol_spo = "";
    public static String foydalanuvhi_id = "";
    public static ProgressBar progress_login;
    final int ADMIN = 5162;
    SharedPreferences preferences;

    SharedPreferences.Editor editor;
    boolean ISHLAYDI = true;
    public static String TABLE_FOYDALANUVCHI = "FOYDALANUVCHI";
    public static String TABLE_OFITSANT = "OFITSANT";
    public static String TABLE_STOL_SONI = "STOL_SONI";
    public static String TABLE_YOLLAR = "YOLLAR";
    public static String TABLE_PRINTER = "PRINTER";
    public static String TABLE_OTDEL = "OTDEL";
    public static String TABLE_MENU = "MENU";
    public static String TABLE_TAOMLAR = "TAOMLAR";

    public static String TABLE_STOLLAR = "stollar";
    public static String TABLE_SHOTLAR = "shotlar";
    public static String TABLE_ZAKAZLAR = "zakazlar";
    public static String TABLE_TOLOVLAR = "tolovlar";
    public static String TABLE_OTMEN_TAOMLAR = "otmen_taomlar";

    public static String TABLE_XATOLIKLAR = "XATOLIKLAR";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_oyna);


        preferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
        editor = preferences.edit();
        btn_ok = (NbButton) findViewById(R.id.btn_login_ok);
        btn_0 = (AutoResizeTextView) findViewById(R.id.btn_login_0);
        btn_1 = (AutoResizeTextView) findViewById(R.id.btn_login_1);
        btn_2 = (AutoResizeTextView) findViewById(R.id.btn_login_2);
        btn_3 = (AutoResizeTextView) findViewById(R.id.btn_login_3);
        btn_4 = (AutoResizeTextView) findViewById(R.id.btn_login_4);
        btn_5 = (AutoResizeTextView) findViewById(R.id.btn_login_5);
        btn_6 = (AutoResizeTextView) findViewById(R.id.btn_login_6);
        btn_7 = (AutoResizeTextView) findViewById(R.id.btn_login_7);
        btn_8 = (AutoResizeTextView) findViewById(R.id.btn_login_8);
        btn_9 = (AutoResizeTextView) findViewById(R.id.btn_login_9);
        btn_c = (ImageButton) findViewById(R.id.btn_login_c);
        rlContent = (RelativeLayout) findViewById(R.id.relative_layout);
        txt_loading = (TextView) findViewById(R.id.txt_loading);
        progress_login = (ProgressBar) findViewById(R.id.progress_login);


        edt_1 = (ImageView) findViewById(R.id.edt_login_1);
        edt_2 = (ImageView) findViewById(R.id.edt_login_2);
        edt_3 = (ImageView) findViewById(R.id.edt_login_3);
        edt_4 = (ImageView) findViewById(R.id.edt_login_4);

        rlContent.setVisibility(View.VISIBLE);
        rlContent.getBackground().setAlpha(0);
        txt_loading.setVisibility(View.GONE);
        progress_login.setIndeterminate(false);
        progress_login.setVisibility(View.GONE);
        handler = new Handler();
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
                if (ISHLAYDI) {
                    String parol = birinchi + ikkinchi + uchinchi + tort;
                    if (!parol.equals("")) {

                        btn_ok.startAnim();
                        Cursor cursor = SQLITE_HELPER.getData("SELECT * FROM " + TABLE_FOYDALANUVCHI + " WHERE parol='" + parol + "'");
                        if (cursor.getCount() != 0) {
                            cursor.moveToFirst();
                            String id = cursor.getString(0);
                            final String ismi = cursor.getString(1);
                            String dostup = cursor.getString(2);
                            foydalanuvhi_id = ismi;
                            parol_spo = parol;
                            if (dostup.equals("0")) {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        final Intent intent = new Intent(Login_oyna.this, Admin_asosiy_oyna.class);
                                        intent.putExtra("Admin", "0");

                                        gotoNew(intent);
                                    }
                                }, 100);
                            } else if (dostup.equals("1")) {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        final Intent intent = new Intent(Login_oyna.this, Bosh_oyna.class);
                                        //跳转
                                        gotoNew(intent);
                                    }
                                }, 100);
                            }
                        } else {

                            DateFormat df = new SimpleDateFormat("Hmm");
                            String date = df.format(Calendar.getInstance().getTime());
                            int vaqt = 0;
                            if (!date.equals("")) {
                                try {
                                    vaqt = Integer.parseInt(date);
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);

                                }
                            }

                            int qiymat = vaqt * ADMIN;
                            String yar = "" + qiymat;
                            String paro = "";
                            if (yar.length() > 3) {
                                paro = yar.substring(0, 4);
                            } else {
                                paro = "" + ADMIN;
                            }
                            if (parol.equals(paro)) {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        Intent intent = new Intent(Login_oyna.this, Admin_asosiy_oyna.class);
                                        intent.putExtra("Admin", "1");
                                        gotoNew(intent);

                                    }
                                }, 100);

                            } else {

                                birinchi = "";
                                ikkinchi = "";
                                uchinchi = "";
                                tort = "";
                                edt_1.setVisibility(View.GONE);
                                edt_2.setVisibility(View.GONE);
                                edt_3.setVisibility(View.GONE);
                                edt_4.setVisibility(View.GONE);
                                Login_oyna.progress_login.setIndeterminate(false);
                                Login_oyna.progress_login.setVisibility(View.GONE);
                                btn_ok.init(Login_oyna.this);
                                new SweetAlertDialog(Login_oyna.this, SweetAlertDialog.ERROR_TYPE)
                                        .setTitleText("")
                                        .setContentText(getString(R.string.parol_notogri))
                                        .show();
                            }
                        }
                    }
                }

            }
        });

        edt_1.setVisibility(View.GONE);
        edt_2.setVisibility(View.GONE);
        edt_3.setVisibility(View.GONE);
        edt_4.setVisibility(View.GONE);

        btn_0.setOnClickListener(this);
        btn_1.setOnClickListener(this);
        btn_2.setOnClickListener(this);
        btn_3.setOnClickListener(this);
        btn_4.setOnClickListener(this);
        btn_5.setOnClickListener(this);
        btn_6.setOnClickListener(this);
        btn_7.setOnClickListener(this);
        btn_8.setOnClickListener(this);
        btn_9.setOnClickListener(this);
        btn_c.setOnClickListener(this);
    }


    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {

                return true;
            }
        }
        return false;
    }

    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static void TaskniTekshirish(Context context, int qa) {
        Orqa_fon hozirgi_vaqt = new Orqa_fon(context, qa);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            hozirgi_vaqt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            hozirgi_vaqt.execute();
        }

    }

    public static class Orqa_fon extends AsyncTask<Void, String, String> {
        ProgressDialog loading;
        Context context;
        int qaysi = 1;

        public Orqa_fon(Context context, int qaysi) {
            this.context = context;
            this.qaysi = qaysi;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {

            createData(context);

            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }

    public static void createData(Context context) {
        SQLITE_HELPER = new Sqlite_helper(context, "Kafe_base.sqlite", null, 1);

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_FOYDALANUVCHI + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, ismi VARCHAR,dostup VARCHAR, parol VARCHAR, yuklandi INTEGER DEFAULT 0)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_OFITSANT + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, ismi VARCHAR, foiz VARCHAR)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_STOL_SONI + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, soni INTEGER DEFAULT 1)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_YOLLAR + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, url VARCHAR)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_PRINTER + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, url VARCHAR, tipi VARCHAR, yuklandi INTEGER DEFAULT 0)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_OTDEL + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, rasmi BLOB, printer VARCHAR, yuklandi INTEGER DEFAULT 0)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_MENU + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, otdel_id VARCHAR, rasmi BLOB, yuklandi INTEGER DEFAULT 0)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_TAOMLAR + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, narxi VARCHAR, otdel_id VARCHAR, menu_id VARCHAR, rasmi BLOB, foizi VARCHAR, populyar INTEGER DEFAULT 0, printer VARCHAR, yuklandi INTEGER DEFAULT 0)");

        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS " + TABLE_XATOLIKLAR + " (Id INTEGER PRIMARY KEY AUTOINCREMENT, vaqt DATE, xatolik VARCHAR,yuklandi INTEGER DEFAULT 0)");

        ///////////////////////////////////////////

//        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS STOLLAR (Id INTEGER PRIMARY KEY AUTOINCREMENT, nomi VARCHAR, holati VARCHAR, ofit_id VARCHAR, shot_raqam VARCHAR, vaqti DATE)");
//
//        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS SHOTLAR (Id INTEGER PRIMARY KEY AUTOINCREMENT, shot_raqam INTEGER, ochilgan_vaqt DATE, yopilgan_sana DATE, ofit_id VARCHAR, stol_raqam VARCHAR,summa VARCHAR, yuklandi INTEGER DEFAULT 0)");
//
//        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS ZAKAZLAR (Id INTEGER PRIMARY KEY AUTOINCREMENT, tovar_id VARCHAR, nomi VARCHAR, narxi VARCHAR, soni VARCHAR, summasi VARCHAR, foizi VARCHAR, shot_raqam VARCHAR, ofit_id VARCHAR, vaqti DATE,printer VARCHAR, yuklandi INTEGER DEFAULT 0)");
//
//        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS TOLOVLAR (Id INTEGER PRIMARY KEY AUTOINCREMENT, shot_raqam VARCHAR, vaqti DATE, taom_sum VARCHAR, xizmat_sum VARCHAR, tolov_sum VARCHAR, bonus VARCHAR, naqd VARCHAR, plastik VARCHAR, stol_nomeri VARCHAR, yuklandi INTEGER DEFAULT 0)");
//
//        SQLITE_HELPER.queryData("CREATE TABLE IF NOT EXISTS OTMEN_TAOMLAR (Id INTEGER PRIMARY KEY AUTOINCREMENT, tovar_id VARCHAR, nomi VARCHAR, soni VARCHAR, buyurtma_sana DATE, ochirilgan_sana DATE, shot_raqam VARCHAR, stol_raqam VARCHAR, ofit_ismi VARCHAR, foy_id VARCHAR, yuklandi INTEGER DEFAULT 0)");
//

        Cursor cursor = SQLITE_HELPER.getData("SELECT * FROM " + TABLE_FOYDALANUVCHI);
        if (cursor.getCount() == 0) {
            String sql = "INSERT INTO " + TABLE_FOYDALANUVCHI + " VALUES (NULL, ?, ?, ?, 0)";
            SQLITE_HELPER.Mal_qoshish_3ta("Admin", "0", "0000", sql);
            SQLITE_HELPER.Mal_qoshish_3ta("Kassir", "1", "0110", sql);
        }
//
//        Cursor cursor_1 = SQLITE_HELPER.getData("SELECT * FROM OFITSANT");
//        if (cursor_1.getCount() == 0) {
//            String sql = "INSERT INTO OFITSANT VALUES (NULL, ?, 10)";
//            SQLITE_HELPER.Mal_qoshish_1ta("Abdullo", sql);
//            SQLITE_HELPER.Mal_qoshish_1ta("Mubina", sql);
//            SQLITE_HELPER.Mal_qoshish_1ta("Ziyoda", sql);
//            SQLITE_HELPER.Mal_qoshish_1ta("Oybek", sql);
//            SQLITE_HELPER.Mal_qoshish_1ta("Bekzod", sql);
//            SQLITE_HELPER.Mal_qoshish_1ta("Oygul", sql);
//            SQLITE_HELPER.Mal_qoshish_1ta("Qodir", sql);
//        }
//        Cursor cursor_2 = SQLITE_HELPER.getData("SELECT * FROM STOL_SONI");
//        if (cursor_2.getCount() == 0) {
//            String sql = "INSERT INTO STOL_SONI VALUES (NULL, ?)";
//            SQLITE_HELPER.Mal_qoshish_stol(30, sql);
//        }

//        Cursor cursor_3 = SQLITE_HELPER.getData("SELECT * FROM OTDEL");
//        if (cursor_3.getCount() == 0) {
//            String sql = "INSERT INTO OTDEL VALUES (NULL, ?, ?, ?, 0)";
//            SQLITE_HELPER.Mal_qoshish_3ta("Oshxona", "", "1", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Bar", "", "2", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Shashlik", "", "3", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Choy", "", "4", sql);
//        }
//
//        Cursor cursor_4 = SQLITE_HELPER.getData("SELECT * FROM PRINTER");
//        if (cursor_4.getCount() == 0) {
//            String sql = "INSERT INTO PRINTER VALUES (NULL, ?, ?, 1, 0)";
//            SQLITE_HELPER.Mal_qoshish_2ta("Oshxona", "192.168.1.60", sql);
//            SQLITE_HELPER.Mal_qoshish_2ta("Bar", "192.168.1.60", sql);
//            SQLITE_HELPER.Mal_qoshish_2ta("Tashqari", "192.168.1.60", sql);
//            SQLITE_HELPER.Mal_qoshish_2ta("Fast food", "192.168.1.60", sql);
//        }

//        Cursor cursor_5 = SQLITE_HELPER.getData("SELECT * FROM MENU");
//        if (cursor_5.getCount() == 0) {
//            String sql = "INSERT INTO MENU VALUES (NULL, ?, ?, ?, 0)";
//
//            SQLITE_HELPER.Mal_qoshish_3ta("Non choy", "1", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("1-taomlar", "1", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("2-taomlar", "1", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Qo'yiq taom", "1", "", sql);
//
//            SQLITE_HELPER.Mal_qoshish_3ta("Spirtli ichimliklar", "2", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Salqin ichimliklar", "2", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Zakuzkalar", "2", "", sql);
//
//            SQLITE_HELPER.Mal_qoshish_3ta("Shashliklar", "3", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Somsalar", "3", "", sql);
//
//            SQLITE_HELPER.Mal_qoshish_3ta("Pitsalar", "4", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Lavashlar", "4", "", sql);
//            SQLITE_HELPER.Mal_qoshish_3ta("Hot dog", "4", "", sql);
//
//        }

//        Cursor cursor_6 = SQLITE_HELPER.getData("SELECT * FROM TAOMLAR");
//        if (cursor_6.getCount() == 0) {
//            String sql = "INSERT INTO TAOMLAR VALUES (NULL, ?, ?, ?, ?, ?, ?, 0, ?, 0)";
//            SQLITE_HELPER.Mal_qoshish_tovar("Yog'li non", "1 500", "1", "1", "", "1", "1", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Yog'siz non", "1 000", "1", "1", "", "1", "1", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Ko'k choy", "500", "1", "1", "", "1", "1", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Qora choy", "500", "1", "1", "", "1", "1", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Asal choy", "1 000", "1", "1", "", "1", "1", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Novvot", "1 000", "1", "1", "", "1", "1", sql);
//
//
//            SQLITE_HELPER.Mal_qoshish_tovar("Osh", "7 000", "1", "2", "", "1", "2", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Lag'mon", "6 000", "1", "2", "", "1", "2", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Sho'rva", "7 500", "1", "2", "", "1", "2", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Mastava", "5 000", "1", "2", "", "0", "2", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Qo'g'irma lag'mon", "5 500", "1", "2", "", "1", "2", sql);
//
//            SQLITE_HELPER.Mal_qoshish_tovar("Qozon kabob", "11 500", "1", "3", "", "1", "3", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Do'lma", "7 500", "1", "3", "", "1", "3", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Siltama", "12 500", "1", "3", "", "1", "3", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Dum sho'rva", "13 000", "1", "3", "", "0", "3", sql);
//
//            SQLITE_HELPER.Mal_qoshish_tovar("Tandir", "15 500", "1", "4", "", "0", "4", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Bosma", "10 000", "1", "4", "", "0", "4", sql);
//            SQLITE_HELPER.Mal_qoshish_tovar("Osh", "7 500", "1", "4", "", "0", "4", sql);
//
//        }


    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void gotoNew(final Intent intent) {
        btn_ok.gotoNew();

        txt_loading.setVisibility(View.VISIBLE);
        rlContent.getBackground().setAlpha(255);

        int xc = (btn_ok.getLeft() + btn_ok.getRight()) / 2;
        int yc = (btn_ok.getTop() + btn_ok.getBottom()) / 2;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            animator = ViewAnimationUtils.createCircularReveal(rlContent, xc, yc, 0, 1111);
            animator.setDuration(200);
            animator.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {

                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startActivity(intent);
                            overridePendingTransition(R.anim.anim_in, R.anim.anim_out);
                            finish();
                        }
                    }, 150);
                }

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });
            animator.start();
        } else {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_in, R.anim.anim_out);
                    finish();
                }
            }, 150);
        }

    }

    @Override
    public void onBackPressed() {
//        Xabar();
        super.onBackPressed();
        ActivityCompat.finishAffinity(Login_oyna.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        edt_1.setVisibility(View.GONE);
        edt_2.setVisibility(View.GONE);
        edt_3.setVisibility(View.GONE);
        edt_4.setVisibility(View.GONE);
        birinchi = "";
        ikkinchi = "";
        uchinchi = "";
        tort = "";
        Security_screen.loadLocale(Login_oyna.this);
//        int tugadi = preferences.getInt("tugadi", 0);
//        String holat = preferences.getString("holati", "1");
//        String muddatlimi = preferences.getString("muddatlimi", "0");
//        if (!isMyServiceRunning(ForegroundEnablingService.class) && !isMyServiceRunning(Tekshiruvchi.class)) {
//            Intent intent = new Intent(this, ForegroundEnablingService.class);
//            startService(intent);
//        }
//        if (holat.equals("0")) {
//            Mal_saqlash("tugadi", 0);
//            Mal_saqlash("vaqt", 0);
//            ISHLAYDI = false;
//            final Dialog dialog = new Dialog(Login_oyna.this, R.style.hisob_ozgart_oyna_di);
//            dialog.setCanceledOnTouchOutside(false);
//            dialog.setCancelable(false);
//            dialog.setContentView(R.layout.tugadi_oyna);
//            dialog.setTitle("");
//            TextView txt_tugadi_mal = dialog.findViewById(R.id.txt_tugadi_mal);
//            Button btn_ok = (Button) dialog.findViewById(R.id.btn_tugagan_ok);
//            txt_tugadi_mal.setText(R.string.dastur_toxtatilgan);
//            btn_ok.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    dialog.cancel();
//                    ActivityCompat.finishAffinity(Login_oyna.this);
//                }
//            });
//            dialog.show();
//            stopService(new Intent(Login_oyna.this, Hisoblovchi.class));
////            }
//        } else {
//
//            if (muddatlimi.equals("0")) {
//                Mal_saqlash("tugadi", 0);
//                Mal_saqlash("vaqt", 0);
//                stopService(new Intent(Login_oyna.this, Hisoblovchi.class));
//
//            } else {
//                if (tugadi == 1) {
//                    final Dialog dialog = new Dialog(Login_oyna.this, R.style.hisob_ozgart_oyna_di);
//                    dialog.setCanceledOnTouchOutside(false);
//                    dialog.setCancelable(false);
//                    dialog.setContentView(R.layout.tugadi_oyna);
//                    dialog.setTitle("");
//                    TextView txt_tugadi_mal = dialog.findViewById(R.id.txt_tugadi_mal);
//                    Button btn_ok = (Button) dialog.findViewById(R.id.btn_tugagan_ok);
//                    txt_tugadi_mal.setText(R.string.dastur_muddati_tugadi);
//                    btn_ok.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            dialog.cancel();
//                            ActivityCompat.finishAffinity(Login_oyna.this);
//                        }
//                    });
//                    dialog.show();
//
//                } else {
//                    if (!isMyServiceRunning(Hisoblovchi.class)) {
//                        Intent intent = new Intent(this, Hisoblovchi.class);
//                        startService(intent);
//                    }
//                }
//            }
//
//        }

    }


    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    public void Xabar() {
        new SweetAlertDialog(Login_oyna.this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.ogohlantirish))
                .setContentText(getString(R.string.chiqishni_hohlaysizmi))
                .setCancelText("Yo'q")
                .setConfirmText("Ha")
                .showCancelButton(true)
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        // reuse previous dialog instance, keep widget user state, reset them if you need
                        sDialog.cancel();

                        // or you can new a SweetAlertDialog to show
                               /* sDialog.dismiss();
                                new SweetAlertDialog(SampleActivity.this, SweetAlertDialog.ERROR_TYPE)
                                        .setTitleText("Cancelled!")
                                        .setContentText("Your imaginary file is safe :)")
                                        .setConfirmText("OK")
                                        .show();*/
                    }
                })
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {

                        ActivityCompat.finishAffinity(Login_oyna.this);
                    }
                })
                .show();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btn_login_0: {
                Toldirish("0");
            }
            break;
            case R.id.btn_login_1: {
                Toldirish("1");
            }
            break;
            case R.id.btn_login_2: {
                Toldirish("2");
            }
            break;
            case R.id.btn_login_3: {
                Toldirish("3");
            }
            break;
            case R.id.btn_login_4: {
                Toldirish("4");
            }
            break;
            case R.id.btn_login_5: {
                Toldirish("5");
            }
            break;
            case R.id.btn_login_6: {
                Toldirish("6");
            }
            break;
            case R.id.btn_login_7: {
                Toldirish("7");
            }
            break;
            case R.id.btn_login_8: {
                Toldirish("8");
            }
            break;
            case R.id.btn_login_9: {
                Toldirish("9");
            }
            break;
            case R.id.btn_login_c: {
                Ochirish();
            }
            break;
        }
    }

    private void Ochirish() {
        if (!birinchi.equals("") && !ikkinchi.equals("") && !uchinchi.equals("") && !tort.equals("")) {
            tort = "";
            edt_4.setVisibility(View.GONE);
        } else if (!birinchi.equals("") && !ikkinchi.equals("") && !uchinchi.equals("") && tort.equals("")) {
            uchinchi = "";
            edt_3.setVisibility(View.GONE);
            edt_4.setVisibility(View.GONE);
        } else if (!birinchi.equals("") && !ikkinchi.equals("") && uchinchi.equals("") && tort.equals("")) {
            ikkinchi = "";
            edt_2.setVisibility(View.GONE);
            edt_3.setVisibility(View.GONE);
            edt_4.setVisibility(View.GONE);
        } else if (!birinchi.equals("") && ikkinchi.equals("") && uchinchi.equals("") && tort.equals("")) {
            birinchi = "";
            edt_1.setVisibility(View.GONE);
            edt_2.setVisibility(View.GONE);
            edt_3.setVisibility(View.GONE);
            edt_4.setVisibility(View.GONE);
        }
    }

    private void Toldirish(String son) {
        if (ISHLAYDI) {
            if (birinchi.equals("") && ikkinchi.equals("") && uchinchi.equals("") && tort.equals("")) {
                birinchi = son;
                edt_1.setVisibility(View.VISIBLE);
                edt_2.setVisibility(View.GONE);
                edt_3.setVisibility(View.GONE);
                edt_4.setVisibility(View.GONE);
            } else if (!birinchi.equals("") && ikkinchi.equals("") && uchinchi.equals("") && tort.equals("")) {
                ikkinchi = son;
                edt_1.setVisibility(View.VISIBLE);
                edt_2.setVisibility(View.VISIBLE);
                edt_3.setVisibility(View.GONE);
                edt_4.setVisibility(View.GONE);
            } else if (!birinchi.equals("") && !ikkinchi.equals("") && uchinchi.equals("") && tort.equals("")) {
                uchinchi = son;
                edt_1.setVisibility(View.VISIBLE);
                edt_2.setVisibility(View.VISIBLE);
                edt_3.setVisibility(View.VISIBLE);
                edt_4.setVisibility(View.GONE);
            } else if (!birinchi.equals("") && !ikkinchi.equals("") && !uchinchi.equals("") && tort.equals("")) {
                tort = son;
                edt_1.setVisibility(View.VISIBLE);
                edt_2.setVisibility(View.VISIBLE);
                edt_3.setVisibility(View.VISIBLE);
                edt_4.setVisibility(View.VISIBLE);
            }
        }
    }
    public static String getStackTrace(final Throwable throwable) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw, true);
        throwable.printStackTrace(pw);
        return sw.getBuffer().toString();
    }
    public static void XATOLIK_YOZISH(final Throwable throwable){
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        String strDate = format.format(calendar1.getTime());
        String sql7 = "INSERT INTO " + Login_oyna.TABLE_XATOLIKLAR + " VALUES (NULL,?,?,0)";
        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, getStackTrace(throwable), sql7);
    }
}
