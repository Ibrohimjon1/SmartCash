package com.balance.smart_cash.Yuklamalar;

import android.app.Activity;
import android.app.Dialog;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Security.Security_screen;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;
import com.harlan.progressbar.LineProgressBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Upload extends AsyncTask<Void, Integer, String> {

    Activity context;
    String urlAddre;
    Dialog dialog;
    View customProgress;
    View view, view2;
    TextView txt_malum;
    int qol_vaqt;

    public Upload(Activity context, String urlAddress, int qol_vaqt) {
        this.context = context;
        this.urlAddre = urlAddress;
        this.qol_vaqt = qol_vaqt;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog = new Dialog(context, R.style.hisob_ozgart_oyna_di);
        customProgress = LayoutInflater.from(context).inflate(R.layout.progress_dialog, null, false);
        dialog.setContentView(customProgress);
        dialog.setCancelable(false);
        txt_malum = customProgress.findViewById(R.id.txt_upload_mal);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        view = customProgress.findViewById(R.id.layout_upload_prog);
        view2 = customProgress.findViewById(R.id.layout_upload_success);
        view.setVisibility(View.VISIBLE);
        view2.setVisibility(View.GONE);
        txt_malum.setText(R.string.malumot_toplanmoqda);
    }

    int MAX_SONI = 0;
    int ket_soni = 0;

    @Override
    protected String doInBackground(Void... voids) {
        MAX_SONI = 0;
        String klent_id = urlAddre;
        Cursor cursor_foyda = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_FOYDALANUVCHI);
        if (cursor_foyda.getCount() != 0) {
            MAX_SONI += cursor_foyda.getCount();
        }
        Cursor cursor_otdel = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_OTDEL );
        if (cursor_otdel.getCount() != 0) {
            MAX_SONI += cursor_otdel.getCount();
        }
        Cursor cursor_menu = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_MENU);
        if (cursor_menu.getCount() != 0) {
            MAX_SONI += cursor_menu.getCount();
        }
        Cursor cursor_taom = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM "  + Login_oyna.TABLE_TAOMLAR);
        if (cursor_taom.getCount() != 0) {
            MAX_SONI += cursor_taom.getCount();
        }
        Cursor cursor_stol = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_STOL_SONI );
        if (cursor_stol.getCount() != 0) {
            MAX_SONI += cursor_stol.getCount();
        }
        Cursor cursor_printer = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_PRINTER);
        if (cursor_printer.getCount() != 0) {
            MAX_SONI += cursor_printer.getCount();
        }
//        Cursor cursor_zakaz = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM ZAKAZLAR WHERE yuklandi = '0'");
//        if (cursor_zakaz.getCount() != 0) {
//            MAX_SONI += cursor_zakaz.getCount();
//        }
//        Cursor cursor_tolov = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM TOLOVLAR WHERE yuklandi = '0'");
//        if (cursor_tolov.getCount() != 0) {
//            MAX_SONI += cursor_tolov.getCount();
//        }
//        Cursor cursor_otmen = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM OTMEN_TAOMLAR WHERE yuklandi = '0'");
//        if (cursor_otmen.getCount() != 0) {
//            MAX_SONI += cursor_otmen.getCount();
//        }
//        Cursor cursor_shotlar = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM SHOTLAR WHERE yuklandi = '0' AND yopilgan_sana IS NOT NULL");
//        if (cursor_shotlar.getCount() != 0) {
//            MAX_SONI += cursor_shotlar.getCount();
//        }
        if (cursor_foyda.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=foydalanuvchi";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-1);
            downloadData(url_delete);
            cursor_foyda.moveToFirst();
            do {
                String id = cursor_foyda.getString(0);
                String ismi = cursor_foyda.getString(1);
                String dostup = cursor_foyda.getString(2);
                String parol = cursor_foyda.getString(3);
                String url = "";
                ket_soni++;
                try {
                    url = url_address + Urllar.Upload_foydalanuvchi + ".php?id="
                            + URLEncoder.encode(id, "UTF-8")
                            + "&ismi=" + URLEncoder.encode(ismi.replace("'", "`"), "UTF-8")
                            + "&dostup=" + URLEncoder.encode(dostup, "UTF-8")
                            + "&parol=" + URLEncoder.encode(parol, "UTF-8")
                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                String qaytdi = downloadData(url);
                publishProgress(ket_soni);

            } while (cursor_foyda.moveToNext());
        }
        Cursor cursor_ofitsant = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_OFITSANT);
        if (cursor_ofitsant.getCount() != 0) {
            MAX_SONI += cursor_ofitsant.getCount();
        }
        if (cursor_ofitsant.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=ofitsant";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-11);
            downloadData(url_delete);
            cursor_ofitsant.moveToFirst();
            do {
                String id = cursor_ofitsant.getString(0);
                String ismi = cursor_ofitsant.getString(1);
                String dostup = cursor_ofitsant.getString(2);
                String parol = cursor_ofitsant.getString(3);
                String url = "";
                ket_soni++;
                try {
                    url = url_address + Urllar.Upload_ofitsant + ".php?id="
                            + URLEncoder.encode(id, "UTF-8")
                            + "&ismi=" + URLEncoder.encode(ismi.replace("'", "`"), "UTF-8")
                            + "&foiz=" + URLEncoder.encode(dostup, "UTF-8")
                            + "&paroli=" + URLEncoder.encode(parol, "UTF-8")
                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                String qaytdi = downloadData(url);
                publishProgress(ket_soni);

            } while (cursor_ofitsant.moveToNext());
        }

        if (cursor_otdel.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash_rasmli + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=otdel";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-2);
            downloadData(url_delete);
            cursor_otdel.moveToFirst();
            do {
                String id = cursor_otdel.getString(0);
                String nomi = cursor_otdel.getString(1);
                byte[] rasmi = cursor_otdel.getBlob(2);
                String printer = cursor_otdel.getString(3);

                Bitmap bitmap = BitmapFactory.decodeByteArray(rasmi, 0, rasmi.length);
                String rasm = "";
                if (bitmap != null && bitmap.getByteCount() != 0) {
                    rasm = getStringImage(bitmap);
                }
                String url = url_address + Urllar.Upload_otdel + ".php";
                ket_soni++;

                HashMap<String, String> data = new HashMap<>();

                data.put("id", id);
                data.put("nomi", nomi.replace("'", "`"));
                data.put("printer", printer);
                data.put("klent_id", klent_id);
                data.put("rasmi", rasm);

//                            "?id="
//                            + URLEncoder.encode(id, "UTF-8")
//                            + "&nomi=" + URLEncoder.encode(nomi.replace("'", "`"), "UTF-8")
//                            + "&printer=" + URLEncoder.encode(printer, "UTF-8")
//                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8")
//                            + "&rasmi=" + URLEncoder.encode(rasm, "UTF-8");

                String qaytdi = upload_Image(url, data);
                publishProgress(ket_soni);

            } while (cursor_otdel.moveToNext());
        }

        if (cursor_menu.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash_rasmli + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=menu";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-3);
            downloadData(url_delete);
            cursor_menu.moveToFirst();
            do {
                String id = cursor_menu.getString(0);
                String nomi = cursor_menu.getString(1);
                String otdel_id = cursor_menu.getString(2);
                byte[] rasmi = cursor_menu.getBlob(3);
                Bitmap bitmap = BitmapFactory.decodeByteArray(rasmi, 0, rasmi.length);
                String rasm = "";
                if (bitmap != null && bitmap.getByteCount() != 0) {
                    rasm = getStringImage(bitmap);
                }
                String url = url_address + Urllar.Upload_menu + ".php";
                ket_soni++;

                HashMap<String, String> data = new HashMap<>();

                data.put("id", id);
                data.put("nomi", nomi.replace("'", "`"));
                data.put("rasmi", rasm);
                data.put("otdel_id", otdel_id);
                data.put("klent_id", klent_id);

                String qaytdi = upload_Image(url, data);
                publishProgress(ket_soni);

            } while (cursor_menu.moveToNext());
        }

        if (cursor_taom.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash_rasmli + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=taomlar";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-4);
            downloadData(url_delete);
            cursor_taom.moveToFirst();
            do {
                String id = cursor_taom.getString(0);
                String nomi = cursor_taom.getString(1);
                String narxi = cursor_taom.getString(2);
                String otdel_id = cursor_taom.getString(3);
                String menu_id = cursor_taom.getString(4);
                byte[] rasmi = cursor_taom.getBlob(5);
                String foiz = cursor_taom.getString(6);
                String populyar = cursor_taom.getString(7);
                String printer = cursor_taom.getString(8);
                Bitmap bitmap = BitmapFactory.decodeByteArray(rasmi, 0, rasmi.length);
                String rasm = "";
                if (bitmap != null && bitmap.getByteCount() != 0) {
                    rasm = getStringImage(bitmap);
                }
                String url = "";
                ket_soni++;
                url = url_address + Urllar.Upload_taom + ".php";

                HashMap<String, String> data = new HashMap<>();

                data.put("id", id);
                data.put("nomi", nomi.replace("'", "`"));
                data.put("narxi", narxi);
                data.put("otdel_id", otdel_id);
                data.put("menu_id", menu_id);
                data.put("rasmi", rasm);
                data.put("foiz", foiz);
                data.put("populyar", populyar);
                data.put("printer", printer);
                data.put("klent_id", klent_id);
                String qaytdi = upload_Image(url, data);
                publishProgress(ket_soni);

            } while (cursor_taom.moveToNext());
        }

        if (cursor_stol.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=stol_soni";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-5);
            downloadData(url_delete);
            cursor_stol.moveToFirst();
            do {
                String id = cursor_stol.getString(0);
                String soni = cursor_stol.getString(1);
                String url = "";
                ket_soni++;
                try {
                    url = url_address + Urllar.Upload_stol + ".php?id="
                            + URLEncoder.encode(id, "UTF-8")
                            + "&soni=" + URLEncoder.encode(soni, "UTF-8")
                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                String qaytdi = downloadData(url);
                publishProgress(ket_soni);

            } while (cursor_stol.moveToNext());
        }
        if (cursor_printer.getCount() != 0) {
            String url_delete = "";
            try {
                url_delete = url_address + Urllar.Spr_tozalash + ".php?klent_id=" +
                        URLEncoder.encode(klent_id, "UTF-8") +
                        "&table=printer";
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }
            publishProgress(-6);
            downloadData(url_delete);
            cursor_printer.moveToFirst();
            do {
                String id = cursor_printer.getString(0);
                String nomi = cursor_printer.getString(1);
                String urlw = cursor_printer.getString(2);
                String url = "";
                ket_soni++;
                try {
                    url = url_address + Urllar.Upload_printer + ".php?id="
                            + URLEncoder.encode(id, "UTF-8")
                            + "&nomi=" + URLEncoder.encode(nomi.replace("'", "`"), "UTF-8")
                            + "&url=" + URLEncoder.encode(urlw, "UTF-8")
                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                }
                String qaytdi = downloadData(url);
                publishProgress(ket_soni);

            } while (cursor_printer.moveToNext());
        }
//        if (cursor_zakaz.getCount() != 0) {
//
//            publishProgress(-7);
//            cursor_zakaz.moveToFirst();
//            do {
//                String id = cursor_zakaz.getString(0);
//                String tov_id = cursor_zakaz.getString(1);
//                String nomi = cursor_zakaz.getString(2);
//                String narxi = cursor_zakaz.getString(3);
//                String soni = cursor_zakaz.getString(4);
//                String summasi = cursor_zakaz.getString(5);
//                String foizi = cursor_zakaz.getString(6);
//                String shot_raqam = cursor_zakaz.getString(7);
//                String ofit_id = cursor_zakaz.getString(8);
//                String vaqti = cursor_zakaz.getString(9);
//                String url = "";
//                ket_soni++;
//                try {
//                    url = url_address + Urllar.Upload_zakaz + ".php?id="
//                            + URLEncoder.encode(id, "UTF-8")
//                            + "&Taom_id=" + URLEncoder.encode(tov_id, "UTF-8")
//                            + "&Taom_nomi=" + URLEncoder.encode(nomi.replace("'", "`"), "UTF-8")
//                            + "&Taom_narxi=" + URLEncoder.encode(narxi, "UTF-8")
//                            + "&Taom_Soni=" + URLEncoder.encode(soni, "UTF-8")
//                            + "&Summa=" + URLEncoder.encode(summasi, "UTF-8")
//                            + "&Foiz=" + URLEncoder.encode(foizi, "UTF-8")
//                            + "&Shot_raqam=" + URLEncoder.encode(shot_raqam, "UTF-8")
//                            + "&Ofitsant_id=" + URLEncoder.encode(ofit_id.replace("'", "`"), "UTF-8")
//                            + "&Vaqt=" + URLEncoder.encode(vaqti, "UTF-8")
//                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                    Calendar calendar1 = Calendar.getInstance();
//                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
//                    String strDate = format.format(calendar1.getTime());
//                    String sql7 = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
//                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql7);
//                }
//                String qaytdi = downloadData(url);
//                publishProgress(ket_soni);
//                if (qaytdi.equals("ok")) {
//                    String sql = "UPDATE ZAKAZLAR SET yuklandi = '1' WHERE Id = '" + id + "'";
//                    Login_oyna.SQLITE_HELPER.queryData(sql);
//                }
//
//            } while (cursor_zakaz.moveToNext());
//        }
//        if (cursor_tolov.getCount() != 0) {
//
//            publishProgress(-8);
//            cursor_tolov.moveToFirst();
//            do {
//                String id = cursor_tolov.getString(0);
//                String shot_raqam = cursor_tolov.getString(1);
//                String vaqti = cursor_tolov.getString(2);
//                String taom_sum = cursor_tolov.getString(3);
//                String xizmat_sum = cursor_tolov.getString(4);
//                String tolov_sum = cursor_tolov.getString(5);
//                String bonus = cursor_tolov.getString(6);
//                String naqd = cursor_tolov.getString(7);
//                String plastik = cursor_tolov.getString(8);
//                String stol_nomeri = cursor_tolov.getString(9);
//                String url = "";
//                ket_soni++;
//                try {
//                    url = url_address + Urllar.Upload_tolov + ".php?id="
//                            + URLEncoder.encode(id, "UTF-8")
//                            + "&Shot_Raqam=" + URLEncoder.encode(shot_raqam, "UTF-8")
//                            + "&Vaqt=" + URLEncoder.encode(vaqti, "UTF-8")
//                            + "&Taom_sum=" + URLEncoder.encode(taom_sum, "UTF-8")
//                            + "&Xizmat_sum=" + URLEncoder.encode(xizmat_sum, "UTF-8")
//                            + "&Tolov_sum=" + URLEncoder.encode(tolov_sum, "UTF-8")
//                            + "&Bonus=" + URLEncoder.encode(bonus, "UTF-8")
//                            + "&Naqd=" + URLEncoder.encode(naqd, "UTF-8")
//                            + "&plastik=" + URLEncoder.encode(plastik, "UTF-8")
//                            + "&Stol_nomeri=" + URLEncoder.encode(stol_nomeri, "UTF-8")
//                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                    Calendar calendar1 = Calendar.getInstance();
//                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
//                    String strDate = format.format(calendar1.getTime());
//                    String sql7 = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
//                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql7);
//                }
//                String qaytdi = downloadData(url);
//                publishProgress(ket_soni);
//                if (qaytdi.equals("ok")) {
//                    String sql = "UPDATE TOLOVLAR SET yuklandi = '1' WHERE Id = '" + id + "'";
//                    Login_oyna.SQLITE_HELPER.queryData(sql);
//                }
//
//            } while (cursor_tolov.moveToNext());
//        }
//        if (cursor_otmen.getCount() != 0) {
//
//            publishProgress(-9);
//            cursor_otmen.moveToFirst();
//            do {
//                String id = cursor_otmen.getString(0);
//                String Taom_id = cursor_otmen.getString(1);
//                String Taom_Nomi = cursor_otmen.getString(2);
//                String Taom_Soni = cursor_otmen.getString(3);
//                String Buyurtma_sana = cursor_otmen.getString(4);
//                String Ochirilgan_sana = cursor_otmen.getString(5);
//                String Shot_raqam = cursor_otmen.getString(6);
//                String Stol_raqam = cursor_otmen.getString(7);
//                String Ofitsant_Nomi = cursor_otmen.getString(8);
//                String Foydalanuvchi_id = cursor_otmen.getString(9);
//                String url = "";
//                ket_soni++;
//                try {
//                    url = url_address + Urllar.Upload_otmen + ".php?id="
//                            + URLEncoder.encode(id, "UTF-8")
//                            + "&Taom_id=" + URLEncoder.encode(Taom_id, "UTF-8")
//                            + "&Taom_Nomi=" + URLEncoder.encode(Taom_Nomi.replace("'", "`"), "UTF-8")
//                            + "&Taom_Soni=" + URLEncoder.encode(Taom_Soni, "UTF-8")
//                            + "&Buyurtma_sana=" + URLEncoder.encode(Buyurtma_sana, "UTF-8")
//                            + "&Ochirilgan_sana=" + URLEncoder.encode(Ochirilgan_sana, "UTF-8")
//                            + "&Shot_raqam=" + URLEncoder.encode(Shot_raqam, "UTF-8")
//                            + "&Stol_raqam=" + URLEncoder.encode(Stol_raqam, "UTF-8")
//                            + "&Ofitsant_Nomi=" + URLEncoder.encode(Ofitsant_Nomi.replace("'", "`"), "UTF-8")
//                            + "&Foydalanuvchi_id=" + URLEncoder.encode(Foydalanuvchi_id.replace("'", "`"), "UTF-8")
//                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                    Calendar calendar1 = Calendar.getInstance();
//                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
//                    String strDate = format.format(calendar1.getTime());
//                    String sql7 = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
//                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql7);
//                }
//                String qaytdi = downloadData(url);
//                publishProgress(ket_soni);
//                if (qaytdi.equals("ok")) {
//                    String sql = "UPDATE OTMEN_TAOMLAR SET yuklandi = '1' WHERE Id = '" + id + "'";
//                    Login_oyna.SQLITE_HELPER.queryData(sql);
//                }
//
//            } while (cursor_otmen.moveToNext());
//        }
//        if (cursor_shotlar.getCount() != 0) {
//
//            publishProgress(-10);
//            cursor_shotlar.moveToFirst();
//            do {
//                String id = cursor_shotlar.getString(0);
//                String Shot_Raqam = cursor_shotlar.getString(1);
//                String Ochilgan_vaqt = cursor_shotlar.getString(2);
//                String Yopilgan_sana = cursor_shotlar.getString(3);
//                String Ofitsant_id = cursor_shotlar.getString(4);
//                String Stol_raqam = cursor_shotlar.getString(5);
//                String Summa = cursor_shotlar.getString(6);
//                String url = "";
//                ket_soni++;
//                try {
//                    url = url_address + Urllar.Upload_shot + ".php?id="
//                            + URLEncoder.encode(id, "UTF-8")
//                            + "&Shot_Raqam=" + URLEncoder.encode(Shot_Raqam, "UTF-8")
//                            + "&Ochilgan_vaqt=" + URLEncoder.encode(Ochilgan_vaqt, "UTF-8")
//                            + "&Yopilgan_sana=" + URLEncoder.encode(Yopilgan_sana, "UTF-8")
//                            + "&Ofitsant_id=" + URLEncoder.encode(Ofitsant_id, "UTF-8")
//                            + "&Stol_raqam=" + URLEncoder.encode(Stol_raqam, "UTF-8")
//                            + "&Summa=" + URLEncoder.encode(Summa, "UTF-8")
//                            + "&klent_id=" + URLEncoder.encode(klent_id, "UTF-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                    Calendar calendar1 = Calendar.getInstance();
//                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
//                    String strDate = format.format(calendar1.getTime());
//                    String sql7 = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
//                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql7);
//                }
//                String qaytdi = downloadData(url);
//                publishProgress(ket_soni);
//                if (qaytdi.equals("ok")) {
//                    String sql = "UPDATE SHOTLAR SET yuklandi = '1' WHERE Id = '" + id + "'";
//                    Login_oyna.SQLITE_HELPER.queryData(sql);
//                }
//
//            } while (cursor_shotlar.moveToNext());
//        }

//        if (qol_vaqt == 1) {
//            String sql_del_sot = "DELETE FROM ZAKAZLAR WHERE yuklandi = '1'";
//            String sql_del_otmen = "DELETE FROM OTMEN_TAOMLAR WHERE yuklandi = '1'";
//            String sql_del_tolov = "DELETE FROM TOLOVLAR WHERE yuklandi = '1'";
//            String sql_del_shot = "DELETE FROM SHOTLAR WHERE yuklandi = '1'";
//            String sql_del_stol = "DELETE FROM STOLLAR";
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_sot);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_otmen);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_tolov);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_shot);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_stol);
//        } else if (qol_vaqt != 2) {
//            String sql_del_sot = "DELETE FROM ZAKAZLAR WHERE vaqti < '" + Oldingi_sana(qol_vaqt) + " 00:00:00' AND yuklandi = '1'";
//            String sql_del_otmen = "DELETE FROM OTMEN_TAOMLAR WHERE ochirilgan_sana < '" + Oldingi_sana(qol_vaqt) + " 00:00:00' AND yuklandi = '1'";
//            String sql_del_tolov = "DELETE FROM TOLOVLAR WHERE vaqti < '" + Oldingi_sana(qol_vaqt) + " 00:00:00' AND yuklandi = '1'";
//            String sql_del_shot = "DELETE FROM SHOTLAR WHERE yopilgan_sana < '" + Oldingi_sana(qol_vaqt) + " 00:00:00' AND yuklandi = '1'";
//            String sql_del_stol = "DELETE FROM STOLLAR WHERE vaqti < '" + Oldingi_sana(qol_vaqt) + " 00:00:00'";
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_sot);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_otmen);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_tolov);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_shot);
//            Login_oyna.SQLITE_HELPER.queryData(sql_del_stol);
//        }
        return "";
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        int progress = values[0];
        if (progress == -1) {
            txt_malum.setText(R.string.foydala_jonat);
        } else if (progress == -2) {
            txt_malum.setText(R.string.otdel_jonat);
        } else if (progress == -3) {
            txt_malum.setText(R.string.menu_jonat);
        } else if (progress == -4) {
            txt_malum.setText(R.string.taom_jonat);
        } else if (progress == -5) {
            txt_malum.setText(R.string.stol_jonat);
        } else if (progress == -6) {
            txt_malum.setText(R.string.printer_jonat);
        } else if (progress == -7) {
            txt_malum.setText(R.string.sotil_jonat);
        } else if (progress == -8) {
            txt_malum.setText(R.string.tolov_jonat);
        } else if (progress == -9) {
            txt_malum.setText(R.string.otmen_jonat);
        } else if (progress == -10) {
            txt_malum.setText(R.string.shot_jonat);
        }  else if (progress == -11) {
            txt_malum.setText("Ofitsantlar jo'natilmoqda!");
        }else {
            double prog = (double) progress / (double) MAX_SONI;
            double pr = (prog * 100);
            LineProgressBar line1 = (LineProgressBar) customProgress.findViewById(R.id.line1);
            line1.setProgress((int) pr);
        }
    }

    Animation animation, animation1;

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        animation = AnimationUtils.loadAnimation(context, R.anim.slide_in_right);
        animation1 = AnimationUtils.loadAnimation(context, R.anim.hide);
        TextView txt_ok = customProgress.findViewById(R.id.txt_upload_ok);
        view.setAnimation(animation1);
        view.setVisibility(View.GONE);
        view2.setVisibility(View.VISIBLE);
        view2.setAnimation(animation);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


    }

    public String Oldingi_sana(int sana) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar c = Calendar.getInstance();
        //Incrementing the date by 1 day
        c.add(Calendar.DAY_OF_MONTH, sana);
        return sdf.format(c.getTime());
    }


    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;

    }

    private BufferedReader reader = null;

    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

    URL url;

    private String upload_Image(String urlAdd, HashMap<String, String> postDataParams) {
        try {
            url = new URL(urlAdd);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);


            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(postDataParams));
            writer.flush();
            writer.close();
            os.close();

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpsURLConnection.HTTP_OK) {
                InputStream br = new BufferedInputStream(conn.getInputStream());
                reader = new BufferedReader(new InputStreamReader(br));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        } catch (ProtocolException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        } catch (IOException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        } catch (JSONException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
        }
        return "no";
    }

    private String downloadData(String urlAdd) {
        HttpURLConnection con = Connector.connection(urlAdd);
        if (con == null) {
            return context.getString(R.string.internetni_tekshir);

        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null && Security_screen.isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            Login_oyna.XATOLIK_YOZISH(e);
            xatolikar = xatolikar + " // " + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolikar = xatolikar + " // " + e.getMessage();
                }
            }
            con.disconnect();
        }
        return context.getString(R.string.internetni_tekshir) + "  " + xatolikar;
    }
}
