package com.balance.smart_cash.Asosiy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.balance.smart_cash.R;

import java.util.ArrayList;

public class Stol_adapter extends BaseAdapter {

    private final Context mContext;
    private ArrayList<Stol_list> stollar;

    // 1
    public Stol_adapter(Context context, ArrayList<Stol_list> stollar) {
        this.mContext = context;
        this.stollar = stollar;
    }

    // 2
    @Override
    public int getCount() {
        return stollar.size();
    }

    // 3
    @Override
    public long getItemId(int position) {
        return 0;
    }

    // 4
    @Override
    public Object getItem(int position) {
        return null;
    }

    // 5
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 1
        Stol_list stol_list = stollar.get(position);

        // 2
        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.stol_item, null);

        }
        // 3
        RelativeLayout layout = (RelativeLayout) convertView.findViewById(R.id.layout_stol_item);
        final TextView txt_holati = (TextView) convertView.findViewById(R.id.txt_stol_item_holati);
        final TextView txt_ismi = (TextView) convertView.findViewById(R.id.txt_stol_item_ismi);
        final TextView txt_ofit_id = (TextView) convertView.findViewById(R.id.txt_stol_item_ofit_id);
        final TextView txt_shot_id = (TextView) convertView.findViewById(R.id.txt_stol_item_shot_id);
        final TextView txt_nomi = (TextView) convertView.findViewById(R.id.txt_stol_item_raqam);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.image_stol);

        txt_nomi.setText(stol_list.getRaqam());
        txt_holati.setText(String.valueOf(stol_list.getHolati()));
        txt_ofit_id.setText(stol_list.getOfit_id());
        if (!stol_list.getIsmi().equals("Ofitsant yo'q")) {
            txt_ismi.setText(stol_list.getIsmi());
        } else {
            txt_ismi.setText("");
        }
        txt_shot_id.setText(stol_list.getShot_id());
        int holati = stol_list.getHolati();
        if (holati == 0) {
            imageView.setImageResource(R.drawable.stol_bosh);
            layout.setBackgroundResource(R.drawable.card_selector);
        } else if (holati == 1) {
            imageView.setImageResource(R.drawable.stol_bosh_odampng);
            layout.setBackgroundResource(R.drawable.card_selector_qizil);
        } else if (holati == 2){
            imageView.setImageResource(R.drawable.stol_bosh_odampng);
            layout.setBackgroundResource(R.drawable.card_selector_ozini);
        }
        Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.slide_in_right);
        convertView.startAnimation(animation);
        return convertView;
    }

}