package com.balance.smart_cash.Saboy1;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.smart_cash.Asosiy.Bosh_oyna;
import com.balance.smart_cash.Asosiy.Stol_list;
import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Ofitsant.Ofitsant_oyna;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Umumiy.Umumiy_oyna;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.Connector;
import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLNonTransientConnectionException;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

/**
 * Created by Hunter on 05.09.2018.
 */

public class Saboy1_oyna extends Fragment {
    private View parent_view;
    GridView gv;
    static ArrayList<Saboy1_list> saboy1Lists = new ArrayList<>();
    static Saboy1_adapter saboy1_adapter;
    FragmentTransaction fragment;
    public static Activity saboy_activit;
    public static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.saboy1_oyna, container, false);
        saboy_activit = getActivity();
        Bosh_oyna.txt_asos_tool.setText(R.string.saboy_royh);
        final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
        final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
//        if (ofit_bormi == 0) {
//            if (stol_bormi == 0) {
//                Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.nav_icon);
        Bosh_oyna.btn_asos_saboy.setVisibility(View.VISIBLE);
        Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
        Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
//            } else {
//                Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);
//                Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.stol_bosh);
//            }
//        } else if (ofit_bormi == 1) {
        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.nav_icon);
        Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.waiter);
//        }
        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
//                if (ofit_bormi == 0) {
//                    if (stol_bormi == 0) {
//                        Bosh_oyna.drawer.openDrawer(Gravity.LEFT);
//                    } else {
//                        changeFragment(new Stol_oyna());
//                    }
//                } else if (ofit_bormi == 1) {
//                    changeFragment(new Ofitsant_oyna());
//                }

                Bosh_oyna.drawer.openDrawer(Gravity.LEFT);
            }
        });
        Bosh_oyna.btn_asos_saboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
//                if (ofit_bormi == 0) {
//                    changeFragment(new Stol_oyna());
//                } else if (ofit_bormi == 1) {
                changeFragment(new Ofitsant_oyna());
//                }
            }
        });
        init();
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public void init() {
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        gv = (GridView) parent_view.findViewById(R.id.saboy_Grid);
        saboy1_adapter = new Saboy1_adapter(getContext(), saboy1Lists);
        gv.setAdapter(saboy1_adapter);

        Get_saboy_Async async = new Get_saboy_Async(getContext());
        async.execute();

        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView shot = (TextView) view.findViewById(R.id.txt_saboy1_item_id);
                TextView vaqti = (TextView) view.findViewById(R.id.txt_saboy1_item_vaqt);
                String shot1 = shot.getText().toString().trim();
                String vaq = vaqti.getText().toString().trim();
                if (shot1.equals("plus")) {
                    Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                    intent.putExtra("stol", "Saboy");
                    intent.putExtra("ofit", "Saboy");
                    intent.putExtra("shot", "yangi");
                    intent.putExtra("vaqti", "");
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                    intent.putExtra("stol", "Saboy");
                    intent.putExtra("ofit", "Saboy");
                    intent.putExtra("shot", shot1);
                    intent.putExtra("vaqti", vaq);
                    startActivity(intent);
                }
            }
        });


    }


    public static class Get_saboy_Async extends AsyncTask<Void, Void, String> {
        final Handler uiHandler = new Handler();

        ProgressDialog dialog;
        Context context;

        public Get_saboy_Async(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            saboy1Lists.clear();
            if (Saboy1_oyna.saboy_activit != null) {
                dialog = new ProgressDialog(Saboy1_oyna.saboy_activit);
                dialog.setTitle(context.getString(R.string.iltimos_mal_yuklanmoqda));
                dialog.setIndeterminate(true);
                dialog.show();
            }
            layout_ofit_mal_yoq.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(Void... voids) {
            String url = "";
            try {
                url = url_address + Urllar.Php_saboy_olish + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_SHOTLAR, "UTF-8");

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            saboy1Lists.clear();
            saboy1Lists.add(new Saboy1_list("plus", "0", ""));
            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }
                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }

                                    if (tugadi) {
                                        String shot_raqam = "";
                                        try {
                                            shot_raqam = jsonObject.getString("shot_raqam");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (shot_raqam.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {

                                            String ochilgan_vaqt = "";
                                            try {
                                                ochilgan_vaqt = jsonObject.getString("ochilgan_vaqt");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }

                                            saboy1Lists.add(new Saboy1_list(shot_raqam, String.valueOf(i), ochilgan_vaqt));
                                        }
                                    }
                                }

                                return "ok";
                            }
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }
            }
            return "off";
//            return LoadData();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            if (s.equals("ok")) {
                try {
                    saboy1_adapter.notifyDataSetChanged();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
            } else {
                saboy1Lists.clear();
                saboy1Lists.add(new Saboy1_list("plus", "0", ""));
                try {
                    saboy1_adapter.notifyDataSetChanged();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
                if (s.equals("off")) {
                    Toast.makeText(context, "Serverga ulanib bo'lmayapti!", Toast.LENGTH_SHORT).show();
                } else {
                    layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                }
            }
            if (saboy1Lists.size() == 0) {
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            } else {

            }
        }
    }


}
