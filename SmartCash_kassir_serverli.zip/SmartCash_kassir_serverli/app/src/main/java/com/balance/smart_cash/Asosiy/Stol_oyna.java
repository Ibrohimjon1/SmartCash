package com.balance.smart_cash.Asosiy;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.balance.smart_cash.Login.Login_oyna;
import com.balance.smart_cash.Ofitsant.Ofitsant_oyna;
import com.balance.smart_cash.Otmenalar.Otmen_list;
import com.balance.smart_cash.R;
import com.balance.smart_cash.Saboy1.Saboy1_oyna;
import com.balance.smart_cash.Umumiy.Umumiy_oyna;
import com.balance.smart_cash.Urllar;
import com.balance.smart_cash.mMySql.ConnectionClass;
import com.balance.smart_cash.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static com.balance.smart_cash.Security.Security_screen.isOnline;
import static com.balance.smart_cash.Security.Security_screen.url_address;

public class Stol_oyna extends Fragment {

    GridView gridView;
    static ArrayList<Stol_list> stol_raqam = new ArrayList<>();
    public static String ofit_ismi = "";
    public static String ofit_id_asos = "";
    static Stol_adapter adapter;
    public static Activity activity;
    private View parentView;
    FragmentTransaction fragment;
    static int ofit_bormi = 0;
    static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.stol_oyna, container, false);
        Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.package_icon);
        Bosh_oyna.btn_asos_saboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Saboy1_oyna());
            }
        });
        Setup();
        return parentView;
    }

    private void Setup() {

        activity = getActivity();
        layout_ofit_mal_yoq = parentView.findViewById(R.id.layout_ofit_mal_yoq);
        ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
        if (ofit_bormi == 1) {
            Bundle bundle = this.getArguments();
            if (bundle != null) {
                ofit_id_asos = bundle.getString("id");
                ofit_ismi = bundle.getString("ismi");
            }
            Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);

            Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
                    if (ofit_bormi == 0) {
                        if (stol_bormi == 0) {
                            changeFragment(new Saboy1_oyna());
                        } else {
                            changeFragment(new Stol_oyna());
                        }
                    } else if (ofit_bormi == 1) {
                        changeFragment(new Ofitsant_oyna());
                    }
                }
            });
            Bosh_oyna.txt_asos_tool.setText(String.format(getString(R.string.stol_oyna_ofitsant), ofit_ismi));
        } else {

            Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
            Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.VISIBLE);
            ofit_ismi = "Ofitsant yo'q";
            ofit_id_asos = "Ofitsant yo'q";
            Bosh_oyna.txt_asos_tool.setText(R.string.stollar_royhati);
            Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.nav_icon);

            Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bosh_oyna.drawer.openDrawer(Gravity.LEFT);
                }
            });
        }
        gridView = (GridView) parentView.findViewById(R.id.grid_view_stol);

        adapter = new Stol_adapter(getContext(), stol_raqam);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Stol_list list = stol_raqam.get(position);
                String nomi = list.getRaqam();
                String shot_id = list.getShot_id();
                String ofit_id = list.getOfit_id();
                String holati = list.getHolati() + "";
                String vaqti = list.getOchil_vaqt();
                String Ismi = list.getIsmi();

                if (!ofit_id.equals("")) {
                    Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                    intent.putExtra("stol", nomi);
                    intent.putExtra("ofit", ofit_id);
                    intent.putExtra("shot", shot_id);
                    intent.putExtra("ismi", Ismi);
                    intent.putExtra("vaqti", vaqti);
                    startActivity(intent);
                } else {
                    if (holati.equals("1")) {
                        new SweetAlertDialog(getContext(), SweetAlertDialog.ERROR_TYPE)
                                .setTitleText("")
                                .setContentText(getString(R.string.boshqa_ofit_qarayapti))
                                .show();
                    } else {
                        Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                        intent.putExtra("stol", nomi);
                        intent.putExtra("ofit", ofit_id_asos);
                        intent.putExtra("shot", "yangi");
                        intent.putExtra("ismi", ofit_ismi);
                        intent.putExtra("vaqti", vaqti);
                        startActivity(intent);
                    }
                }

            }
        });

        Get_stol_Async get_stol_async = new Get_stol_Async(getActivity());
        get_stol_async.execute();
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public static class Get_stol_Async extends AsyncTask<Void, Void, String> {

        Context context;
        ProgressDialog dialog;
        ArrayList<Stol_list> stol_lis = new ArrayList<>();
        ArrayList<String> stol_raqamlari = new ArrayList<>();

        public Get_stol_Async(Context contex) {
            this.context = contex;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            stol_raqam.clear();
            if (Stol_oyna.activity != null) {
                dialog = new ProgressDialog(Stol_oyna.activity);
                dialog.setTitle(context.getString(R.string.iltimos_mal_yuklanmoqda));
                dialog.setIndeterminate(true);
                dialog.show();
            }
            layout_ofit_mal_yoq.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(Void... voids) {
            stol_lis.clear();
            stol_raqamlari.clear();

            String url = "";
            try {
                url = url_address + Urllar.Php_stol_olish + ".php?table1=" + URLEncoder.encode(Login_oyna.TABLE_STOLLAR, "UTF-8") + "&table2=" + URLEncoder.encode(Login_oyna.TABLE_OFITSANT.toLowerCase(), "UTF-8");

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                Login_oyna.XATOLIK_YOZISH(e);
            }

            HttpURLConnection con5 = Connector.connection(url);
            if (con5 != null) {
                InputStream inputStream = null;
                String xatolik = "";
                try {
                    if (con5 != null && isOnline(context)) {
                        inputStream = new BufferedInputStream(con5.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String resulr = reader.readLine();
                        if (resulr != null) {
                            JSONObject json = null;
                            try {
                                json = new JSONObject(resulr);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Login_oyna.XATOLIK_YOZISH(e);
                            }

                            if (json != null) {
                                JSONObject object = null;
                                try {
                                    object = json.getJSONObject("qiymat");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                boolean tugadi = true;
                                int sonlari = 0;

                                try {
                                    sonlari = json.getInt("soni");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Login_oyna.XATOLIK_YOZISH(e);
                                }
                                for (int i = 1; i < sonlari; i++) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = object.getJSONObject("qiy_" + i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Login_oyna.XATOLIK_YOZISH(e);
                                        tugadi = false;
                                    }

                                    if (tugadi) {
                                        String nomi = "";
                                        try {
                                            nomi = jsonObject.getString("nomi");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                            Login_oyna.XATOLIK_YOZISH(e);
                                        }
                                        if (nomi.equals("mal_yoq")) {
                                            tugadi = false;
                                        } else {
                                            String ofit_id = "";
                                            try {
                                                ofit_id = jsonObject.getString("ofit_id");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String shot_raqam = "";
                                            try {
                                                shot_raqam = jsonObject.getString("shot_raqam");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String vaqti = "";
                                            try {
                                                vaqti = jsonObject.getString("vaqti");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            String ismi = "";
                                            try {
                                                ismi = jsonObject.getString("ismi");
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                                Login_oyna.XATOLIK_YOZISH(e);
                                            }
                                            stol_raqamlari.add(nomi);
                                            stol_lis.add(new Stol_list(nomi, 2, ofit_id, shot_raqam, ismi, vaqti));
                                        }
                                    }
                                }

                                Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM " + Login_oyna.TABLE_STOL_SONI);
                                if (cursor.getCount() != 0) {
                                    cursor.moveToFirst();
                                    int soni = cursor.getInt(1);
                                    if (soni > 0) {
                                        for (int i = 1; i <= soni; i++) {
                                            int index = stol_raqamlari.indexOf("" + i);
                                            if (index > -1) {
                                                Stol_list stol_list = stol_lis.get(index);
                                                stol_raqam.add(stol_list);
                                            } else {
                                                stol_raqam.add(new Stol_list("" + i, 0, "", "", "", ""));
                                            }
                                        }
                                    }
                                }
                            }
                            return "ok";
                        }
                    } else {
                        return "off";
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } catch (IOException e) {
                    e.printStackTrace();
                    Login_oyna.XATOLIK_YOZISH(e);
                    xatolik += "\n" + e.getMessage();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Login_oyna.XATOLIK_YOZISH(e);
                            xatolik += "\n" + e.getMessage();
                        }
                    }
                    if (con5 != null) {
                        con5.disconnect();
                    }
                }
            }
            return "off";

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            if (s.equals("ok")) {
                try {
                    adapter.notifyDataSetChanged();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
            } else {
                stol_raqam.clear();
                if (s.equals("off")) {
                    Toast.makeText(context, "Serverga ulanishda xatolik bo'ldi", Toast.LENGTH_SHORT).show();
                } else {
                    layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                }
                try {
                    adapter.notifyDataSetChanged();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                }
            }
            if (stol_raqam.size() == 0){
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            } else {
                layout_ofit_mal_yoq.setVisibility(View.GONE);
            }
        }
    }


}
