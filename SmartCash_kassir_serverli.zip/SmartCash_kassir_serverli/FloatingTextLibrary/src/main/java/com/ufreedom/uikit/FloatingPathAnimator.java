package com.ufreedom.uikit;

/**
 * Author UFreedom
 * 
 */
public interface FloatingPathAnimator {

    public  void applyFloatingPathAnimation(FloatingTextView view,float start,float end);

}
