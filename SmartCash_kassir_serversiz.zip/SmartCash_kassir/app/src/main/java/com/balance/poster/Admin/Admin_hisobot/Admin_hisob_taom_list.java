package com.balance.poster.Admin.Admin_hisobot;

/**
 * Created by Ibrohimjon on 06.09.2018.
 */

public class Admin_hisob_taom_list {
    String Id;
    String Tartib;
    String Nomi;
    String Soni;
    String Narxi;
    String Summa;
    String Printer;

    public Admin_hisob_taom_list(String id, String tartib, String nomi, String soni, String narxi, String summa, String printer) {
        Id = id;
        Tartib = tartib;
        Nomi = nomi;
        Soni = soni;
        Narxi = narxi;
        Summa = summa;
        Printer = printer;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getTartib() {
        return Tartib;
    }

    public void setTartib(String tartib) {
        Tartib = tartib;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }

    public String getSoni() {
        return Soni;
    }

    public void setSoni(String soni) {
        Soni = soni;
    }

    public String getNarxi() {
        return Narxi;
    }

    public void setNarxi(String narxi) {
        Narxi = narxi;
    }

    public String getSumma() {
        return Summa;
    }

    public void setSumma(String summa) {
        Summa = summa;
    }

    public String getPrinter() {
        return Printer;
    }

    public void setPrinter(String printer) {
        Printer = printer;
    }
}
