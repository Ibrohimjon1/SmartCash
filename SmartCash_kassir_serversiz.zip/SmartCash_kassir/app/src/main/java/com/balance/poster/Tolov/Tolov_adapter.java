package com.balance.poster.Tolov;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.poster.R;

import java.util.ArrayList;

/**
 * Created by Ibrohimjon on 20.08.2018.
 */

public class Tolov_adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Tolov_list> tolov_lists;

    public Tolov_adapter(Context context, ArrayList<Tolov_list> tolov_lists) {
        this.context = context;
        this.tolov_lists = tolov_lists;
    }

    @Override
    public int getCount() {
        return tolov_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return tolov_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_tartib, txt_nomi, txt_soni, txt_narxi;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.tolov_item, null);

            holder.txt_tartib = (TextView) row.findViewById(R.id.txt_tolov_item_tartib);
            holder.txt_nomi = (TextView) row.findViewById(R.id.txt_tolov_item_nomi);
            holder.txt_soni = (TextView) row.findViewById(R.id.txt_tolov_item_soni);
            holder.txt_narxi = (TextView) row.findViewById(R.id.txt_tolov_item_narxi);

            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }

        Tolov_list qarzdorlar_list = tolov_lists.get(position);

        holder.txt_tartib.setText(qarzdorlar_list.getTartib());
        holder.txt_nomi.setText(qarzdorlar_list.getTaom());
        holder.txt_soni.setText(qarzdorlar_list.getSoni());
        holder.txt_narxi.setText(qarzdorlar_list.getNarxi());

        return row;
    }
}
