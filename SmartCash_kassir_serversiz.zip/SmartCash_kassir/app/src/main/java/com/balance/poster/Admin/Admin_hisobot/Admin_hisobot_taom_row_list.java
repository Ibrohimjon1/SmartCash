package com.balance.poster.Admin.Admin_hisobot;

/**
 * Created by Ibrohimjon on 07.09.2018.
 */

public class Admin_hisobot_taom_row_list {

    String Tartib;
    String Ofitsant;
    String Soni;

    public Admin_hisobot_taom_row_list(String tartib, String ofitsant, String soni) {
        Tartib = tartib;
        Ofitsant = ofitsant;
        Soni = soni;
    }

    public String getTartib() {
        return Tartib;
    }

    public void setTartib(String tartib) {
        Tartib = tartib;
    }

    public String getOfitsant() {
        return Ofitsant;
    }

    public void setOfitsant(String ofitsant) {
        Ofitsant = ofitsant;
    }

    public String getSoni() {
        return Soni;
    }

    public void setSoni(String soni) {
        Soni = soni;
    }
}
