package com.balance.poster.Saboy1;

/**
 * Created by Hunter on 05.09.2018.
 */

public class Saboy1_list {
    String Id;
    String Num;
    String Sana;

    public Saboy1_list(String id, String num, String sana) {
        Id = id;
        Num = num;
        Sana = sana;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getNum() {
        return Num;
    }

    public void setNum(String num) {
        Num = num;
    }

    public String getSana() {
        return Sana;
    }

    public void setSana(String sana) {
        Sana = sana;
    }
}
