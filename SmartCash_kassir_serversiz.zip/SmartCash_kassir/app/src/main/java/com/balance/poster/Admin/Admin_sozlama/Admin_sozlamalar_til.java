package com.balance.poster.Admin.Admin_sozlama;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.poster.R;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_til extends Fragment {
    View parent_view;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    RadioButton check_lotin, check_kril, check_ruscha, check_english;
    TextView txt_til_sozlama;
    View layout_lotin, layout_kril, layout_rus, layout_english;

    @SuppressLint("CommitPrefEdits")

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_til, container, false);
        init();

        loadLocale();
        return parent_view;
    }

    @SuppressLint("CommitPrefEdits")
    public void init() {
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        layout_lotin = parent_view.findViewById(R.id.layout_til_lotin);
        layout_kril = parent_view.findViewById(R.id.layout_til_kril);
        layout_rus = parent_view.findViewById(R.id.layout_til_rus);
        layout_english = parent_view.findViewById(R.id.layout_til_eng);

        check_lotin = parent_view.findViewById(R.id.check_til_lotin);
        check_kril = parent_view.findViewById(R.id.check_til_kril);
        check_ruscha = parent_view.findViewById(R.id.check_til_ruscha);
        check_english = parent_view.findViewById(R.id.check_til_english);
        txt_til_sozlama = parent_view.findViewById(R.id.txt_til_sozlama);

        check_lotin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    changeLocale("uz");
                    check_kril.setChecked(false);
                    check_english.setChecked(false);
                    check_ruscha.setChecked(false);
                }
            }
        });
        check_kril.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    changeLocale("fr");
                    check_lotin.setChecked(false);
                    check_english.setChecked(false);
                    check_ruscha.setChecked(false);
                }
            }
        });
        check_ruscha.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    changeLocale("ru");
                    check_kril.setChecked(false);
                    check_english.setChecked(false);
                    check_lotin.setChecked(false);
                }
            }
        });
        check_english.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    changeLocale("en");
                    check_kril.setChecked(false);
                    check_lotin.setChecked(false);
                    check_ruscha.setChecked(false);
                }
            }
        });

        layout_lotin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_lotin.setChecked(true);
            }
        });
        layout_kril.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_kril.setChecked(true);
            }
        });
        layout_rus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_ruscha.setChecked(true);
            }
        });
        layout_english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_english.setChecked(true);
            }
        });

    }

    //Save locale method in preferences
    public void saveLocale(String lang) {
        editor.putString("language", lang);
        editor.commit();
    }

    public void loadLocale() {
        String language = sharedPreferences.getString("language", "");
        if (language.equals("en")) {
            check_english.setChecked(true);
        } else if (language.equals("uz")) {
            check_lotin.setChecked(true);
        } else if (language.equals("fr")) {
            check_kril.setChecked(true);
        } else if (language.equals("ru")) {
            check_ruscha.setChecked(true);
        }
        changeLocale(language);
    }

    public void changeLocale(String lang) {
        if (lang.equalsIgnoreCase(""))
            return;
        Locale myLocale = new Locale(lang);
        saveLocale(lang);//Save the selected locale
        Locale.setDefault(myLocale);//set new locale as default
        Configuration config = new Configuration();//get Configuration
        config.locale = myLocale;//set config locale as selected locale
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());//Update the config
        txt_til_sozlama.setText(getString(R.string.dastur_tilini_tanlang));
        Admin_sozlamalar_royhati.Tilini_ozgartir();
    }
}
