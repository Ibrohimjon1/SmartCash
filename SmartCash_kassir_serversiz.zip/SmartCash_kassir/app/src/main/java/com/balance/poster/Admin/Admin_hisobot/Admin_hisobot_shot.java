package com.balance.poster.Admin.Admin_hisobot;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.poster.Asosiy.Bosh_oyna;
import com.balance.poster.Asosiy.Stol_oyna;
import com.balance.poster.Hisobot.Hisob_list_row;
import com.balance.poster.Hisobot.Hisobot_adapter_row;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Ofitsant.Ofitsant_oyna;
import com.balance.poster.R;
import com.balance.poster.Sotilganlar.SampleFragment;
import com.balance.poster.Sotilganlar.Sotilgan_list;
import com.balance.poster.Sotilganlar.Sotlgan_adapter;
import com.hookedonplay.decoviewlib.DecoView;
import com.hookedonplay.decoviewlib.charts.EdgeDetail;
import com.hookedonplay.decoviewlib.charts.SeriesItem;
import com.hookedonplay.decoviewlib.events.DecoEvent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Admin_hisobot_shot extends SampleFragment {

    public static View parent_view;
    ListView listView;
    static TextView txt_otmenaoyna_yoq;
    static ArrayList<Sotilgan_list> sotilgan_lists = new ArrayList<>();
    static Sotlgan_adapter adapter;
    private static int mSeries1Index;
    private static int mSeries2Index;
    private static int mSeries3Index;
    FragmentTransaction fragment;
    public static Context context;
    static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.yopilgan_shotlar, container, false);
        context = getActivity();
        init();
        return parent_view;
    }


    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }


    @Override
    protected void createTracks() {
        setDemoFinished(false);

    }

    public static void INIT(float mSeriesMax) {
        final View view = parent_view;
        final DecoView decoView1 = getDecoView(1, parent_view);
        final DecoView decoView2 = getDecoView(2, parent_view);
        final DecoView decoView3 = getDecoView(3, parent_view);


        if (view == null || decoView1 == null) {

        } else {
//            view.setBackgroundColor(Color.argb(255, 196, 196, 128));

            decoView1.executeReset();
            decoView1.deleteAll();


            SeriesItem seriesBack1Item = new SeriesItem.Builder(COLOR_BACK)
                    .setRange(0, mSeriesMax, mSeriesMax)
                    .setLineWidth(getDimension(20, context))
                    .build();

            decoView1.addSeries(seriesBack1Item);

            SeriesItem series1Item = new SeriesItem.Builder(COLOR_NEUTRAL)
                    .setRange(0, mSeriesMax, 0)
                    .setInitialVisibility(false)
                    .setLineWidth(getDimension(20, context))
                    .setCapRounded(true)
                    .addEdgeDetail(new EdgeDetail(EdgeDetail.EdgeType.EDGE_INNER, COLOR_EDGE, 0.2f))
                    .setShowPointWhenEmpty(true)
                    .build();

            mSeries1Index = decoView1.addSeries(series1Item);

            TextView textListener = (TextView) view.findViewById(R.id.txt_deco_naqd);
            addFitListener1(series1Item, textListener);
        }
        if (view == null || decoView2 == null) {

        } else {


            decoView2.executeReset();
            decoView2.deleteAll();

            SeriesItem seriesBack1Item = new SeriesItem.Builder(COLOR_BACK)
                    .setRange(0, mSeriesMax, mSeriesMax)
                    .setLineWidth(getDimension(20, context))
                    .build();

            decoView2.addSeries(seriesBack1Item);

            SeriesItem series1Item = new SeriesItem.Builder(COLOR_NEUTRAL)
                    .setRange(0, mSeriesMax, 0)
                    .setInitialVisibility(false)
                    .setLineWidth(getDimension(20, context))
                    .setCapRounded(true)
                    .addEdgeDetail(new EdgeDetail(EdgeDetail.EdgeType.EDGE_INNER, COLOR_EDGE, 0.2f))
                    .setShowPointWhenEmpty(true)
                    .build();

            mSeries2Index = decoView2.addSeries(series1Item);

            TextView textListener = (TextView) view.findViewById(R.id.txt_deco_plastik);
            addFitListener2(series1Item, textListener);
        }
        if (view == null || decoView3 == null) {

        } else {

//            view.setBackgroundColor(Color.argb(255, 196, 196, 128));

            decoView3.executeReset();
            decoView3.deleteAll();

            SeriesItem seriesBack1Item = new SeriesItem.Builder(COLOR_BACK)
                    .setRange(0, mSeriesMax, mSeriesMax)
                    .setLineWidth(getDimension(22, context))
                    .build();

            decoView3.addSeries(seriesBack1Item);

            SeriesItem series1Item = new SeriesItem.Builder(COLOR_NEUTRAL)
                    .setRange(0, mSeriesMax, 0)
                    .setInitialVisibility(false)
                    .setLineWidth(getDimension(22, context))
                    .setCapRounded(true)
                    .addEdgeDetail(new EdgeDetail(EdgeDetail.EdgeType.EDGE_INNER, COLOR_EDGE, 0.2f))
                    .setShowPointWhenEmpty(true)
                    .build();

            mSeries3Index = decoView3.addSeries(series1Item);

            TextView textListener = (TextView) view.findViewById(R.id.txt_deco_umum);
            addFitListener3(series1Item, textListener);
        }
    }

    @Override
    protected void setupEvents() {

    }

    public static void ANIM(float naqd, float plast, float umum) {
        final DecoView arcView1 = getDecoView(1, parent_view);
        final DecoView arcView2 = getDecoView(2, parent_view);
        final DecoView arcView3 = getDecoView(3, parent_view);
        final View view = parent_view;

        if (view == null || arcView1 == null || arcView1.isEmpty()) {

        } else {
            final ImageView imgView = (ImageView) view.findViewById(R.id.image_deco_1);
            addAnimation(arcView1, mSeries1Index, naqd, 500, imgView, R.drawable.naqd_icon, "Naqd %.0f so'm", Color.parseColor("#003366"), false);
        }

        if (view == null || arcView2 == null || arcView2.isEmpty()) {

        } else {
            final ImageView imgView = (ImageView) view.findViewById(R.id.image_deco_2);
            addAnimation(arcView2, mSeries2Index, plast, 1000, imgView, R.drawable.card_icon, "Plastik %.0f so'm", Color.parseColor("#6F0564"), false);
        }

        if (view == null || arcView3 == null || arcView3.isEmpty()) {

        } else {
            final ImageView imgView = (ImageView) view.findViewById(R.id.image_deco_3);
            addAnimation(arcView3, mSeries3Index, umum, 1500, imgView, R.drawable.all_money, "Umumiy %.0f so'm", Color.parseColor("#048482"), false);
        }
    }

    private static void addAnimation(final DecoView arcView, int series, float moveTo, int delay,
                                     final ImageView imageView, final int imageId,
                                     final String format, final int color, final boolean restart) {

        DecoEvent.ExecuteEventListener listener = new DecoEvent.ExecuteEventListener() {
            @Override
            public void onEventStart(DecoEvent event) {
                imageView.setImageDrawable(ContextCompat.getDrawable(context, imageId));
                showAvatar(true, imageView);

            }

            @Override
            public void onEventEnd(DecoEvent event) {

            }
        };

        arcView.addEvent(new DecoEvent.Builder(moveTo)
                .setIndex(series)
                .setDelay(delay)
                .setDuration(3000)
                .setListener(listener)
                .setColor(color)
                .build());
    }

    private static void showAvatar(boolean show, View view) {
        AlphaAnimation animation = new AlphaAnimation(show ? 0.0f : 1.0f, show ? 1.0f : 0.0f);
        animation.setDuration(2000);
        animation.setFillAfter(true);
        view.startAnimation(animation);
    }

    private static void addFitListener1(@NonNull final SeriesItem seriesItem, @NonNull final TextView view) {
        seriesItem.addArcSeriesItemListener(new SeriesItem.SeriesItemListener() {

            @Override
            public void onSeriesItemAnimationProgress(float percentComplete, float currentPosition) {

                view.setText(String.format(context.getString(R.string.admin_hisobot_naqd_pul_som), Bosh_oyna.getDecimalFormattedString(String.valueOf((int) currentPosition))));
            }

            @Override
            public void onSeriesItemDisplayProgress(float percentComplete) {

            }
        });
    }

    private static void addFitListener2(@NonNull final SeriesItem seriesItem, @NonNull final TextView view) {
        seriesItem.addArcSeriesItemListener(new SeriesItem.SeriesItemListener() {

            @Override
            public void onSeriesItemAnimationProgress(float percentComplete, float currentPosition) {
                view.setText(String.format(context.getString(R.string.admin_hisobot_plastik_som), Bosh_oyna.getDecimalFormattedString(String.valueOf((int) currentPosition))));
            }

            @Override
            public void onSeriesItemDisplayProgress(float percentComplete) {

            }
        });
    }

    private static void addFitListener3(@NonNull final SeriesItem seriesItem, @NonNull final TextView view) {
        seriesItem.addArcSeriesItemListener(new SeriesItem.SeriesItemListener() {

            @Override
            public void onSeriesItemAnimationProgress(float percentComplete, float currentPosition) {

                view.setText(String.format(context.getString(R.string.admin_hisobot_umum_som), Bosh_oyna.getDecimalFormattedString(String.valueOf((int) currentPosition))));
            }

            @Override
            public void onSeriesItemDisplayProgress(float percentComplete) {

            }
        });
    }


    public void init() {
        TextView txt_hisob_shot_nomi = parent_view.findViewById(R.id.txt_hisob_shot_nomi);
        txt_hisob_shot_nomi.setVisibility(View.VISIBLE);
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        txt_otmenaoyna_yoq = (TextView) parent_view.findViewById(R.id.txt_otmenaoyna_yoq);
        listView = (ListView) parent_view.findViewById(R.id.lView_yopiqShot);

        adapter = new Sotlgan_adapter(getContext(), sotilgan_lists);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Sotilgan_list list = sotilgan_lists.get(position);
                String taom_sum = list.getTaom_sum();
                String xizm_sum = list.getXizm_sum();
                String tolov_sum = list.getTolov_sum();
                String shot_raqam = list.getShot();
                String och_vaqt = list.getOchil_sana();
                String yop_vaqt = list.getYop_sana();
                if (!shot_raqam.equals("")) {
                    ArrayList<Admin_hisob_shot_list> list_rows = new ArrayList<>();
                    String sql = "SELECT vaqti,nomi,soni,narxi FROM ZAKAZLAR WHERE vaqti >= '" + och_vaqt + "' AND vaqti <= '" + yop_vaqt + "' AND shot_raqam = '" + shot_raqam + "'";
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
                    list_rows.clear();
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();

                        int tart = 0;
                        do {
                            tart++;
                            String vaqti = cursor.getString(0);
                            String nomi = cursor.getString(1);
                            String soni = cursor.getString(2);
                            String narxi = cursor.getString(3);

                            list_rows.add(new Admin_hisob_shot_list("" + tart, vaqti, nomi, soni, narxi));
                        } while (cursor.moveToNext());
                        Shot_dialog(list_rows, shot_raqam, taom_sum, xizm_sum, tolov_sum);
                    }
                }
            }
        });

        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        String strDate = format.format(calendar1.getTime());

        String sql = "SELECT tolov.naqd, tolov.plastik, tolov.taom_sum, tolov.xizmat_sum, tolov.tolov_sum, shot.* FROM SHOTLAR AS shot INNER JOIN TOLOVLAR AS tolov ON shot.shot_raqam = tolov.shot_raqam WHERE shot.yopilgan_sana LIKE '" + strDate + "%' AND shot.yopilgan_sana = tolov.vaqti";
        Yangilash yangilash = new Yangilash(sql,getContext());
        yangilash.execute();


    }

    private void Shot_dialog(ArrayList<Admin_hisob_shot_list> list_rows, String shot, String taom, String xizm, String tolov_sum) {

        final Dialog dialog = new Dialog(getContext(), R.style.hisob_ozgart_oyna_di);
        dialog.setContentView(R.layout.hisob_shot_item);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.CENTER;
        wlp.flags &= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        window.setAttributes(wlp);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setTitle("");

        ListView list_hisob_item = dialog.findViewById(R.id.list_hisob_item);
        TextView txt_hisob_item_row_nomi = dialog.findViewById(R.id.txt_hisob_item_row_nomi);
        TextView txt_hisob_item_row_umum_taom = dialog.findViewById(R.id.txt_hisob_item_row_umum_taom);
        TextView txt_hisob_item_row_umum_xizm = dialog.findViewById(R.id.txt_hisob_item_row_umum_xizm);
        TextView txt_hisob_item_row_umum_tolov = dialog.findViewById(R.id.txt_hisob_item_row_umum_tolov);
        Admin_hisobot_adapter_row adapter = new Admin_hisobot_adapter_row(getContext(), list_rows);
        list_hisob_item.setAdapter(adapter);

        txt_hisob_item_row_umum_taom.setText(Bosh_oyna.getDecimalFormattedString(taom));
        txt_hisob_item_row_umum_xizm.setText(Bosh_oyna.getDecimalFormattedString(xizm));
        txt_hisob_item_row_umum_tolov.setText(Bosh_oyna.getDecimalFormattedString(tolov_sum));

        txt_hisob_item_row_nomi.setText(String.format(getString(R.string.admin_hisob_raqamli_shot), shot));
        ImageView btn_iks = dialog.findViewById(R.id.btn_hisob_item_iks);
        btn_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();

    }

    public static class Yangilash extends AsyncTask<Void, Void, String> {

        String sql;
        int umum_naqd = 0, umum_plast = 0, umum_sum = 0;
        ProgressDialog dialog;
        Context context;

        public Yangilash(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

//            txt_otmenaoyna_yoq.setVisibility(View.VISIBLE);
//            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
//            txt_otmenaoyna_yoq.setText(R.string.iltimos_mal_yuklanmoqda);
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {
            sotilgan_lists.clear();
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                int tartib = 0;
                umum_naqd = 0;
                umum_plast = 0;
                umum_sum = 0;
                do {
                    tartib++;
                    String naqd = cursor.getString(0);
                    String plast = cursor.getString(1);
                    if (!naqd.equals("")) {
                        int naq = 0;
                        try {
                            naq = Integer.parseInt(naqd);
                            umum_naqd += naq;
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                    if (!plast.equals("")) {
                        int pla = 0;
                        try {
                            pla = Integer.parseInt(plast);
                            umum_plast += pla;
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                    String taom_sum = cursor.getString(2);
                    String xizm_suma = cursor.getString(3);
                    String tolov_sum = cursor.getString(4);
                    String shot_raqam = cursor.getString(6);
                    String och_sana = cursor.getString(7);
                    String yop_sana = cursor.getString(8);
                    String ofit_id = cursor.getString(9);
                    String stol = cursor.getString(10);
                    String summa = cursor.getString(11);
                    if (!summa.equals("")) {
                        int sum = 0;
                        try {
                            sum = Integer.parseInt(summa);
                            umum_sum += sum;
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                    sotilgan_lists.add(new Sotilgan_list("" + tartib, och_sana, yop_sana, stol, shot_raqam, Bosh_oyna.getDecimalFormattedString(summa), ofit_id, taom_sum, xizm_suma, tolov_sum));
                } while (cursor.moveToNext());
                return "ok";
            } else {
                umum_naqd = 0;
                umum_plast = 0;
                umum_sum = 0;
                return "yoq";
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            adapter.notifyDataSetChanged();
            if (s.equals("ok")) {
                txt_otmenaoyna_yoq.setVisibility(View.GONE);
                layout_ofit_mal_yoq.setVisibility(View.GONE);
            } else {
                txt_otmenaoyna_yoq.setVisibility(View.VISIBLE);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_otmenaoyna_yoq.setText(R.string.ushbu_sanada_yopilgan_yoq);
            }
            INIT(umum_sum + (umum_sum * 2 / 100));
            ANIM(umum_naqd, umum_plast, umum_sum);
        }
    }

}
