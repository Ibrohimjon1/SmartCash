package com.balance.poster.Security;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.poster.Asosiy.Bosh_oyna;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Urllar;
import com.tokopedia.showcase.ShowCaseBuilder;
import com.tokopedia.showcase.ShowCaseContentPosition;
import com.tokopedia.showcase.ShowCaseDialog;
import com.tokopedia.showcase.ShowCaseObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import static com.balance.poster.Login.Login_oyna.TaskniTekshirish;

public class Security_screen extends AppCompatActivity {

    Button btn_login;
    EditText edt_kalit;
    TextView edt_gen_key;
    public static ImageView imageView_logo, btn_security_send;
    public static String url_address = "http://192.168.1.113/smart_cash/";
    public static final String SHOWCASE_TAG = "sample_showcase_tag";
    private ShowCaseDialog showCaseDialog;
    SharedPreferences getPreferences;
    public static AnimationDrawable frameAnimation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.security_screen);

        getPreferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);

        String klent_id = getPreferences.getString("klent_id", "");
        if (!klent_id.equals("")) {
            finish();
            Intent intent = new Intent(Security_screen.this, Login_oyna.class);
            startActivity(intent);
        }

        btn_login = (Button) findViewById(R.id.btn_security_login);
        edt_kalit = (EditText) findViewById(R.id.edt_kalit);
        edt_gen_key = (TextView) findViewById(R.id.edt_gen_key);
        btn_security_send = (ImageView) findViewById(R.id.btn_security_send);
        imageView_logo = (ImageView) findViewById(R.id.image_sec_logo);
        imageView_logo.setBackgroundResource(R.drawable.logo_anim);
        frameAnimation = (AnimationDrawable) imageView_logo.getBackground();
        frameAnimation.start();

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "";
                String gen_key = edt_gen_key.getText().toString();
//                Intent intent = new Intent(Security_screen.this, Login_oyna.class);
//                startActivity(intent);
//                preferences = getSharedPreferences("Holati", Activity.MODE_PRIVATE);
//                editor1 = preferences.edit();
//                Mal_saqlash("klent_id", "1");
//                Mal_saqlash("holati", "1");
//                Mal_saqlash("muddatlimi", "0");
//                Mal_saqlash("muddat_vaqti", "0");
//                Security_screen.frameAnimation.stop();
//                finish();
                try {
                    url = url_address + Urllar.Tekshiruvchi + ".php?gen=" + URLEncoder.encode(gen_key, "UTF-8") + "&kalit=" + URLEncoder.encode(edt_kalit.getText().toString(), "UTF-8")
                            + "&imei=" + URLEncoder.encode(String.valueOf(qiymat), "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                }
                TaskniTekshir_tek(url);

            }
        });

        btn_login.setEnabled(false);

        loadLocale(Security_screen.this);
        btn_security_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "";
                String gen_key = edt_gen_key.getText().toString();

                try {
                    url = url_address + Urllar.Check_user + ".php?gen=" + URLEncoder.encode(gen_key, "UTF-8") + "&imei=" + URLEncoder.encode(String.valueOf(qiymat), "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                }

                TaskniTekshir(url);
            }
        });
        TaskniTekshirish(Security_screen.this);
        edt_kalit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edt_kalit.getText().toString().equals("")) {
                    btn_login.setEnabled(false);
                } else {
                    btn_login.setEnabled(true);
                }
            }
        });

        edt_gen_key.setText(getUniqueIMEIId());
    }

    public void Mal_saqlash(String kalit, String qiymat) {
        editor1.putString(kalit, qiymat);
        editor1.commit();
    }

    static SharedPreferences sharedPreferences;
    static SharedPreferences preferences;
    static SharedPreferences.Editor editor1;
    static SharedPreferences.Editor editor;

    public static void loadLocale(Context context) {
        sharedPreferences = context.getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);

        editor = sharedPreferences.edit();
        String language = sharedPreferences.getString("language", "uz");
        changeLocale(language, context);
    }

    public static void saveLocale(String lang) {
        editor.putString("language", lang);
        editor.commit();
    }

    public static void changeLocale(String lang, Context context) {
        if (lang.equalsIgnoreCase(""))
            return;
        Locale myLocale = new Locale(lang);
        saveLocale(lang);//Save the selected locale
        Locale.setDefault(myLocale);//set new locale as default
        Configuration config = new Configuration();//get Configuration
        config.locale = myLocale;//set config locale as selected locale
        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());//Update the config

    }


    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void TaskniTekshir(String url) {
        Jonatuvchi jonatuvchi = new Jonatuvchi(Security_screen.this, url);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            jonatuvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            jonatuvchi.execute();
        }

    }

    @SuppressLint("ObsoleteSdkInt")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void TaskniTekshir_tek(String url) {
        Tekshiruvchi jonatuvchi = new Tekshiruvchi(Security_screen.this, url);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            jonatuvchi.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            jonatuvchi.execute();
        }

    }

    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert cm != null;
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        btn_security_send.setEnabled(true);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(Security_screen.this, "Permission denied to read your phone state!", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    long qiymat = 0;

    public String getUniqueIMEIId() {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (ActivityCompat.checkSelfPermission(Security_screen.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Security_screen.this,
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        1);
                return "";
            }
            String imei = telephonyManager.getDeviceId();

            if (imei != null && !imei.isEmpty()) {

                String IME = imei.replaceAll("[^0-9]", "");
                if (!IME.equals("")) {
                    try {
                        qiymat = Long.parseLong(IME);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                    if (qiymat == 0) {
                        qiymat = 1;
                    }
                    Calendar calendar = Calendar.getInstance();
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat("mmHHss");
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat format2 = new SimpleDateFormat("s");
                    String strDate = format.format(calendar.getTime());
                    String sekund = format2.format(calendar.getTime());
                    if (sekund.equals("") || sekund.equals("0")) {
                        sekund = "1";
                    }
                    long soat = 0;
                    String soatt;
                    if (strDate.equals("")) {
                        strDate = "1";
                    }
                    soatt = "5162" + strDate;
                    try {
                        soat = Long.parseLong(soatt);
                    } catch (NumberFormatException r) {
                        r.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format3 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate3 = format3.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate3, r.getMessage(), sql);
                    }
                    long key = 0;
                    try {
                        int sek = Integer.parseInt(sekund);
                        key = (qiymat * sek) + soat;
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format4 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate4 = format4.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate4, e.getMessage(), sql);
                    }

                    return String.format("%d*%s", key, strDate);
                }

            } else {
                return android.os.Build.SERIAL;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
        }
        return "not_found";
    }
}
