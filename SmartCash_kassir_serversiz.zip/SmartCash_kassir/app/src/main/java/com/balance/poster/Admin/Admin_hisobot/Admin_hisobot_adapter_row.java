package com.balance.poster.Admin.Admin_hisobot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.poster.Hisobot.Hisob_list_row;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Admin_hisobot_adapter_row extends BaseAdapter {
    Context context;
    private ArrayList<Admin_hisob_shot_list> sotilganLists;

    public Admin_hisobot_adapter_row(Context context, ArrayList<Admin_hisob_shot_list> sotilganLists) {
        this.context = context;
        this.sotilganLists = sotilganLists;
    }

    @Override
    public int getCount() {
        return sotilganLists.size();
    }

    @Override
    public Object getItem(int position) {
        return sotilganLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_num, txt_sana, txt_taom, txt_soni, txt_narxi;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;

        ViewHolder holder = new ViewHolder();
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.hisob_shot_item_row, null);
            holder.txt_num = (TextView) row.findViewById(R.id.txt_hisob_item_row_tartib);
            holder.txt_sana = (TextView) row.findViewById(R.id.txt_hisob_item_row_sana);
            holder.txt_taom = (TextView) row.findViewById(R.id.txt_hisob_item_row_taom);
            holder.txt_soni = (TextView) row.findViewById(R.id.txt_hisob_item_row_soni);
            holder.txt_narxi = (TextView) row.findViewById(R.id.txt_hisob_item_row_narxi);

            row.setTag(holder);

        } else {
            holder = (ViewHolder) row.getTag();
        }
        try {

            Admin_hisob_shot_list sotilgan_list = sotilganLists.get(position);

            holder.txt_num.setText(sotilgan_list.getTartib());
            holder.txt_sana.setText(sotilgan_list.getSana());
            holder.txt_taom.setText(sotilgan_list.getTaom());
            holder.txt_soni.setText(sotilgan_list.getSoni());
            holder.txt_narxi.setText(sotilgan_list.getNarxi());

        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
        }


        return row;
    }
}
