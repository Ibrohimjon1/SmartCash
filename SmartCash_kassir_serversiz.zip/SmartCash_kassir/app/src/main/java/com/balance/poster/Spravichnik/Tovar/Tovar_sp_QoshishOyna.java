package com.balance.poster.Spravichnik.Tovar;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Spravichnik.Menu.Menu_sp_royhat;
import com.balance.poster.Spravichnik.Otdel.Otdel_sp_royhat;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Tovar_sp_QoshishOyna extends AppCompatActivity {
    Button btn_tovar_sp_saqlash, btn_tovar_sp_ortga;
    EditText edit_Taom_sp_TamoNomi, edit_Taom_sp_TamoNarxi;
    Spinner spiner_Taom_sp_TamoMenu;
    private static int RESULT_LOAD_IMAGE = 1;
    ImageView image_Taom_sp_TaomRasm;
    CheckBox checkbox_Taom_sp_TamoFoiz;


    ArrayList<String> menu_Nomi = new ArrayList<String>();
    ArrayList<String> menu_ID = new ArrayList<String>();
    ArrayList<String> printer = new ArrayList<String>();
    ArrayList<String> otdel_ID = new ArrayList<String>();
    String sessionId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tovar_sp_oyna);
        init();
        loadSpinnerData();
        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        btn_tovar_sp_saqlash = (Button) findViewById(R.id.btn_tovar_sp_saqlash);
        btn_tovar_sp_ortga = (Button) findViewById(R.id.btn_tovar_sp_ortga);
        image_Taom_sp_TaomRasm = (ImageView) findViewById(R.id.image_Taom_sp_TaomRasm);
        edit_Taom_sp_TamoNomi = (EditText) findViewById(R.id.edit_Taom_sp_TamoNomi);
        edit_Taom_sp_TamoNarxi = (EditText) findViewById(R.id.edit_Taom_sp_TamoNarxi);
        checkbox_Taom_sp_TamoFoiz = (CheckBox) findViewById(R.id.checkbox_Taom_sp_TamoFoiz);
        spiner_Taom_sp_TamoMenu = (Spinner) findViewById(R.id.spiner_Taom_sp_TamoMenu);

        image_Taom_sp_TaomRasm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        btn_tovar_sp_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_tovar_sp_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = spiner_Taom_sp_TamoMenu.getSelectedItemPosition();
                String print = printer.get(index);
                if (!edit_Taom_sp_TamoNomi.getText().toString().equals("") && !edit_Taom_sp_TamoNarxi.getText().toString().equals("")) {

                    if (!sessionId.equals("")) {

                        String sql = "UPDATE TAOMLAR SET  nomi = ?, narxi=?, otdel_id=?, menu_id=?, rasmi=?, foizi=?, printer = ? WHERE Id='" + sessionId + "'";
                        String TaomNomi = edit_Taom_sp_TamoNomi.getText().toString();
                        String TaomNarxi = edit_Taom_sp_TamoNarxi.getText().toString();

                        String checkFoiz = "0";
                        if (checkbox_Taom_sp_TamoFoiz.isChecked()) {
                            checkFoiz = "1";
                        } else {
                            checkFoiz = "0";
                        }
                        String menuId = menu_ID.get(index);
                        String otdelId = otdel_ID.get(index);

                        Login_oyna.SQLITE_HELPER.Taom_qoshish(TaomNomi, TaomNarxi, otdelId, menuId, image_Taom_sp_TaomRasm, checkFoiz, print, sql);
                        edit_Taom_sp_TamoNomi.setText("");
                        edit_Taom_sp_TamoNarxi.setText("");
                        checkbox_Taom_sp_TamoFoiz.setSelected(false);
                        Tovar_sp_royhat.GetData_Taom();
                        finish();

                    } else {
                        String sql = "INSERT INTO TAOMLAR VALUES (NULL, ?, ?, ?, ?, ?, ?, 0, ?, 0)";

                        String TaomNomi = edit_Taom_sp_TamoNomi.getText().toString();
                        String TaomNarxi = edit_Taom_sp_TamoNarxi.getText().toString();

                        String checkFoiz = "0";
                        if (checkbox_Taom_sp_TamoFoiz.isChecked()) {
                            checkFoiz = "1";
                        } else {
                            checkFoiz = "0";
                        }
                        String menuId = menu_ID.get(index);
                        String otdelId = otdel_ID.get(index);

                        Login_oyna.SQLITE_HELPER.Taom_qoshish(TaomNomi, TaomNarxi, otdelId, menuId, image_Taom_sp_TaomRasm, checkFoiz, print, sql);

                        edit_Taom_sp_TamoNomi.setText("");
                        edit_Taom_sp_TamoNarxi.setText("");
                        checkbox_Taom_sp_TamoFoiz.setSelected(false);
                        Tovar_sp_royhat.GetData_Taom();
                        finish();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    private void loadSpinnerData() {
        // database handler
        Cursor cursor_1 = Login_oyna.SQLITE_HELPER.getData("SELECT otdel.printer, menu.* FROM OTDEL AS otdel INNER JOIN MENU AS menu ON menu.otdel_id = otdel.Id");
        if (cursor_1.getCount() != 0) {
            try {
                menu_ID.clear();
                menu_Nomi.clear();
                otdel_ID.clear();
                printer.clear();
                cursor_1.moveToFirst();
                do {
                    printer.add(cursor_1.getString(0));
                    menu_ID.add(cursor_1.getString(1));
                    menu_Nomi.add(cursor_1.getString(2));
                    otdel_ID.add(cursor_1.getString(3));
                } while (cursor_1.moveToNext());

            } catch (SQLException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }
        }

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.spinner_item, menu_Nomi);
        // attaching data adapter to spinner
        spiner_Taom_sp_TamoMenu.setAdapter(dataAdapter);
    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM TAOMLAR WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edit_Taom_sp_TamoNomi.setText(cursor_2.getString(1));
            edit_Taom_sp_TamoNarxi.setText(cursor_2.getString(2));
            String otdelID = cursor_2.getString(3);
            String menuID = cursor_2.getString(4);
            byte[] rasm = cursor_2.getBlob(5);
            String foiz = cursor_2.getString(6);
            if (foiz.equals("1")) {
                checkbox_Taom_sp_TamoFoiz.setChecked(true);
            }
            if (foiz.equals("0")) {
                checkbox_Taom_sp_TamoFoiz.setChecked(false);
            }
            int indexO = menu_ID.indexOf(menuID);

            Bitmap bitmap = BitmapFactory.decodeByteArray(rasm, 0, rasm.length);
            image_Taom_sp_TaomRasm.setImageBitmap(bitmap);

            spiner_Taom_sp_TamoMenu.setSelection(indexO);

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(selectedImage);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                image_Taom_sp_TaomRasm.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Calendar calendar1 = Calendar.getInstance();
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                String strDate = format.format(calendar1.getTime());
                String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}

