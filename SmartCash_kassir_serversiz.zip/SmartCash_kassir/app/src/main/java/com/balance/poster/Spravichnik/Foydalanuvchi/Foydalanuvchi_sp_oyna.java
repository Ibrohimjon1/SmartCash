package com.balance.poster.Spravichnik.Foydalanuvchi;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Spravichnik.Printer.Printer_sp_royhat;

import java.util.ArrayList;

public class Foydalanuvchi_sp_oyna extends AppCompatActivity {
    Button btn_foydalnuvchi_oyna_saqlash, btn_foydalnuvchi_ortga;
    EditText edt_foydalnuvchi_Oyna_Ism, edt_foydalnuvchi_Oyna_parol;
    Spinner spinner_f;
    ArrayList<String> spiner_dostup = new ArrayList<String>();
    String sessionId;
    TextView txt_qoshi_oyna;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foydalanuvchi_sp_oyna);
        init();
        spiner_dostup.clear();
        spiner_dostup.add("Admin");
        spiner_dostup.add("Kassir");

        SetDataOnSpinner();
        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }

    }

    public void init() {
        edt_foydalnuvchi_Oyna_Ism = (EditText) findViewById(R.id.edt_foydalnuvchi_Oyna_Ism);
        edt_foydalnuvchi_Oyna_parol = (EditText) findViewById(R.id.edt_foydalnuvchi_Oyna_parol);
        btn_foydalnuvchi_oyna_saqlash = (Button) findViewById(R.id.btn_foydalnuvchi_oyna_saqlash);
        btn_foydalnuvchi_ortga = (Button) findViewById(R.id.btn_foydalnuvchi_ortga);
        spinner_f = (Spinner) findViewById(R.id.spinner_foydalnuvchi_Oyna_dostup);

        btn_foydalnuvchi_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_foydalnuvchi_oyna_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edt_foydalnuvchi_Oyna_Ism.getText().toString().equals("") && !edt_foydalnuvchi_Oyna_parol.getText().toString().equals("")) {

                    if (!sessionId.equals("")) {

                        String Fio = edt_foydalnuvchi_Oyna_Ism.getText().toString().trim();
                        String parol = edt_foydalnuvchi_Oyna_parol.getText().toString().trim();
                        int index = spinner_f.getSelectedItemPosition();
                        String dostuprId = String.valueOf(index);
                        Login_oyna.SQLITE_HELPER.queryData("UPDATE FOYDALANUVCHI SET  ismi = '" + Fio + "'," +
                                "dostup='" + dostuprId + "', parol='" + parol + "' WHERE Id='" + sessionId + "'");
                        edt_foydalnuvchi_Oyna_parol.setText("");
                        edt_foydalnuvchi_Oyna_Ism.setText("");
                        Foydalanuvchi_sp_royhat.GetData_Foydalanuvchi();
                        finish();
                    } else {
                        String Fio = edt_foydalnuvchi_Oyna_Ism.getText().toString().trim();
                        String parol = edt_foydalnuvchi_Oyna_parol.getText().toString().trim();
                        int index = spinner_f.getSelectedItemPosition();
                        String dostuprId = String.valueOf(index);
                        String sql = "INSERT INTO FOYDALANUVCHI VALUES (NULL, ?, ?, ?, 0)";
                        Login_oyna.SQLITE_HELPER.Foydalanuvchi_qoshish(Fio, dostuprId, parol, sql);
                        edt_foydalnuvchi_Oyna_parol.setText("");
                        edt_foydalnuvchi_Oyna_Ism.setText("");
                        Foydalanuvchi_sp_royhat.GetData_Foydalanuvchi();
                        finish();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), R.string.malum_toliq_kiriting, Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

    public void SetDataOnSpinner() {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.spinner_item, spiner_dostup);
        // attaching data adapter to spinner
        spinner_f.setAdapter(dataAdapter);
    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM FOYDALANUVCHI WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edt_foydalnuvchi_Oyna_Ism.setText(cursor_2.getString(1));
            edt_foydalnuvchi_Oyna_parol.setText(cursor_2.getString(3));
            String dostp = cursor_2.getString(2);
            int dostup1 = Integer.parseInt(dostp);
            spinner_f.setSelection(dostup1);

        }
    }
}
