package com.balance.poster.Admin.Admin_sozlama;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.balance.poster.R;
import com.balance.poster.Spravichnik.url.Url_sp_royhat;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_royhati extends FragmentActivity {
    FragmentTransaction fragment;
    public static LinearLayout admin_sozlama_til, admin_sozlama_Assosiy, admin_sozlama_Tolov, admin_sozlama_Pechat, admin_sozlama_Kasir, admin_sozlama_Yuklamlar,
            admin_sozlama_BazaniTozalash;
    LinearLayout eski_bosilgan;
    ImageView btn_admin_hisob_ortga;
    public static TextView txt_asos_toolbar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_sozlam_royhat);
        admin_sozlama_til = (LinearLayout) findViewById(R.id.admin_sozlama_til);
        admin_sozlama_Assosiy = (LinearLayout) findViewById(R.id.admin_sozlama_Assosiy);
        admin_sozlama_Tolov = (LinearLayout) findViewById(R.id.admin_sozlama_Tolov);
        admin_sozlama_Pechat = (LinearLayout) findViewById(R.id.admin_sozlama_Pechat);
        txt_asos_toolbar = findViewById(R.id.txt_asos_toolbar);
        admin_sozlama_Kasir = (LinearLayout) findViewById(R.id.admin_sozlama_Kasir);
        admin_sozlama_Yuklamlar = (LinearLayout) findViewById(R.id.admin_sozlama_Yuklamlar);
        admin_sozlama_BazaniTozalash = (LinearLayout) findViewById(R.id.admin_sozlama_BazaniTozalash);
        btn_admin_hisob_ortga = (ImageView) findViewById(R.id.btn_admin_hisob_ortga);

        btn_admin_hisob_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        admin_sozlama_Assosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_Assosiy.setSelected(true);
                eski_bosilgan = admin_sozlama_Assosiy;
                changeFragment(new Admin_sozlamalar_Assosiy());
            }
        });

        admin_sozlama_til.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_til.setSelected(true);
                eski_bosilgan = admin_sozlama_til;
                changeFragment(new Admin_sozlamalar_til());
            }
        });

        admin_sozlama_Tolov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_Tolov.setSelected(true);
                eski_bosilgan = admin_sozlama_Tolov;
                changeFragment(new Admin_sozlamalar_Tolov());
            }
        });
        admin_sozlama_Pechat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_Pechat.setSelected(true);
                eski_bosilgan = admin_sozlama_Pechat;
                changeFragment(new Admin_sozlamalar_Pechat());
            }
        });
        admin_sozlama_Kasir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_Kasir.setSelected(true);
                eski_bosilgan = admin_sozlama_Kasir;
                changeFragment(new Admin_sozlamalar_KassirHuquqi());
            }
        });
        admin_sozlama_Yuklamlar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_Yuklamlar.setSelected(true);
                eski_bosilgan = admin_sozlama_Yuklamlar;
                changeFragment(new Admin_sozlamalar_Yuklamalar());
            }
        });
        admin_sozlama_BazaniTozalash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sozlama_BazaniTozalash.setSelected(true);
                eski_bosilgan = admin_sozlama_BazaniTozalash;
                changeFragment(new Admin_sozlamalar_BazaniTozalash());
            }
        });

        Tilini_ozgartir();
    }

    public static void Tilini_ozgartir() {
        TextView txt_til = admin_sozlama_til.findViewById(R.id.txt_sozlam_til);
        TextView txt_asos = admin_sozlama_Assosiy.findViewById(R.id.txt_sozlama_asos);
        TextView txt_kass = admin_sozlama_Kasir.findViewById(R.id.txt_sozlama_kassir);
        TextView txt_pech = admin_sozlama_Pechat.findViewById(R.id.txt_sozlama_pechat);
        TextView txt_tolov = admin_sozlama_Tolov.findViewById(R.id.txt_sozlama_tolov);
        TextView txt_yuk = admin_sozlama_Yuklamlar.findViewById(R.id.txt_sozlama_yuklama);

        txt_til.setText(R.string.dastur_tili);
        txt_asos.setText(R.string.asosiy);
        txt_kass.setText(R.string.kassir_huquqlari);
        txt_pech.setText(R.string.pechat);
        txt_tolov.setText(R.string.to_lov);
        txt_yuk.setText(R.string.yuklamalar);
        txt_asos_toolbar.setText(R.string.sozlama_oyna);
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.admin_sozlamalar_royhat_Fregmant, targetFragment)
                .commit();
    }
}
