package com.balance.poster.Otdel;

/**
 * Created by Ibrohimjon on 19.08.2018.
 */

public class Otdel_list {

    String Id;
    private byte[] Image;
    String Nomi;

    public Otdel_list(String id, byte[] image, String nomi) {
        Id = id;
        Image = image;
        Nomi = nomi;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public byte[] getImage() {
        return Image;
    }

    public void setImage(byte[] image) {
        Image = image;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }
}
