package com.balance.poster.Menu;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Otdel.Otdel_oyna;
import com.balance.poster.R;
import com.balance.poster.Taomlar.Taomlar_oyna;
import com.balance.poster.Umumiy.Umumiy_oyna;

import java.util.ArrayList;

public class Menu_oyna extends Fragment {

    GridView gridView;
    ArrayList<Menu_list> otdel_list = new ArrayList<>();
    private View parentView;
    String otdel_id = "";
    Button btn_otdel, btn_menu, btn_taom;
    Menu_adapter adapter;
    FragmentTransaction fragment;
    View txt_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.menu_oyna, container, false);
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            otdel_id = bundle.getString("otdel");
        }
        Setup();
        String sql = "";
        if (Umumiy_oyna.OTDEL_BORMI == 0) {
            sql = "SELECT * FROM MENU";
        } else {
            sql = "SELECT * FROM MENU WHERE otdel_id='" + otdel_id + "'";
        }
        Get_menu(sql);
        return parentView;
    }

    private void Setup() {

        btn_taom = (Button) getActivity().findViewById(R.id.btn_umum_taom);
        btn_menu = (Button) getActivity().findViewById(R.id.btn_umum_menu);
        btn_otdel = (Button) getActivity().findViewById(R.id.btn_umum_otdel);
        txt_mal_yoq = parentView.findViewById(R.id.txt_menu_oyna_mal_yoq);

        if (Umumiy_oyna.OTDEL_BORMI == 0) {
            btn_otdel.setVisibility(View.GONE);
            Umumiy_oyna.view_umum_oq.setVisibility(View.VISIBLE);

        } else {
            btn_otdel.setVisibility(View.VISIBLE);
            Umumiy_oyna.view_umum_oq.setVisibility(View.GONE);
        }
        btn_menu.setVisibility(View.VISIBLE);
        btn_taom.setVisibility(View.GONE);
        btn_otdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Otdel_oyna(), "");
            }
        });

        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment_2(new Menu_oyna(), otdel_id);
            }
        });

        gridView = (GridView) parentView.findViewById(R.id.grid_view_otdel);
        otdel_list.clear();
        adapter = new Menu_adapter(getContext(), otdel_list);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView txt_id = view.findViewById(R.id.txt_otdel_item_id);
                changeFragment(new Taomlar_oyna(), txt_id.getText().toString());
            }
        });


    }

    public void Get_menu(String sql) {
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            otdel_list.clear();
            do {
                String id = cursor.getString(0);
                String nomi = cursor.getString(1);

                byte[] image = cursor.getBlob(3);

                otdel_list.add(new Menu_list(id, nomi, image));
            } while (cursor.moveToNext());
            adapter.notifyDataSetChanged();
            txt_mal_yoq.setVisibility(View.GONE);
        } else {
            otdel_list.clear();
            txt_mal_yoq.setVisibility(View.VISIBLE);
            adapter.notifyDataSetChanged();
        }
    }

    public void changeFragment(Fragment targetFragment, String menu) {
        if (!menu.equals("")) {
            Bundle bundle = new Bundle();
            if (Umumiy_oyna.OTDEL_BORMI != 0) {
                bundle.putString("otdel", otdel_id);
            } else {
                bundle.putString("otdel", "");
            }
            bundle.putString("menu", menu);
            targetFragment.setArguments(bundle);
        }
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public void changeFragment_2(Fragment targetFragment, String id) {
        Bundle bundle = new Bundle();
        bundle.putString("otdel", id);
        targetFragment.setArguments(bundle);
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();
    }
}
