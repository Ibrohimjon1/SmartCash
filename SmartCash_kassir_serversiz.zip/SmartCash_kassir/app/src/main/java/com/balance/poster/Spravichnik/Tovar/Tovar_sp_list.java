package com.balance.poster.Spravichnik.Tovar;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Tovar_sp_list {
    String id;
    String num;
    String nomi;
    String narx;
    String foiz;
    String menu;
    byte [] rasm;

    public Tovar_sp_list(String id, String num, String nomi, String narx, String foiz, String menu, byte[] rasm) {
        this.id = id;
        this.num = num;
        this.nomi = nomi;
        this.narx = narx;
        this.foiz = foiz;
        this.menu = menu;
        this.rasm = rasm;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNomi() {
        return nomi;
    }

    public void setNomi(String nomi) {
        this.nomi = nomi;
    }

    public String getNarx() {
        return narx;
    }

    public void setNarx(String narx) {
        this.narx = narx;
    }

    public String getFoiz() {
        return foiz;
    }

    public void setFoiz(String foiz) {
        this.foiz = foiz;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public byte[] getRasm() {
        return rasm;
    }

    public void setRasm(byte[] rasm) {
        this.rasm = rasm;
    }
}
