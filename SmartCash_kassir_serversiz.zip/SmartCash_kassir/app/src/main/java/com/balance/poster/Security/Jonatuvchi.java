package com.balance.poster.Security;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.widget.Toast;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.mMySql.Connector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Jonatuvchi extends AsyncTask<Void, Void, String> {

    Activity context;
    String urlAddress;
    ProgressDialog dialog;

    public Jonatuvchi(Activity context, String urlAddress) {
        this.context = context;
        this.urlAddress = urlAddress;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog = new ProgressDialog(context);
        dialog.setTitle(R.string.jo_natilmoqda);
        dialog.setMessage(context.getString(R.string.iltimos_jonatilmoqda));
        dialog.show();

    }

    @Override
    protected String doInBackground(Void... voids) {
        return downloadData();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        dialog.dismiss();
        if (s.equals("ok")) {
            //
            Security_screen.btn_security_send.setEnabled(false);
            Toast.makeText(context, R.string.muvaf_jonatildi, Toast.LENGTH_SHORT).show();
        } else if (s.equals("no")) {
            new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("")
                    .setContentText(context.getString(R.string.jonatishda_xatolik_boldi))
                    .show();
        } else {

            new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("")
                    .setContentText(s)
                    .show();
        }

    }


    private BufferedReader reader = null;

    private String downloadData() {
        HttpURLConnection con = Connector.connection(urlAddress);
        if (con == null) {
            return context.getString(R.string.internetni_tekshir);
        }
        InputStream inputStream = null;

        String xatolikar = "";
        try {
            if (con != null && Security_screen.isOnline(context)) {
                inputStream = new BufferedInputStream(con.getInputStream());
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String result = reader.readLine();
                if (result != null) {
                    JSONObject jsonObj = new JSONObject(result);
                    String query_result = jsonObj.getString("query_result");
                    if (query_result.equals("SUCCESS")) {
                        return "ok";
                    } else {
                        return "no";
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (SocketException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + "\n" + e.getMessage();
        } catch (JSONException e) {
            e.printStackTrace();
            Calendar calendar1 = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            String strDate = format.format(calendar1.getTime());
            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
            xatolikar = xatolikar + "\n" + e.getMessage();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Calendar calendar1 = Calendar.getInstance();
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    String strDate = format.format(calendar1.getTime());
                    String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    xatolikar = xatolikar + "\n" + e.getMessage();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
        return context.getString(R.string.internetni_tekshir) + "\n" + xatolikar;
    }
}
