package com.balance.poster.Spravichnik.Ofitsant;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 26.08.2018.
 */

public class Ofitsant_sp_adapter extends BaseAdapter {
    Context context;
    ArrayList<Ofitsant_sp_list> ofitsant_sp_lists;

    public Ofitsant_sp_adapter(Context context, ArrayList<Ofitsant_sp_list> ofitsant_sp_lists) {
        this.context = context;
        this.ofitsant_sp_lists = ofitsant_sp_lists;
    }

    @Override
    public int getCount() {
        return ofitsant_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return ofitsant_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView ofitsant_sp_royhat_item_Num, ofitsant_sp_royhat_item_id, ofitsant_sp_royhat_item_FIO, ofitsant_sp_royhat_item_foizi;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;
        ViewHolder holder = new ViewHolder();
        Ofitsant_sp_list ofitsant_sp_list = ofitsant_sp_lists.get(position);

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.ofitsant_sp_royhat_item, null);

            holder.ofitsant_sp_royhat_item_id = (TextView) row.findViewById(R.id.ofitsant_sp_royhat_item_id);
            holder.ofitsant_sp_royhat_item_FIO = (TextView) row.findViewById(R.id.ofitsant_sp_royhat_item_FIO);
            holder.ofitsant_sp_royhat_item_foizi = (TextView) row.findViewById(R.id.ofitsant_sp_royhat_item_foizi);
            holder.ofitsant_sp_royhat_item_Num = (TextView) row.findViewById(R.id.ofitsant_sp_royhat_item_Num);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }
        holder.ofitsant_sp_royhat_item_id.setText(ofitsant_sp_list.getId());
        holder.ofitsant_sp_royhat_item_FIO.setText(ofitsant_sp_list.getFio());
        holder.ofitsant_sp_royhat_item_foizi.setText(ofitsant_sp_list.getFoiz());
        holder.ofitsant_sp_royhat_item_Num.setText(ofitsant_sp_list.getNum());


        return row;
    }
}
