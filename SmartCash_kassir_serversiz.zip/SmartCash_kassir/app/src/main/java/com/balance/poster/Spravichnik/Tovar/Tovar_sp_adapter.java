package com.balance.poster.Spravichnik.Tovar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.R;
import com.balance.poster.Spravichnik.Otdel.Otdel_sp_adapter;
import com.balance.poster.Spravichnik.Otdel.Otdel_sp_list;

import java.util.ArrayList;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Tovar_sp_adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Tovar_sp_list> tovar_sp_lists;

    public Tovar_sp_adapter(Context context, ArrayList<Tovar_sp_list> tovar_sp_lists) {
        this.context = context;
        this.tovar_sp_lists = tovar_sp_lists;
    }

    @Override
    public int getCount() {
        return tovar_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return tovar_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    private class ViewHolder {
        TextView tovar_sp_royhat_item_Id,tovar_sp_royhat_item_Num,tovar_sp_royhat_item_Nomi, tovar_sp_royhat_item_Foiz,tovar_sp_royhat_item_Menu
                ,tovar_sp_royhat_item_Popular,tovar_sp_royhat_item_Narxi;
        ImageView tova_sp_royhat_item_Img;
    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        ViewHolder holder=new ViewHolder();
        Tovar_sp_list tovar_sp_list=tovar_sp_lists.get(position);

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.tovar_sp_royhat_item,null);
            holder.tova_sp_royhat_item_Img=(ImageView)row.findViewById(R.id.tova_sp_royhat_item_Img);
            holder.tovar_sp_royhat_item_Id=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Id);
            holder.tovar_sp_royhat_item_Num=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Num);
            holder.tovar_sp_royhat_item_Nomi=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Nomi);
            holder.tovar_sp_royhat_item_Foiz=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Foiz);
            holder.tovar_sp_royhat_item_Menu=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Menu);
            holder.tovar_sp_royhat_item_Popular=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Popular);
            holder.tovar_sp_royhat_item_Narxi=(TextView)row.findViewById(R.id.tovar_sp_royhat_item_Narxi);
            row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
        holder.tovar_sp_royhat_item_Id.setText(tovar_sp_list.getId());
        holder.tovar_sp_royhat_item_Num.setText(tovar_sp_list.getNum());
        holder.tovar_sp_royhat_item_Nomi.setText(tovar_sp_list.getNomi());
        holder.tovar_sp_royhat_item_Narxi.setText(tovar_sp_list.getNarx());
        String foiz=tovar_sp_list.getFoiz();
        String foizNomi="";

        if (foiz.equals("0")){
            foizNomi="Yo`q";
        }else {
           foizNomi="Ha";
        }
        holder.tovar_sp_royhat_item_Foiz.setText(foizNomi);
        holder.tovar_sp_royhat_item_Menu.setText(tovar_sp_list.getMenu());
        byte[]food=tovar_sp_list.getRasm();
        Bitmap bitmap= BitmapFactory.decodeByteArray(food,0,food.length);
        holder.tova_sp_royhat_item_Img.setImageBitmap(bitmap);

        return row;
    }
}
