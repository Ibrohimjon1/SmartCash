package com.balance.poster.Admin.Admin_sp_royhat;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.balance.poster.R;
import com.balance.poster.Spravichnik.Foydalanuvchi.Foydalanuvchi_sp_royhat;
import com.balance.poster.Spravichnik.Menu.Menu_sp_royhat;
import com.balance.poster.Spravichnik.Ofitsant.Ofitsant_sp_royhat;
import com.balance.poster.Spravichnik.Otdel.Otdel_sp_royhat;
import com.balance.poster.Spravichnik.Printer.Printer_sp_royhat;
import com.balance.poster.Spravichnik.Stol_Sp.Stol_sp_royhat;
import com.balance.poster.Spravichnik.Tovar.Tovar_sp_royhat;
import com.balance.poster.Spravichnik.url.Url_sp_royhat;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Admin_Sp_oyna extends FragmentActivity {
    LinearLayout admin_sp_waiter, admin_sp_user, admin_sp_otdel, admin_sp_menu, admin_sp_meal, admin_sp_table, admin_sp_printer, admin_sp_url;
    FragmentTransaction fragment;
    LinearLayout eski_bosilgan;
    ImageView btn_admin_hisob_ortga;
    public static ImageView btn_admin_spr_qoshish;
    SharedPreferences sharedPreferences;
    CardView CardView_ofitsant, CardView_otdel, stol_CardView;
    TextView txt_asos_toolbar, txt_foyda, txt_ofit, txt_stol, txt_menu, txt_otdel, txt_taom, txt_printer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_sp_oyna);

        txt_asos_toolbar = findViewById(R.id.txt_asos_toolbar);
        txt_foyda = findViewById(R.id.txt_foydalanuvchi);
        txt_menu = findViewById(R.id.txt_menu);
        txt_ofit = findViewById(R.id.txt_ofitsant);
        txt_stol = findViewById(R.id.txt_stol);
        txt_otdel = findViewById(R.id.txt_otdel);
        txt_taom = findViewById(R.id.txt_taomlar);
        txt_printer = findViewById(R.id.txt_printer);

        txt_asos_toolbar.setText(R.string.ma_lumotlar_oynasi);
        txt_foyda.setText(R.string.foydalanuvchi);
        txt_menu.setText(R.string.menu);
        txt_ofit.setText(R.string.admin_ofitsant);
        txt_stol.setText(R.string.stol);
        txt_otdel.setText(R.string.admin_otdel);
        txt_taom.setText(R.string.taomlar);
        txt_printer.setText(R.string.printer);

        admin_sp_meal = (LinearLayout) findViewById(R.id.admin_sp_meal);
        admin_sp_waiter = (LinearLayout) findViewById(R.id.admin_sp_waiter);
        admin_sp_user = (LinearLayout) findViewById(R.id.admin_sp_user);
        admin_sp_otdel = (LinearLayout) findViewById(R.id.admin_sp_otdel);
        admin_sp_menu = (LinearLayout) findViewById(R.id.admin_sp_menu);
        admin_sp_table = (LinearLayout) findViewById(R.id.admin_sp_table);
        admin_sp_printer = (LinearLayout) findViewById(R.id.admin_sp_printer);
        admin_sp_url = (LinearLayout) findViewById(R.id.admin_sp_url);
        CardView_ofitsant = (CardView) findViewById(R.id.ofitsant_CardView);
        CardView_otdel = (CardView) findViewById(R.id.otdel_CardView);
        stol_CardView = (CardView) findViewById(R.id.stol_CardView);

        btn_admin_hisob_ortga = (ImageView) findViewById(R.id.btn_admin_hisob_ortga);
        btn_admin_spr_qoshish = (ImageView) findViewById(R.id.btn_admin_spr_qoshish);
        sharedPreferences = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        int ofitsant_bormi = sharedPreferences.getInt("ofitsant_bormi", 0);
        int otdel_bormi = sharedPreferences.getInt("otdel_bormi", 0);
        int stol_bormi = sharedPreferences.getInt("stol_bormi", 0);


        if (ofitsant_bormi == 1) {
            CardView_ofitsant.setVisibility(View.VISIBLE);
        } else {
            CardView_ofitsant.setVisibility(View.GONE);

        }
        if (otdel_bormi != 0) {
            CardView_otdel.setVisibility(View.VISIBLE);
        } else {
            CardView_otdel.setVisibility(View.GONE);
        }
        if (stol_bormi == 1) {
            stol_CardView.setVisibility(View.VISIBLE);
        } else {
            stol_CardView.setVisibility(View.GONE);
        }

        btn_admin_spr_qoshish.setVisibility(View.GONE);

        btn_admin_hisob_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        admin_sp_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_user.setSelected(true);
                eski_bosilgan = admin_sp_user;
                changeFragment(new Foydalanuvchi_sp_royhat());

            }
        });
        admin_sp_meal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_meal.setSelected(true);
                eski_bosilgan = admin_sp_meal;
                changeFragment(new Tovar_sp_royhat());

            }
        });
        admin_sp_waiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_waiter.setSelected(true);
                eski_bosilgan = admin_sp_waiter;
                changeFragment(new Ofitsant_sp_royhat());

            }
        });
        admin_sp_otdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_otdel.setSelected(true);
                eski_bosilgan = admin_sp_otdel;
                changeFragment(new Otdel_sp_royhat());

            }
        });

        admin_sp_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_menu.setSelected(true);
                eski_bosilgan = admin_sp_menu;
                changeFragment(new Menu_sp_royhat());

            }
        });
        admin_sp_table.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_table.setSelected(true);
                eski_bosilgan = admin_sp_table;
                changeFragment(new Stol_sp_royhat());

            }
        });
        admin_sp_printer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_printer.setSelected(true);
                eski_bosilgan = admin_sp_printer;
                changeFragment(new Printer_sp_royhat());

            }
        });
        admin_sp_url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eski_bosilgan != null) {
                    eski_bosilgan.setSelected(false);
                }
                admin_sp_url.setSelected(true);
                eski_bosilgan = admin_sp_url;
                changeFragment(new Url_sp_royhat());

            }
        });
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.admin_sp_Fregmant, targetFragment)
                .commit();

    }
}
