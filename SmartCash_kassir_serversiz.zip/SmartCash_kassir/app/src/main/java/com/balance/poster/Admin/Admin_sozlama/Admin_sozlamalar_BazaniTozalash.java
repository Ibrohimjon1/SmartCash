package com.balance.poster.Admin.Admin_sozlama;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.balance.poster.R;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_BazaniTozalash extends Fragment {
    View parent_view;
    LinearLayout set_ruchnoy_delete;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_bazanitozalash, container, false);
       init();
        return parent_view;
    }
    public void init(){
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        set_ruchnoy_delete=(LinearLayout)parent_view.findViewById(R.id.set_ruchnoy_delete);
        set_ruchnoy_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ruchnoy_delete_dialog();
            }
        });

    }
    private void Ruchnoy_delete_dialog() {
        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_ruchnoy_delete);
        dialog.setCancelable(true);
        dialog.setTitle("");
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        dialog.show();
    }

}
