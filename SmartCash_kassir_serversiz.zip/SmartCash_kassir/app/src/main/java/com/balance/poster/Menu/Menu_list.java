package com.balance.poster.Menu;

/**
 * Created by Ibrohimjon on 19.08.2018.
 */

public class Menu_list {

    String Id;
    String Nomi;
    private byte[] Image;

    public Menu_list(String id, String nomi, byte[] image) {
        Id = id;
        Nomi = nomi;
        Image = image;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }

    public byte[] getImage() {
        return Image;
    }

    public void setImage(byte[] image) {
        Image = image;
    }
}
