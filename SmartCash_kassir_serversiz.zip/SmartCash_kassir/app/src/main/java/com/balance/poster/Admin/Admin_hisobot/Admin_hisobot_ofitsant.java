package com.balance.poster.Admin.Admin_hisobot;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.poster.Admin.Admin_Assosiy_oyna.Admin_asosiy_oyna;
import com.balance.poster.Asosiy.Bosh_oyna;
import com.balance.poster.Asosiy.Stol_oyna;
import com.balance.poster.Hisobot.Hisob_list_row;
import com.balance.poster.Hisobot.Hisob_ofit_list;
import com.balance.poster.Hisobot.Hisobot_adapter_row;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Ofitsant.Ofitsant_oyna;
import com.balance.poster.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

import me.ithebk.barchart.BarChart;
import me.ithebk.barchart.BarChartModel;

public class Admin_hisobot_ofitsant extends Fragment {

    private View parent_view;
    private static BarChart barChartVertical;
    static TextView txt_mal_yoq, txt_hisob_ofit_nomi;
    FragmentTransaction fragment;
    static View layout_ofit_mal_yoq;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.hisobot_ofitsant, container, false);
        init();
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.hisob_Fregmant, targetFragment)
                .commit();

    }

    public void init() {
        barChartVertical = (BarChart) parent_view.findViewById(R.id.bar_chart_vertical);
        txt_mal_yoq = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_ma_yoq);
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        txt_hisob_ofit_nomi = (TextView) parent_view.findViewById(R.id.txt_hisob_ofit_nomi);
        Calendar calendar1 = Calendar.getInstance();
        txt_hisob_ofit_nomi.setVisibility(View.VISIBLE);
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        final String strDate = format.format(calendar1.getTime());

        String sql = "SELECT shot.ofit_id, tolov.xizmat_sum FROM TOLOVLAR AS tolov INNER JOIN SHOTLAR AS shot ON tolov.shot_raqam = shot.shot_raqam WHERE tolov.vaqti LIKE '" + strDate + "%' ORDER BY shot.ofit_id ASC";

        Orqa_get_data orqa_get_data = new Orqa_get_data(sql, getContext());
        orqa_get_data.execute();

        barChartVertical.setOnBarClickListener(new BarChart.OnBarClickListener() {
            @Override
            public void onBarClick(BarChartModel barChartModel) {
                String ofit = barChartModel.getBarText();
                String sana = Admin_Hisobot_oyna.txt_admin_hisob_sana.getText().toString();
                if (!ofit.equals("")) {
                    ArrayList<Hisob_list_row> list_rows = new ArrayList<>();
                    String sql = "SELECT tolov.vaqti, tolov.shot_raqam, tolov.taom_sum, tolov.xizmat_sum FROM TOLOVLAR AS tolov INNER JOIN SHOTLAR AS shot ON tolov.shot_raqam = shot.shot_raqam WHERE tolov.vaqti LIKE '" + sana + "%' AND shot.ofit_id = '" + ofit.replace("'", "''") + "'";
                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
                    if (cursor.getCount() != 0) {
                        list_rows.clear();
                        cursor.moveToFirst();
                        int i = 1;
                        int xizmati = 0, taomsuma = 0;
                        do {
                            String sanasi = cursor.getString(0);
                            String shot = cursor.getString(1);
                            String taom = cursor.getString(2);
                            String xizm = cursor.getString(3);
                            if (!taom.equals("")) {
                                try {
                                    taomsuma += Integer.parseInt(taom.replace(" ", ""));
                                } catch (NumberFormatException r) {
                                    r.printStackTrace();
                                    Calendar calendar1 = Calendar.getInstance();
                                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                    String strDate = format.format(calendar1.getTime());
                                    String sqlt = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sqlt);
                                }
                            }
                            if (!xizm.equals("")) {
                                try {
                                    xizmati += Integer.parseInt(xizm.replace(" ", ""));
                                } catch (NumberFormatException r) {
                                    r.printStackTrace();
                                    Calendar calendar1 = Calendar.getInstance();
                                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                                    String strDate = format.format(calendar1.getTime());
                                    String sqlr = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                                    Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, r.getMessage(), sqlr);
                                }
                            }
                            list_rows.add(new Hisob_list_row("" + i, sanasi, shot, Bosh_oyna.getDecimalFormattedString(taom), Bosh_oyna.getDecimalFormattedString(xizm)));
                            i++;
                        } while (cursor.moveToNext());
                        Nom_dialog(list_rows, ofit, strDate, xizmati + "", taomsuma + "");
                    }
                }
            }
        });

    }

    private void Nom_dialog(ArrayList<Hisob_list_row> list_rows, String ofit, String sana, String xizm, String taom) {

        final Dialog dialog = new Dialog(getContext(), R.style.hisob_ozgart_oyna_di);
        dialog.setContentView(R.layout.hisob_ofit_item);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.CENTER;
        wlp.flags &= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        window.setAttributes(wlp);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setTitle("");

        ListView list_hisob_item = dialog.findViewById(R.id.list_hisob_item);
        TextView txt_hisob_item_row_nomi = dialog.findViewById(R.id.txt_hisob_item_row_nomi);
        TextView txt_hisob_item_row_umum_taom = dialog.findViewById(R.id.txt_hisob_item_row_umum_taom);
        TextView txt_hisob_item_row_umum_xizm = dialog.findViewById(R.id.txt_hisob_item_row_umum_xizm);
        Hisobot_adapter_row adapter = new Hisobot_adapter_row(getContext(), list_rows);
        list_hisob_item.setAdapter(adapter);

        txt_hisob_item_row_umum_taom.setText(Bosh_oyna.getDecimalFormattedString(taom));
        txt_hisob_item_row_umum_xizm.setText(Bosh_oyna.getDecimalFormattedString(xizm));

        txt_hisob_item_row_nomi.setText(String.format(String.valueOf(R.string.admin_hisobot_ning_sanadagi), ofit, sana));
        ImageView btn_iks = dialog.findViewById(R.id.btn_hisob_item_iks);
        btn_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();

    }

    public static class Orqa_get_data extends AsyncTask<Void, String, Void> {

        BarChartModel barChartModel;
        String eski_ismi = "";
        int eski_sum = 0;
        ArrayList<Hisob_ofit_list> ofit_lists = new ArrayList<>();
        int KATTASI = 0;
        String sql;
        ProgressDialog dialog;
        Context context;

        public Orqa_get_data(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            ofit_lists.clear();
            barChartVertical.clearAll();
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

//            txt_mal_yoq.setText(R.string.iltimos_mal_yuklanmoqda);
//            txt_mal_yoq.setVisibility(View.VISIBLE);
//            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {

            Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                int i = 0;
                do {
                    String ismi = cursor.getString(0);
                    String summa = cursor.getString(1);
                    int xizma = 0;
                    if (!summa.equals("")) {
                        try {
                            xizma = Integer.parseInt(summa.replace(" ", ""));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }

                    if (ismi.equals(eski_ismi)) {
                        eski_sum += xizma;
                    } else {
                        if (i > 0) {
                            ofit_lists.add(new Hisob_ofit_list(eski_ismi, eski_sum));
                            eski_ismi = ismi;
                            eski_sum = xizma;
                        } else {
                            eski_ismi = ismi;
                            eski_sum = xizma;
                        }
                    }
                    i++;
                } while (cursor.moveToNext());
                if (!eski_ismi.equals("")) {
                    ofit_lists.add(new Hisob_ofit_list(eski_ismi, eski_sum));
                }
                Collections.sort(ofit_lists, new Comparator<Hisob_ofit_list>() {
                    @Override
                    public int compare(Hisob_ofit_list o1, Hisob_ofit_list o2) {
                        return o1.getSummasi() - o2.getSummasi();
                    }
                });

                KATTASI = ofit_lists.get(ofit_lists.size() - 1).getSummasi();
                publishProgress("0");
                for (int k = 0; k < ofit_lists.size(); k++) {
                    Hisob_ofit_list list = ofit_lists.get(k);
                    String ismi = list.getIsmi();
                    int xizmat_sum = list.getSummasi();

                    barChartModel = new BarChartModel();
                    barChartModel.setBarValue(xizmat_sum);
                    barChartModel.setBarValue_str(Bosh_oyna.getDecimalFormattedString("" + xizmat_sum));
                    Random rnd = new Random();
                    barChartModel.setBarColor(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
                    barChartModel.setBarTag(null);
                    barChartModel.setBarText(ismi);
                    publishProgress("1");
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Calendar calendar1 = Calendar.getInstance();
                        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                        String strDate = format.format(calendar1.getTime());
                        String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                        Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                    }
                }

            } else {
                publishProgress("no");
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            dialog.dismiss();
            if (values[0].equals("1")) {
                barChartVertical.addBar(0, barChartModel);
            } else if (values[0].equals("0")) {
                if (KATTASI != 0) {
                    barChartVertical.setBarMaxValue(KATTASI * 120 / 100);
                } else {
                    barChartVertical.setBarMaxValue(5);
                }
                txt_mal_yoq.setVisibility(View.GONE);
                layout_ofit_mal_yoq.setVisibility(View.GONE);
            } else if (values[0].equals("no")) {
                txt_mal_yoq.setText(R.string.ushbu_sanada_ofitsantlar_hisoboti_yo_q);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_mal_yoq.setVisibility(View.VISIBLE);
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }

    }

}
