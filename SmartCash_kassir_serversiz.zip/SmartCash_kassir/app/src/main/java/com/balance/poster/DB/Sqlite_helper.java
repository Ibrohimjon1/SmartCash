package com.balance.poster.DB;

/**
 * Created by Ibrohimjon on 25.08.2018.
 */

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;

public class Sqlite_helper extends SQLiteOpenHelper {

    public Sqlite_helper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public void queryData(String sql) {
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }


    public void Mal_qoshish_1ta(String nomi, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi.trim());
        statement.executeInsert();
        database.close();
    }

    public void Mal_qoshish_stol(int soni, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindDouble(1, soni);
        statement.executeInsert();
        database.close();
    }

    public void Mal_qoshish_2ta(String nomi1, String nomi2, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.executeInsert();
        database.close();
    }

    public void Printer_qoshish(String nomi1, String nomi2, String tip, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.bindString(3, tip.trim());
        statement.executeInsert();
        database.close();
    }

    public void Foydalanuvchi_qoshish(String nomi1, String nomi2, String nomi3, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.bindString(3, nomi3.trim());
        statement.executeInsert();
        database.close();
    }

    public void Otdel_qoshish_3ta(String nomi1, ImageView imageView, String nomi2, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindBlob(2, imageToByte(imageView));
        statement.bindString(3, nomi2.trim());
        statement.executeInsert();
        database.close();
    }

    public void Otdel_qoshish(String id, String nomi1, byte[] imageView, String nomi2, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, id.trim());
        statement.bindString(2, nomi1.trim());
        statement.bindBlob(3, imageView);
        statement.bindString(4, nomi2.trim());
        statement.executeInsert();
        database.close();
    }
    public void Menu_qoshish(String id, String nomi1, byte[] imageView, String nomi2, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, id.trim());
        statement.bindString(2, nomi1.trim());
        statement.bindString(3, nomi2.trim());
        statement.bindBlob(4, imageView);
        statement.executeInsert();
        database.close();
    }
    public void Otdel_Update_3ta(String nomi1, ImageView imageView, String nomi2, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindBlob(2, imageToByte(imageView));
        statement.bindString(3, nomi2.trim());
        statement.executeInsert();
        database.close();
    }

    public void Taom_qoshish(String nomi1, String nomi2, String nomi3, String nomi4, ImageView imageView, String nomi6, String nomi7, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.bindString(3, nomi3.trim());
        statement.bindString(4, nomi4.trim());
        statement.bindBlob(5, imageToByte(imageView));
        statement.bindString(6, nomi6.trim());
        statement.bindString(7, nomi7.trim());
        statement.executeInsert();
        database.close();
    }

    public void Taom_qoshish_down(String id, String nomi, String narxi, String otdel, String menu, byte[] rasm, String foiz, String popul,String print, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, id.trim());
        statement.bindString(2, nomi.trim());
        statement.bindString(3, narxi.trim());
        statement.bindString(4, otdel.trim());
        statement.bindString(5, menu.trim());
        statement.bindBlob(6, rasm);
        statement.bindString(7, foiz.trim());
        statement.bindString(8, popul.trim());
        statement.bindString(9, print.trim());
        statement.executeInsert();
        database.close();
    }

    public void Menu_qoshish_3ta(String nomi1, String nomi2, ImageView imageView, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.bindBlob(3, imageToByte(imageView));
        statement.executeInsert();
        database.close();
    }

    public void Ofitsnt_qoshish_2ta(String nomi1, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.executeInsert();
        database.close();
    }

    public void Ofitsnt_qoshish(String nomi1, String nomi2, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.executeInsert();
        database.close();
    }

    public static Bitmap getScaledBitmap(Bitmap b, int reqWidth, int reqHeight)
    {
        Matrix m = new Matrix();
        m.setRectToRect(new RectF(0, 0, b.getWidth(), b.getHeight()), new RectF(0, 0, reqWidth, reqHeight), Matrix.ScaleToFit.CENTER);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
    }

    public byte[] imageToByte(ImageView imageView) {
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap = getScaledBitmap(bitmap,300,300);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    public void Mal_qoshish_3ta(String nomi1, String nomi2, String nomi3, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.bindString(3, nomi3.trim());
        statement.executeInsert();
        database.close();
    }

    public void Mal_qoshish_4ta(String nomi1, String nomi2, String nomi3, String nomi4, String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, nomi1.trim());
        statement.bindString(2, nomi2.trim());
        statement.bindString(3, nomi3.trim());
        statement.bindString(4, nomi4.trim());
        statement.executeInsert();
        database.close();
    }

    public void Mal_qoshish_tovar(String s, String s1, String s2, String s3, String s4, String s5, String s6, String sql) {

        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, s.trim());
        statement.bindString(2, s1.trim());
        statement.bindString(3, s2.trim());
        statement.bindString(4, s3.trim());
        statement.bindString(5, s4.trim());
        statement.bindString(6, s5.trim());
        statement.bindString(7, s6.trim());
        statement.executeInsert();
        database.close();
    }

    public void Mal_qoshish_zakar(String tov_id, String nomi, String narxi, String soni, String summa, String foizi, String shot_r, String ofit_i, String vaqti, String print, String sql) {

        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, tov_id.trim());
        statement.bindString(2, nomi.trim());
        statement.bindString(3, narxi.trim());
        statement.bindString(4, soni.trim());
        statement.bindString(5, summa.trim());
        statement.bindString(6, foizi.trim());
        statement.bindString(7, shot_r.trim());
        statement.bindString(8, ofit_i.trim());
        statement.bindString(9, vaqti.trim());
        if (!print.equals("-")) {
            statement.bindString(10, print.trim());
        }
        statement.executeInsert();
        database.close();

    }

    public void deleteData(String sql) {
        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.execute();
        database.close();
    }

    public void Mal_qoshish_Otmenlar(String s, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String sql) {

        SQLiteDatabase database = getWritableDatabase();

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindString(1, s.trim());
        statement.bindString(2, s1.trim());
        statement.bindString(3, s2.trim());
        statement.bindString(4, s3.trim());
        statement.bindString(5, s4.trim());
        statement.bindString(6, s5.trim());
        statement.bindString(7, s6.trim());
        statement.bindString(8, s7.trim());
        statement.bindString(9, s8.trim());
        statement.executeInsert();
        database.close();

    }

    public Cursor getData(String sql) {
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
