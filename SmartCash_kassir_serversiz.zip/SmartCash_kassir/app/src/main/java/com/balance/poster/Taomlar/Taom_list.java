package com.balance.poster.Taomlar;

/**
 * Created by Ibrohimjon on 19.08.2018.
 */

public class Taom_list {

    String Id;
    String Nomi;
    String Narxi;
    String Foizi;
    byte[] Image;
    int Yulduz;
    String Printer;

    public Taom_list(String id, String nomi, String narxi, String foizi, byte[] image, int yulduz, String printer) {
        Id = id;
        Nomi = nomi;
        Narxi = narxi;
        Foizi = foizi;
        Image = image;
        Yulduz = yulduz;
        Printer = printer;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }

    public String getNarxi() {
        return Narxi;
    }

    public void setNarxi(String narxi) {
        Narxi = narxi;
    }

    public String getFoizi() {
        return Foizi;
    }

    public void setFoizi(String foizi) {
        Foizi = foizi;
    }

    public byte[] getImage() {
        return Image;
    }

    public void setImage(byte[] image) {
        Image = image;
    }

    public int getYulduz() {
        return Yulduz;
    }

    public void setYulduz(int yulduz) {
        Yulduz = yulduz;
    }

    public String getPrinter() {
        return Printer;
    }

    public void setPrinter(String printer) {
        Printer = printer;
    }
}
