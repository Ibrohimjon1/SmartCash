package com.balance.poster.Spravichnik.url;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Spravichnik.Printer.Printer_sp_royhat;
import com.balance.poster.Spravichnik.Stol_Sp.Stol_sp_royhat;

/**
 * Created by Hunter on 28.08.2018.
 */

public class Url_sp_QoshishOyna extends AppCompatActivity {
    Button btn_url_sp_qoshish, btn_url_sp_chiqish;
    EditText edit_Url_sp_Adress;
    String sessionId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.url_sp_oyna);
        init();
        sessionId = getIntent().getStringExtra("SESSION_ID");
        if (!sessionId.equals("")) {
            getDataForUpdate();
        }
    }

    public void init() {
        btn_url_sp_qoshish = (Button) findViewById(R.id.btn_url_sp_qoshish);
        btn_url_sp_chiqish = (Button) findViewById(R.id.btn_url_sp_chiqish);
        edit_Url_sp_Adress = (EditText) findViewById(R.id.edit_Url_sp_Adress);

        btn_url_sp_chiqish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        btn_url_sp_qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edit_Url_sp_Adress.getText().toString().equals("")) {

                    if (!sessionId.equals("")) {
                        String sql = "UPDATE YOLLAR SET url=? WHERE Id='" + sessionId + "'";
                        String nomi = edit_Url_sp_Adress.getText().toString().trim();
                        Login_oyna.SQLITE_HELPER.Ofitsnt_qoshish_2ta(nomi, sql);
                        edit_Url_sp_Adress.setText("");
                        Url_sp_royhat.GetData_Url();
                        finish();

                    } else {
                        String sql = "INSERT INTO YOLLAR VALUES (NULL, ?)";
                        String Nomi = edit_Url_sp_Adress.getText().toString();
                        Login_oyna.SQLITE_HELPER.Ofitsnt_qoshish_2ta(Nomi, sql);
                        edit_Url_sp_Adress.setText("");
                        Url_sp_royhat.GetData_Url();
                        finish();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.malum_toliq_kiriting), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void getDataForUpdate() {

        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM YOLLAR WHERE Id='" + sessionId + "'");
        if (cursor_2.getCount() != 0) {
            cursor_2.moveToFirst();

            edit_Url_sp_Adress.setText(cursor_2.getString(1));


        }
    }
}