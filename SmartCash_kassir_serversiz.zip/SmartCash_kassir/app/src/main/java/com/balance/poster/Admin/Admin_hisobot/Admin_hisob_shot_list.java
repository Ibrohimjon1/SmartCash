package com.balance.poster.Admin.Admin_hisobot;

/**
 * Created by Ibrohimjon on 06.09.2018.
 */

public class Admin_hisob_shot_list {

    String Tartib;
    String Sana;
    String Taom;
    String Soni;
    String Narxi;

    public Admin_hisob_shot_list(String tartib, String sana, String taom, String soni, String narxi) {
        Tartib = tartib;
        Sana = sana;
        Taom = taom;
        Soni = soni;
        Narxi = narxi;
    }

    public String getTartib() {
        return Tartib;
    }

    public void setTartib(String tartib) {
        Tartib = tartib;
    }

    public String getSana() {
        return Sana;
    }

    public void setSana(String sana) {
        Sana = sana;
    }

    public String getTaom() {
        return Taom;
    }

    public void setTaom(String taom) {
        Taom = taom;
    }

    public String getSoni() {
        return Soni;
    }

    public void setSoni(String soni) {
        Soni = soni;
    }

    public String getNarxi() {
        return Narxi;
    }

    public void setNarxi(String narxi) {
        Narxi = narxi;
    }
}
