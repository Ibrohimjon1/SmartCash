package com.balance.poster.Spravichnik.Otdel;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.Otmenalar.Otmen_adpter;
import com.balance.poster.R;
import com.balance.poster.Spravichnik.Ofitsant.Ofitsant_sp_adapter;
import com.balance.poster.Spravichnik.Ofitsant.Ofitsant_sp_list;

import java.util.ArrayList;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Otdel_sp_adapter extends BaseAdapter {
    ArrayList<Otdel_sp_list>otdel_sp_lists;
    Context context;

    public Otdel_sp_adapter( Context context,ArrayList<Otdel_sp_list> otdel_sp_lists) {
        this.otdel_sp_lists = otdel_sp_lists;
        this.context = context;
    }

    @Override
    public int getCount() {
        return otdel_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return otdel_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView otdel_sp_royhat_item_id,otdel_sp_royhat_item_Num,otdel_sp_royhat_item_Nomi, otdel_sp_royhat_item_Printer;
        ImageView otdel_sp_royhat_item_Img;
    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        ViewHolder holder=new ViewHolder();
        Otdel_sp_list otdel_sp_list=otdel_sp_lists.get(position);

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.otdel_sp_royhat_item,null);
            holder.otdel_sp_royhat_item_Img=(ImageView)row.findViewById(R.id.otdel_sp_royhat_item_Img);
            holder.otdel_sp_royhat_item_id=(TextView)row.findViewById(R.id.otdel_sp_royhat_item_id);
            holder.otdel_sp_royhat_item_Nomi=(TextView)row.findViewById(R.id.otdel_sp_royhat_item_Nomi);
            holder.otdel_sp_royhat_item_Num=(TextView)row.findViewById(R.id.otdel_sp_royhat_item_Num);
            holder.otdel_sp_royhat_item_Printer=(TextView)row.findViewById(R.id.otdel_sp_royhat_item_Printer);
            row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
        holder.otdel_sp_royhat_item_id.setText(otdel_sp_list.getId());
        holder.otdel_sp_royhat_item_Nomi.setText(otdel_sp_list.getNomi());
        holder.otdel_sp_royhat_item_Num.setText(otdel_sp_list.getNum());
        holder.otdel_sp_royhat_item_Printer.setText(otdel_sp_list.getPrinter());

        byte[]food=otdel_sp_list.getRasm();
        Bitmap bitmap= BitmapFactory.decodeByteArray(food,0,food.length);
        holder.otdel_sp_royhat_item_Img.setImageBitmap(bitmap);

        return row;
    }
}
