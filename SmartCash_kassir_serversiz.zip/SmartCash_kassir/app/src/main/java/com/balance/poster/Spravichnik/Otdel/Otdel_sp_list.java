package com.balance.poster.Spravichnik.Otdel;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Otdel_sp_list {
    String id;
    String num;
    String Nomi;
    String printer;
    byte[] rasm;

    public Otdel_sp_list(String id, String num, String nomi, String printer, byte[] rasm) {
        this.id = id;
        this.num = num;
        Nomi = nomi;
        this.printer = printer;
        this.rasm = rasm;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNomi() {
        return Nomi;
    }

    public void setNomi(String nomi) {
        Nomi = nomi;
    }

    public String getPrinter() {
        return printer;
    }

    public void setPrinter(String printer) {
        this.printer = printer;
    }

    public byte[] getRasm() {
        return rasm;
    }

    public void setRasm(byte[] rasm) {
        this.rasm = rasm;
    }
}
