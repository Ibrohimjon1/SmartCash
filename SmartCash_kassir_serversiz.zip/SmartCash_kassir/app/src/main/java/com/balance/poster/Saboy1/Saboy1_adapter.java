package com.balance.poster.Saboy1;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 05.09.2018.
 */

public class Saboy1_adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Saboy1_list> saboy1_lists;

    public Saboy1_adapter(Context context, ArrayList<Saboy1_list> saboy1_lists) {
        this.context = context;
        this.saboy1_lists = saboy1_lists;
    }

    @Override
    public int getCount() {
        return saboy1_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return saboy1_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_saboy1_item_id, txt_saboy1_item_Num, txt_saboy1_item_vaqt;
        ImageView imageView;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;

        Saboy1_list saboy1list = saboy1_lists.get(position);
        ViewHolder holder = new ViewHolder();

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.saboy1_oyna_item, null);
            holder.txt_saboy1_item_id = row.findViewById(R.id.txt_saboy1_item_id);
            holder.txt_saboy1_item_Num = row.findViewById(R.id.txt_saboy1_item_Num);
            holder.txt_saboy1_item_vaqt = row.findViewById(R.id.txt_saboy1_item_vaqt);
            holder.imageView = row.findViewById(R.id.image_saboy_item);

            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }
        if (saboy1list.getNum().equals("0")) {
            holder.imageView.setImageResource(R.drawable.plus_icon);
            holder.txt_saboy1_item_id.setText(saboy1list.getId());
            holder.txt_saboy1_item_Num.setVisibility(View.GONE);
            holder.txt_saboy1_item_vaqt.setVisibility(View.GONE);
        } else {
            holder.txt_saboy1_item_id.setText(saboy1list.getId());
            holder.txt_saboy1_item_Num.setText(saboy1list.getNum());
            holder.txt_saboy1_item_vaqt.setText(saboy1list.getSana());
            holder.imageView.setImageResource(R.drawable.packageee);
            holder.txt_saboy1_item_Num.setVisibility(View.VISIBLE);
            holder.txt_saboy1_item_vaqt.setVisibility(View.VISIBLE);
        }
        return row;
    }
}
