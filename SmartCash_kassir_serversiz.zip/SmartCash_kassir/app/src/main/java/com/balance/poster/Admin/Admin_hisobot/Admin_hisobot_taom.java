package com.balance.poster.Admin.Admin_hisobot;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.poster.Asosiy.Bosh_oyna;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Print.Tolov_pechat;
import com.balance.poster.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Admin_hisobot_taom extends Fragment {


    public static View parent_view;
    public static TextView txt_admin_hisob_taom_yoq, txt_jami_soni, txt_jami_sum, txt_nomi, txt_jami,
            txt_soni, txt_narxi, txt_sum, txt_hisob_taom_label;
    public static ListView listView;
    public static Admin_hisob_taom_adapter adapter;
    public static ArrayList<Admin_hisob_taom_list> taom_lists = new ArrayList<>();
    public static View layout_ofit_mal_yoq;
    ImageView otdel_print;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_hisobot_taom, container, false);

        init();
        return parent_view;
    }

    public void init() {
        txt_nomi = parent_view.findViewById(R.id.txt_nomi);
        txt_jami = parent_view.findViewById(R.id.txt_jami);
        txt_soni = parent_view.findViewById(R.id.txt_soni);
        txt_narxi = parent_view.findViewById(R.id.txt_narxi);
        txt_sum = parent_view.findViewById(R.id.txt_sum);
        otdel_print = parent_view.findViewById(R.id.otdel_print);
        txt_hisob_taom_label = parent_view.findViewById(R.id.txt_hisob_taom_label);

        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        txt_admin_hisob_taom_yoq = (TextView) parent_view.findViewById(R.id.txt_admin_hisob_taom_yoq);
        txt_jami_soni = (TextView) parent_view.findViewById(R.id.txt_admin_hisob_taom_jami_soni);
        txt_jami_sum = (TextView) parent_view.findViewById(R.id.txt_admin_hisob_taom_jami_sum);
        listView = (ListView) parent_view.findViewById(R.id.list_hisob_taom);

        txt_nomi.setText(R.string.nomi);
        txt_jami.setText(R.string.jami);
        txt_soni.setText(R.string.soni);
        txt_narxi.setText(R.string.narxi);
        txt_sum.setText(R.string.sum);
        txt_hisob_taom_label.setText(R.string.sotilgan_taomlar_hisoboti);

        adapter = new Admin_hisob_taom_adapter(getContext(), taom_lists);
        listView.setAdapter(adapter);
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        String strDate = format.format(calendar1.getTime());

        otdel_print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (taom_lists.size() > 0) {
                    new SweetAlertDialog(getContext(), SweetAlertDialog.WARNING_TYPE)
                            .setContentText(getString(R.string.pechat_qilmoqchimisiz))
                            .setCancelText(getString(R.string.yoq))
                            .setConfirmText(getString(R.string.ha))
                            .showCancelButton(true)
                            .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(SweetAlertDialog sDialog) {
                                    // reuse previous dialog instance, keep widget user state, reset them if you need
                                    sDialog.cancel();

                                }
                            })
                            .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                @Override
                                public void onClick(final SweetAlertDialog sDialog) {
                                    sDialog.dismiss();
                                    Orqa_Pechat orqa_pechat = new Orqa_Pechat();
                                    orqa_pechat.execute();
                                }
                            })
                            .show();
                } else {

                }
            }
        });

        String sql = "SELECT zakaz.tovar_id, zakaz.nomi, SUM(zakaz.soni), zakaz.narxi, SUM(zakaz.soni) * zakaz.narxi AS summa, taom.otdel_id FROM ZAKAZLAR AS zakaz INNER JOIN TAOMLAR AS taom ON zakaz.tovar_id = taom.Id WHERE zakaz.vaqti LIKE '" + strDate + "%' GROUP BY zakaz.tovar_id ORDER BY SUM(zakaz.soni) DESC";
        Yangilash yangilash = new Yangilash(sql, getContext());
        yangilash.execute();


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Admin_hisob_taom_list list = taom_lists.get(position);
                String taom_nomi = list.getNomi();
                String Soni = list.getSoni();

                if (!taom_nomi.equals("")) {
                    ArrayList<Admin_hisobot_taom_row_list> list_rows = new ArrayList<>();

                    String sql = "SELECT zakaz.ofit_id,SUM(zakaz.soni) FROM ZAKAZLAR AS zakaz WHERE zakaz.vaqti LIKE '" + Admin_Hisobot_oyna.txt_admin_hisob_sana.getText().toString() + "%' AND zakaz.nomi LIKE '" + taom_nomi.replace("'", "''") + "' GROUP BY zakaz.ofit_id";

                    Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
                    list_rows.clear();
                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();

                        int tart = 0;
                        do {
                            tart++;
                            String soni = cursor.getString(1);
                            String ismi = cursor.getString(0);

                            String sql1 = "SELECT ismi FROM OFITSANT WHERE Id = '" + ismi + "'";
                            Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData(sql1);
                            if (cursor1.getCount() != 0) {
                                cursor1.moveToFirst();
                                do {
                                    ismi = cursor1.getString(0);
                                } while (cursor1.moveToNext());
                            }
                            list_rows.add(new Admin_hisobot_taom_row_list("" + tart, ismi, soni));
                        } while (cursor.moveToNext());
                        Shot_dialog(list_rows, taom_nomi, Soni);
                    }
                }
            }
        });

    }


    class Orqa_Pechat extends AsyncTask<Void, String, String> {

        ProgressDialog loading;
        String otdel_nomi;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(getContext(), getString(R.string.pechat_qilinmoqda), null, true, true);
        }

        @Override
        protected String doInBackground(Void... voids) {
            return Qogozga_chiqar();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            loading.dismiss();
        }
    }


    public String Qogozga_chiqar() {

        ArrayList<Admin_hisob_taom_list> taom_list = taom_lists;

        Collections.sort(taom_list, new Comparator<Admin_hisob_taom_list>() {
            @Override
            public int compare(Admin_hisob_taom_list s1, Admin_hisob_taom_list s2) {
                return s1.getPrinter().compareTo(s2.getPrinter());
            }
        });

        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        String strDate = format.format(calendar1.getTime());

        String nom = "" + getString(R.string.admin_hisobot) + "\n";
        String pechat_shapka = "\n" +
                "________________________________________________\n\n" +
                " " + getString(R.string.vaqti) + ":                    " + strDate + "  ";

        String asosiy = "";


        String eski_print = "";
        String eski_asos = "";
        for (int i = 0; i < taom_list.size(); i++) {
            Admin_hisob_taom_list tolov_list = taom_list.get(i);
            String print = tolov_list.getPrinter();

            if (!eski_print.equals("") && print.equals(eski_print)) {
                String nomi = tolov_list.getNomi();
                String soni = tolov_list.getSoni();
                String summa = tolov_list.getSumma();
                if (nomi.length() < 32) {
                    for (int j = nomi.length(); j < 32; j++) {
                        nomi = nomi + " ";
                    }
                } else {
                    String taom_boshi = "" + nomi.substring(0, 32) + "             \n ";
                    String oxir = nomi.substring(32, nomi.length());
                    if (oxir.length() < 32) {
                        for (int j = oxir.length(); j < 32; j++) {
                            oxir = oxir + " ";
                        }
                    }
                    nomi = taom_boshi + oxir;
                }
                if (soni.length() < 4) {
                    for (int k = soni.length(); k < 4; k++) {
                        soni = soni + " ";
                    }
                }

                if (summa.length() < 8) {
                    for (int k = summa.length(); k < 8; k++) {
                        summa = " " + summa;
                    }
                }
                asosiy = asosiy + "\n " + nomi + " " + soni + " " + summa + "";
            } else {
                String sql = "";
                eski_print = print;
                sql = "SELECT nomi FROM OTDEL WHERE Id = '" + print + "'";
                Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
                String otdel = "";
                if (cursor.getCount() != 0) {
                    cursor.moveToFirst();
                    do {
                        otdel = cursor.getString(0);
                    } while (cursor.moveToNext());
                }
                asosiy = asosiy + "\n________________________________________________\n" +
                        " " + otdel +
                        "\n________________________________________________\n";
                String nomi = tolov_list.getNomi();
                String soni = tolov_list.getSoni();
                String summa = tolov_list.getSumma();
                if (nomi.length() < 32) {
                    for (int j = nomi.length(); j < 32; j++) {
                        nomi = nomi + " ";
                    }
                } else {
                    String taom_boshi = "" + nomi.substring(0, 32) + "             \n ";
                    String oxir = nomi.substring(32, nomi.length());
                    if (oxir.length() < 32) {
                        for (int j = oxir.length(); j < 32; j++) {
                            oxir = oxir + " ";
                        }
                    }
                    nomi = taom_boshi + oxir;
                }
                if (soni.length() < 4) {
                    for (int k = soni.length(); k < 4; k++) {
                        soni = soni + " ";
                    }
                }

                if (summa.length() < 8) {
                    for (int k = summa.length(); k < 8; k++) {
                        summa = " " + summa;
                    }
                }
                asosiy = asosiy + "\n " + nomi + " " + soni + " " + summa + "";
            }
        }
        String jami_so = txt_jami_soni.getText().toString();
        String jami_sum = txt_jami_sum.getText().toString();

        for (int i = jami_sum.length(); i < 14; i++) {
            jami_sum = " " + jami_sum;
        }

        String qi = jami_so + jami_sum;
        if (qi.length() < 36) {
            for (int i = qi.length(); i < 36; i++) {
                qi = " " + qi;
            }
        }


        String padval =
                "________________________________________________\n\n"
                        + " " + getString(R.string.jami) + ":      " + qi;

        String xatolik_soz = "";
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT url FROM PRINTER WHERE nomi LIKE 'Kassa'");
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            String print_ip = cursor.getString(0);
            xatolik_soz = Tolov_pechat.Pechat_qilish(print_ip, nom, pechat_shapka, asosiy, padval);

        }


        return xatolik_soz;
    }

    private void Shot_dialog(ArrayList<Admin_hisobot_taom_row_list> list_rows, String taom, String soni) {

        final Dialog dialog = new Dialog(getContext(), R.style.hisob_ozgart_oyna_di);
        dialog.setContentView(R.layout.hisob_taom_item);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();

        wlp.gravity = Gravity.CENTER;
        wlp.flags &= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
        window.setAttributes(wlp);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setTitle("");

        ListView list_hisob_item = dialog.findViewById(R.id.list_hisob_item);
        TextView txt_hisob_item_row_nomi = dialog.findViewById(R.id.txt_hisob_item_row_nomi);
        TextView txt_hisob_item_row_soni = dialog.findViewById(R.id.txt_hisob_item_row_umum_soni);
        Admin_hisobot_taom_adapter_row adapter = new Admin_hisobot_taom_adapter_row(getContext(), list_rows);
        list_hisob_item.setAdapter(adapter);


        txt_hisob_item_row_nomi.setText(String.format(getString(R.string.admin_hisobot_ofitsant_boyicha), taom));
        txt_hisob_item_row_soni.setText(soni);
        ImageView btn_iks = dialog.findViewById(R.id.btn_hisob_item_iks);
        btn_iks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();

    }

    public static class Yangilash extends AsyncTask<Void, Void, String> {

        String sql;
        int umum_soni = 0, umum_sum = 0;
        Context context;
        ProgressDialog dialog;

        public Yangilash(String sql, Context context) {
            this.sql = sql;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(context, context.getString(R.string.iltimos_mal_yuklanmoqda), null, true, true);

//            txt_admin_hisob_taom_yoq.setVisibility(View.VISIBLE);
//            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
//            txt_admin_hisob_taom_yoq.setText(R.string.iltimos_mal_yuklanmoqda);
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... voids) {
            taom_lists.clear();
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData(sql);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                int tartib = 0;
                umum_soni = 0;
                umum_sum = 0;
                do {
                    tartib++;
                    String tov_id = cursor.getString(0);
                    String nomi = cursor.getString(1);
                    String soni = cursor.getString(2);
                    String narxi = cursor.getString(3);
                    String summa = cursor.getString(4);
                    String printer = cursor.getString(5);
                    if (!soni.equals("")) {
                        try {
                            umum_soni += Integer.parseInt(soni);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                    if (!summa.equals("")) {
                        try {
                            umum_sum += Integer.parseInt(summa.replace(" ", ""));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                    taom_lists.add(new Admin_hisob_taom_list(tov_id, "" + tartib, nomi, soni, Bosh_oyna.getDecimalFormattedString(narxi), Bosh_oyna.getDecimalFormattedString(summa), printer));
                } while (cursor.moveToNext());
                return "ok";
            } else {
                umum_soni = 0;
                umum_sum = 0;
                return "yoq";
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            adapter.notifyDataSetChanged();
            txt_jami_soni.setText(String.valueOf(umum_soni));
            txt_jami_sum.setText(Bosh_oyna.getDecimalFormattedString(String.valueOf(umum_sum)));
            if (s.equals("ok")) {
                txt_admin_hisob_taom_yoq.setVisibility(View.GONE);
                layout_ofit_mal_yoq.setVisibility(View.GONE);
            } else {
                txt_admin_hisob_taom_yoq.setVisibility(View.VISIBLE);
                layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
                txt_admin_hisob_taom_yoq.setText(R.string.ushbu_sanada_sotilgan_taomlar_yo_q);
            }
        }
    }
}
