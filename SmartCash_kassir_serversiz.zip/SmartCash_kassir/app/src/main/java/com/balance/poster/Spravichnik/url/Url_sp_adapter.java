package com.balance.poster.Spravichnik.url;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.R;
import com.balance.poster.Spravichnik.Ofitsant.Ofitsant_sp_adapter;
import com.balance.poster.Spravichnik.Ofitsant.Ofitsant_sp_list;

import java.util.ArrayList;

/**
 * Created by Hunter on 27.08.2018.
 */

public class Url_sp_adapter  extends BaseAdapter{
    private Context context;
    private ArrayList<Url_sp_list>url_sp_lists;

    public Url_sp_adapter(Context context, ArrayList<Url_sp_list> url_sp_lists) {
        this.context = context;
        this.url_sp_lists = url_sp_lists;
    }

    @Override
    public int getCount() {
        return url_sp_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return url_sp_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        TextView url_sp_royhat_item_Id,url_sp_royhat_item_Num,url_sp_royhat_item_Nomi;
    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        ViewHolder holder=new ViewHolder();
        Url_sp_list url_sp_list=url_sp_lists.get(position);

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.url_sp_royhat_item,null);
            holder.url_sp_royhat_item_Id=(TextView)row.findViewById(R.id.url_sp_royhat_item_Id);
            holder.url_sp_royhat_item_Num=(TextView)row.findViewById(R.id.url_sp_royhat_item_Num);
            holder.url_sp_royhat_item_Nomi=(TextView)row.findViewById(R.id.url_sp_royhat_item_Nomi);
            row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
        holder.url_sp_royhat_item_Id.setText(url_sp_list.getId());
        holder.url_sp_royhat_item_Num.setText(url_sp_list.getNum());
        holder.url_sp_royhat_item_Nomi.setText(url_sp_list.getNomi());



        return row;
    }
}
