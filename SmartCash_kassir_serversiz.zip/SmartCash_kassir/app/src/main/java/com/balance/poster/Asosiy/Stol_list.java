package com.balance.poster.Asosiy;

/**
 * Created by Ibrohimjon on 19.08.2018.
 */

public class Stol_list {

    String Raqam;
    int Holati;
    String Ofit_id;
    String Shot_id;
    String Ismi;
    String Ochil_vaqt;

    public Stol_list(String raqam, int holati, String ofit_id, String shot_id, String ismi, String ochil_vaqt) {
        Raqam = raqam;
        Holati = holati;
        Ofit_id = ofit_id;
        Shot_id = shot_id;
        Ismi = ismi;
        Ochil_vaqt = ochil_vaqt;
    }

    public String getRaqam() {
        return Raqam;
    }

    public void setRaqam(String raqam) {
        Raqam = raqam;
    }

    public int getHolati() {
        return Holati;
    }

    public void setHolati(int holati) {
        Holati = holati;
    }

    public String getOfit_id() {
        return Ofit_id;
    }

    public void setOfit_id(String ofit_id) {
        Ofit_id = ofit_id;
    }

    public String getShot_id() {
        return Shot_id;
    }

    public void setShot_id(String shot_id) {
        Shot_id = shot_id;
    }

    public String getIsmi() {
        return Ismi;
    }

    public void setIsmi(String ismi) {
        Ismi = ismi;
    }

    public String getOchil_vaqt() {
        return Ochil_vaqt;
    }

    public void setOchil_vaqt(String ochil_vaqt) {
        Ochil_vaqt = ochil_vaqt;
    }
}
