package com.balance.poster.Spravichnik.Menu;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.Menu.Menu_adapter;
import com.balance.poster.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 26.08.2018.
 */

public class Mneu_sp_adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Menu_sp_list>menuSpLists;

    public Mneu_sp_adapter(Context context, ArrayList<Menu_sp_list> menuSpLists) {
        this.context = context;
        this.menuSpLists = menuSpLists;
    }

    @Override
    public int getCount() {
        return menuSpLists.size();
    }

    @Override
    public Object getItem(int position) {
        return menuSpLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        TextView menu_sp_royhat_item_Num,menu_sp_royhat_item_Nomi,menu_sp_royhat_item_Bolim,menu_sp_royhat_item_id;
        ImageView menu_img;
    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row=view;
        ViewHolder holder=new ViewHolder();
        Menu_sp_list menu_sp_list=menuSpLists.get(position);

        if (row==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.menu_sp_royhat_item,null);
            holder.menu_img=(ImageView)row.findViewById(R.id.menu_sp_royhat_item_Img);
            holder.menu_sp_royhat_item_id=(TextView)row.findViewById(R.id.menu_sp_royhat_item_id);
            holder.menu_sp_royhat_item_Num=(TextView)row.findViewById(R.id.menu_sp_royhat_item_Num);
            holder.menu_sp_royhat_item_Nomi=(TextView)row.findViewById(R.id.menu_sp_royhat_item_Nomi);
            holder.menu_sp_royhat_item_Bolim=(TextView)row.findViewById(R.id.menu_sp_royhat_item_Bolim);
        row.setTag(holder);
        }else {
            holder=(ViewHolder)row.getTag();
        }
            holder.menu_sp_royhat_item_id.setText(menu_sp_list.getId());
            holder.menu_sp_royhat_item_Num.setText(menu_sp_list.getNum());
            holder.menu_sp_royhat_item_Nomi.setText(menu_sp_list.getNomi());
            holder.menu_sp_royhat_item_Bolim.setText(menu_sp_list.getBolim());
            byte[]food=menu_sp_list.getRasm();
            Bitmap bitmap= BitmapFactory.decodeByteArray(food,0,food.length);
            holder.menu_img.setImageBitmap(bitmap);

        return row;
    }
}
