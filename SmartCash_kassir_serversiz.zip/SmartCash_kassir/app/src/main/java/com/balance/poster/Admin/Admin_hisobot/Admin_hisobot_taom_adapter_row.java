package com.balance.poster.Admin.Admin_hisobot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.balance.poster.R;

import java.util.ArrayList;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Admin_hisobot_taom_adapter_row extends BaseAdapter {
    Context context;
    private ArrayList<Admin_hisobot_taom_row_list> sotilganLists;

    public Admin_hisobot_taom_adapter_row(Context context, ArrayList<Admin_hisobot_taom_row_list> sotilganLists) {
        this.context = context;
        this.sotilganLists = sotilganLists;
    }

    @Override
    public int getCount() {
        return sotilganLists.size();
    }

    @Override
    public Object getItem(int position) {
        return sotilganLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_num, txt_ofit, txt_soni;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View row = view;

        ViewHolder holder = new ViewHolder();
        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.hisob_taom_item_row, null);
            holder.txt_num = (TextView) row.findViewById(R.id.txt_hisob_item_row_tartib);
            holder.txt_ofit = (TextView) row.findViewById(R.id.txt_hisob_item_row_ofit);
            holder.txt_soni = (TextView) row.findViewById(R.id.txt_hisob_item_row_soni);

            row.setTag(holder);

        } else {
            holder = (ViewHolder) row.getTag();
        }
        Admin_hisobot_taom_row_list sotilgan_list = sotilganLists.get(position);

        holder.txt_num.setText(sotilgan_list.getTartib());
        holder.txt_ofit.setText(sotilgan_list.getOfitsant());
        holder.txt_soni.setText(sotilgan_list.getSoni());


        return row;
    }
}
