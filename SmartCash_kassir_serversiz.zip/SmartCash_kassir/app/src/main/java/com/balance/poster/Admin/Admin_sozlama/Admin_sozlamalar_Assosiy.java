package com.balance.poster.Admin.Admin_sozlama;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Sozlamalar.Sozlama_oyna;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_Assosiy extends Fragment {
    LinearLayout set_oshxona_nomi, set_otdel;
    Switch switch_set_ofitsant, switch_set_stol, switch_set_yulduz, switch_set_menu;
    TextView txt_set_oshxona_nomi, txt_otdel_nomi, txt_oshxona_nomi, txt_ofitsant, txt_otdel, txt_stol_bormi, txt_tanlangan;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")

    View parent_view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_assosiy, container, false);
        init();
        return parent_view;
    }

    public void init() {
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        set_oshxona_nomi = (LinearLayout) parent_view.findViewById(R.id.set_oshxona_nomi);
        set_otdel = (LinearLayout) parent_view.findViewById(R.id.set_otdel);
        switch_set_ofitsant = (Switch) parent_view.findViewById(R.id.switch_set_ofitsant);
        switch_set_stol = (Switch) parent_view.findViewById(R.id.switch_set_stol);
        switch_set_yulduz = (Switch) parent_view.findViewById(R.id.switch_set_yulduz);
        switch_set_menu = (Switch) parent_view.findViewById(R.id.switch_set_menu);
        txt_set_oshxona_nomi = (TextView) parent_view.findViewById(R.id.txt_set_oshxona_nomi);
        txt_otdel_nomi = (TextView) parent_view.findViewById(R.id.txt_set_otdel_nomi);

        txt_oshxona_nomi = (TextView) parent_view.findViewById(R.id.oshxona_nomi);
        txt_ofitsant = (TextView) parent_view.findViewById(R.id.txt_ofitsant_bormi);
        txt_otdel = (TextView) parent_view.findViewById(R.id.txt_otdel_bormi);
        txt_stol_bormi = (TextView) parent_view.findViewById(R.id.txt_stol_bormi);
        txt_tanlangan = (TextView) parent_view.findViewById(R.id.txt_tanlan_bormi);

        txt_oshxona_nomi.setText(R.string.oshxona_nomi);
        txt_otdel.setText(R.string.otdel_bormi);
        txt_ofitsant.setText(R.string.ofitsant_bormi);
        txt_stol_bormi.setText(R.string.stol_bormi);
        txt_tanlangan.setText(R.string.tanlangan_taom_bormi);

        set_oshxona_nomi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nom_dialog();
            }
        });

        Mal_toldirish();
        switch_set_stol.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("stol_bormi", 1);
                } else {
                    Mal_saqlash("stol_bormi", 0);
                }
            }
        });

        switch_set_yulduz.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("yulduz_bormi", 1);
                } else {
                    Mal_saqlash("yulduz_bormi", 0);
                }
            }
        });


        switch_set_menu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("menu_bormi", 1);
                } else {
                    Mal_saqlash("menu_bormi", 0);
                }
            }
        });


        switch_set_ofitsant.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("ofitsant_bormi", 1);
                } else {
                    Mal_saqlash("ofitsant_bormi", 0);
                }
            }
        });
        set_otdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Otdel_dialog();
            }
        });

    }


    private void Otdel_dialog() {
        final Dialog dialog = new Dialog(getActivity(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_otdel);
        dialog.setCancelable(true);
        dialog.setTitle("");
        final Spinner spinner = dialog.findViewById(R.id.spin_otdel);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int taom_print = sharedPreferences.getInt("otdel_bormi", 0);

        final ArrayList<String> list = new ArrayList<>();
        final ArrayList<String> list_id = new ArrayList<>();
        list.clear();
        list_id.clear();
        list_id.add("0");
        list.add(getString(R.string.hamma_otdellarni));

        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM OTDEL");
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String prin_id = cursor.getString(0);
                String prin_nomi = cursor.getString(1);
                list_id.add(prin_id);
                list.add(prin_nomi);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);

        if (taom_print == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (taom_print == -1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else {
            int index = list_id.indexOf("" + taom_print);
            spinner.setSelection(index);
            swit.setChecked(true);
            spinner.setEnabled(true);
        }

        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    if (spinner.getSelectedItemPosition() == 0) {
                        editor.putInt("otdel_bormi", -1);
                        editor.commit();
                    } else {
                        int index = spinner.getSelectedItemPosition();
                        String id = list_id.get(index);
                        try {
                            int is = Integer.parseInt(id);
                            editor.putInt("otdel_bormi", is);
                            editor.commit();
                            String nomi = list.get(index);
                            txt_otdel_nomi.setText(nomi);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            Calendar calendar1 = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            String strDate = format.format(calendar1.getTime());
                            String sql = "INSERT INTO XATOLIKLAR VALUES (NULL,?,?,0)";
                            Login_oyna.SQLITE_HELPER.Mal_qoshish_2ta(strDate, e.getMessage(), sql);
                        }
                    }
                } else {
                    editor.putInt("otdel_bormi", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }


    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    private void Mal_toldirish() {
        int ofitsant_bormi = sharedPreferences.getInt("ofitsant_bormi", 0);
        int otdel_bormi = sharedPreferences.getInt("otdel_bormi", 0);
        int menu_bormi = sharedPreferences.getInt("menu_bormi", 0);
        int stol_bormi = sharedPreferences.getInt("stol_bormi", 0);
        int yulduz_bormi = sharedPreferences.getInt("yulduz_bormi", 0);

        if (otdel_bormi == 0) {
            Mal_saqlash("otdel_bormi", 0);
            txt_otdel_nomi.setText(R.string.otdel_yoq);
        } else if (otdel_bormi == -1) {
            txt_otdel_nomi.setText(getString(R.string.hamma_otdellarni));
        } else {
            Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM OTDEL WHERE Id = '" + otdel_bormi + "'");
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();

                String prin_nomi = cursor.getString(1);
                txt_otdel_nomi.setText(prin_nomi);
            }
        }
        if (menu_bormi == 0) {
            Mal_saqlash("menu_bormi", 0);
            switch_set_menu.setChecked(false);
        } else if (menu_bormi == 1) {
            switch_set_menu.setChecked(true);
        }
        if (stol_bormi == 0) {
            Mal_saqlash("stol_bormi", 0);
            switch_set_stol.setChecked(false);
        } else if (stol_bormi == 1) {
            switch_set_stol.setChecked(true);
        }
        if (yulduz_bormi == 0) {
            Mal_saqlash("yulduz_bormi", 0);
            switch_set_yulduz.setChecked(false);
        } else if (yulduz_bormi == 1) {
            switch_set_yulduz.setChecked(true);
        }
        if (ofitsant_bormi == 0) {
            Mal_saqlash("ofitsant_bormi", 0);
            switch_set_ofitsant.setChecked(false);
        } else if (ofitsant_bormi == 1) {
            switch_set_ofitsant.setChecked(true);
        }
        String oshxona_nomi = sharedPreferences.getString("oshxona_nomi", "");
        txt_set_oshxona_nomi.setText(oshxona_nomi);
    }

    private void Nom_dialog() {

        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_oshxona_nomi);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setTitle("");
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);
        final EditText edt_nomi = dialog.findViewById(R.id.edt_set_oshxona_nomi);

        String oshxona_nomi = sharedPreferences.getString("oshxona_nomi", "");
        edt_nomi.setText(oshxona_nomi);
        edt_nomi.setSelection(oshxona_nomi.length());
        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomi = edt_nomi.getText().toString();
                if (!nomi.equals("")) {
                    editor.putString("oshxona_nomi", nomi);
                    editor.commit();
                    dialog.cancel();
                    txt_set_oshxona_nomi.setText(nomi);
                }
            }
        });

        dialog.show();

    }

}
