package com.balance.poster.Asosiy;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.graphics.drawable.DrawerArrowDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Ofitsant.Ofitsant_oyna;
import com.balance.poster.R;
import com.balance.poster.Saboy1.Saboy1_oyna;
import com.balance.poster.Umumiy.Umumiy_oyna;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class Stol_oyna extends Fragment {

    GridView gridView;
    static ArrayList<Stol_list> stol_raqam = new ArrayList<>();
    public static String ofit_ismi = "";
    public static String ofit_id_asos = "";
    static Stol_adapter adapter;
    public static Activity activity;
    private View parentView;
    FragmentTransaction fragment;
    static int ofit_bormi = 0;
    static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parentView = inflater.inflate(R.layout.stol_oyna, container, false);
        Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.package_icon);
        Bosh_oyna.btn_asos_saboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Saboy1_oyna());
            }
        });
        Setup();
        return parentView;
    }

    private void Setup() {

        activity = getActivity();
        layout_ofit_mal_yoq = parentView.findViewById(R.id.layout_ofit_mal_yoq);
        ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
        if (ofit_bormi == 1) {
            Bundle bundle = this.getArguments();
            if (bundle != null) {
                ofit_id_asos = bundle.getString("id");
                ofit_ismi = bundle.getString("ismi");
            }
            Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);

            Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
                    if (ofit_bormi == 0) {
                        if (stol_bormi == 0) {
                            changeFragment(new Saboy1_oyna());
                        } else {
                            changeFragment(new Stol_oyna());
                        }
                    } else if (ofit_bormi == 1) {
                        changeFragment(new Ofitsant_oyna());
                    }
                }
            });
            Bosh_oyna.txt_asos_tool.setText(String.format(getString(R.string.stol_oyna_ofitsant), ofit_ismi));
        } else {

            Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
            Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
            Bosh_oyna.btn_asos_saboy.setVisibility(View.VISIBLE);
            ofit_ismi = "Ofitsant yo'q";
            ofit_id_asos = "Ofitsant yo'q";
            Bosh_oyna.txt_asos_tool.setText(R.string.stollar_royhati);
            Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.nav_icon);

            Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bosh_oyna.drawer.openDrawer(Gravity.LEFT);
                }
            });
        }
        gridView = (GridView) parentView.findViewById(R.id.grid_view_stol);

        adapter = new Stol_adapter(getContext(), stol_raqam);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Stol_list list = stol_raqam.get(position);
                String nomi = list.getRaqam();
                String shot_id = list.getShot_id();
                String ofit_id = list.getOfit_id();
                String holati = list.getHolati() + "";
                String vaqti = list.getOchil_vaqt();

                if (ofit_id.equals(ofit_id_asos)) {
                    Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                    intent.putExtra("stol", nomi);
                    intent.putExtra("ofit", ofit_id_asos);
                    intent.putExtra("shot", shot_id);
                    intent.putExtra("vaqti", vaqti);
                    startActivity(intent);
                } else {
                    if (holati.equals("1")) {
                        new SweetAlertDialog(getContext(), SweetAlertDialog.ERROR_TYPE)
                                .setTitleText("")
                                .setContentText(getString(R.string.boshqa_ofit_qarayapti))
                                .show();
                    } else {
                        Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                        intent.putExtra("stol", nomi);
                        intent.putExtra("ofit", ofit_id_asos);
                        intent.putExtra("shot", "yangi");
                        intent.putExtra("vaqti", vaqti);
                        startActivity(intent);
                    }
                }

            }
        });

        Get_stol();
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public static void Get_stol() {
        Cursor cursor = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM STOL_SONI");
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            stol_raqam.clear();
            layout_ofit_mal_yoq.setVisibility(View.GONE);
            int soni = cursor.getInt(1);
            if (soni > 0) {
                for (int i = 1; i <= soni; i++) {
                    Cursor cursor_1 = Login_oyna.SQLITE_HELPER.getData("SELECT stol.*, ofit.ismi FROM STOLLAR AS stol INNER JOIN OFITSANT AS ofit ON stol.ofit_id = ofit.Id WHERE stol.nomi='" + i + "' AND stol.holati = 0");
                    if (cursor_1.getCount() != 0) {
                        cursor_1.moveToFirst();
                        String nomi = cursor_1.getString(1);
                        String ofit_id = cursor_1.getString(3);
                        String shot_id = cursor_1.getString(4);
                        String vaqti = cursor_1.getString(5);
                        String ismi = cursor_1.getString(6);
//                        if (ofit_id.equals(ofit_id_asos)) {
                            stol_raqam.add(new Stol_list(nomi, 2, ofit_id, shot_id, ismi, vaqti));
//                        } else {
//                            stol_raqam.add(new Stol_list(nomi, 1, ofit_id, shot_id, ismi, vaqti));
//                        }
                    } else {
                        if (ofit_bormi == 0) {
                            Cursor cursor1 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM STOLLAR WHERE nomi='" + i + "' AND holati=0 AND ofit_id = 'Ofitsant yo''q'");
                            if (cursor1.getCount() != 0) {
                                cursor1.moveToFirst();
                                String nomi = cursor1.getString(1);
                                String ofit_id = "Ofitsant yo'q";
                                String shot = cursor1.getString(4);
                                String vaqti = cursor1.getString(5);
                                String ismi = "Ofitsant yo'q";
                                stol_raqam.add(new Stol_list(nomi, 2, ofit_id, shot, ismi, vaqti));
                            } else {
                                stol_raqam.add(new Stol_list("" + i, 0, "", "", "", ""));
                            }
                        } else if (ofit_bormi == 1) {
                            stol_raqam.add(new Stol_list("" + i, 0, "", "", "", ""));
                        }
                    }
                }
            }
            adapter.notifyDataSetChanged();
        } else {
            stol_raqam.clear();
            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            adapter.notifyDataSetChanged();
        }
    }

}
