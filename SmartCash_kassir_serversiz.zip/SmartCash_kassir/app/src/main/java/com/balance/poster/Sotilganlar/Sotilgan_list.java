package com.balance.poster.Sotilganlar;

/**
 * Created by Hunter on 22.08.2018.
 */

public class Sotilgan_list {
    String num;
    String Ochil_sana;
    String Yop_sana;
    String stol;
    String shot;
    String summ;
    String ofit;
    String taom_sum;
    String xizm_sum;
    String tolov_sum;

    public Sotilgan_list(String num, String ochil_sana, String yop_sana, String stol, String shot, String summ, String ofit, String taom_sum, String xizm_sum, String tolov_sum) {
        this.num = num;
        Ochil_sana = ochil_sana;
        Yop_sana = yop_sana;
        this.stol = stol;
        this.shot = shot;
        this.summ = summ;
        this.ofit = ofit;
        this.taom_sum = taom_sum;
        this.xizm_sum = xizm_sum;
        this.tolov_sum = tolov_sum;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getOchil_sana() {
        return Ochil_sana;
    }

    public void setOchil_sana(String ochil_sana) {
        Ochil_sana = ochil_sana;
    }

    public String getYop_sana() {
        return Yop_sana;
    }

    public void setYop_sana(String yop_sana) {
        Yop_sana = yop_sana;
    }

    public String getStol() {
        return stol;
    }

    public void setStol(String stol) {
        this.stol = stol;
    }

    public String getShot() {
        return shot;
    }

    public void setShot(String shot) {
        this.shot = shot;
    }

    public String getSumm() {
        return summ;
    }

    public void setSumm(String summ) {
        this.summ = summ;
    }

    public String getOfit() {
        return ofit;
    }

    public void setOfit(String ofit) {
        this.ofit = ofit;
    }

    public String getTaom_sum() {
        return taom_sum;
    }

    public void setTaom_sum(String taom_sum) {
        this.taom_sum = taom_sum;
    }

    public String getXizm_sum() {
        return xizm_sum;
    }

    public void setXizm_sum(String xizm_sum) {
        this.xizm_sum = xizm_sum;
    }

    public String getTolov_sum() {
        return tolov_sum;
    }

    public void setTolov_sum(String tolov_sum) {
        this.tolov_sum = tolov_sum;
    }
}
