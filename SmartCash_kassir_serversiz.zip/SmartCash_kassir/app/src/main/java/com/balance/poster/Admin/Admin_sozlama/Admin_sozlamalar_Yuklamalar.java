package com.balance.poster.Admin.Admin_sozlama;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Sozlamalar.Sozlama_oyna;

import java.util.ArrayList;

/**
 * Created by Hunter on 06.09.2018.
 */

public class Admin_sozlamalar_Yuklamalar extends Fragment {
    View parent_view;
    Switch switch_set_sync;
    LinearLayout set_auto_delete;
    TextView txt_set_auto_delete;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    TextView txt_avto_ochirish, txt_yuklansinmi;

    @SuppressLint("CommitPrefEdits")

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.admin_sozlamalar_yuklamalar, container, false);
        init();
        return parent_view;
    }

    public void init() {
        sharedPreferences = getActivity().getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        txt_avto_ochirish = parent_view.findViewById(R.id.txt_avto_ochirilishi);
        txt_yuklansinmi = parent_view.findViewById(R.id.txt_malumot_yuklansinmi);

        txt_avto_ochirish.setText(R.string.ma_lumot_xotiradan_o_chirilishi_muddati);
        txt_yuklansinmi.setText(R.string.onlinega_ma_lumotlar_yuklansinmi);

        switch_set_sync = (Switch) parent_view.findViewById(R.id.switch_set_sync);
        set_auto_delete = (LinearLayout) parent_view.findViewById(R.id.set_auto_delete);
        txt_set_auto_delete = (TextView) parent_view.findViewById(R.id.txt_set_auto_delete);
        Mal_toldirish();

        switch_set_sync.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Mal_saqlash("sync_bormi", 1);
                } else {
                    Mal_saqlash("sync_bormi", 0);
                }
            }
        });

        set_auto_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Auto_delete_dialog();
            }
        });

    }

    public void Mal_saqlash(String kalit, int qiymat) {
        editor.putInt(kalit, qiymat);
        editor.commit();
    }

    private void Auto_delete_dialog() {
        final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
        dialog.setContentView(R.layout.set_auto_delete);
        dialog.setCancelable(true);
        dialog.setTitle("");
        final Spinner spinner = dialog.findViewById(R.id.spin_printer);
        final Switch swit = dialog.findViewById(R.id.switch_taom_print);
        Button btn_ortga = dialog.findViewById(R.id.btn_set_dialog_ortga);
        Button btn_saqlash = dialog.findViewById(R.id.btn_set_dialog_saqlash);

        int auto_delete = sharedPreferences.getInt("auto_delete", 0);

        ArrayList<String> list = new ArrayList<>();
        list.add(getString(R.string.hammasini));
        list.add(getString(R.string.osha_1_kungi));
        list.add(getString(R.string.osha_2_kungi));
        list.add(getString(R.string.osha_3_kungi));
        list.add(getString(R.string.osha_1_haftalik));

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setEnabled(false);
        if (auto_delete == 0) {
            swit.setChecked(false);
            spinner.setEnabled(false);
        } else if (auto_delete == 1) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(0);
        } else if (auto_delete == 2) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(1);
        } else if (auto_delete == 3) {
            swit.setChecked(true);
            spinner.setEnabled(true);
            spinner.setSelection(2);
        }
        swit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                spinner.setEnabled(isChecked);
            }
        });

        btn_ortga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (swit.isChecked()) {
                    int index = spinner.getSelectedItemPosition();
                    editor.putInt("auto_delete", index + 1);
                    editor.commit();
                } else {
                    editor.putInt("auto_delete", 0);
                    editor.commit();
                }
                dialog.cancel();
                Mal_toldirish();
            }
        });

        dialog.show();
    }

    private void Mal_toldirish() {

        int sync_bormi = sharedPreferences.getInt("sync_bormi", 0);

        if (sync_bormi == 0) {
            Mal_saqlash("sync_bormi", 0);
        }
        if (sync_bormi == 0) {
            switch_set_sync.setChecked(false);
        } else if (sync_bormi == 1) {
            switch_set_sync.setChecked(true);
        }


        int auto_delete = sharedPreferences.getInt("auto_delete", 0);

        if (auto_delete == 0) {
            txt_set_auto_delete.setText(R.string.avto_ochirilmaydi);
        } else if (auto_delete == 1) {
            txt_set_auto_delete.setText(R.string.hammasini);
        } else if (auto_delete == 2) {
            txt_set_auto_delete.setText(R.string.osha_1_kungi);
        } else if (auto_delete == 3) {
            txt_set_auto_delete.setText(R.string.osha_2_kungi);
        } else if (auto_delete == 4) {
            txt_set_auto_delete.setText(R.string.osha_3_kungi);
        } else if (auto_delete == 5) {
            txt_set_auto_delete.setText(R.string.osha_1_haftalik);
        }
    }

}
