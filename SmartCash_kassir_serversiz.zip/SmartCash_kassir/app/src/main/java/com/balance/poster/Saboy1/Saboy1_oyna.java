package com.balance.poster.Saboy1;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.poster.Asosiy.Bosh_oyna;
import com.balance.poster.Asosiy.Stol_oyna;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Ofitsant.Ofitsant_oyna;
import com.balance.poster.R;
import com.balance.poster.Umumiy.Umumiy_oyna;

import java.util.ArrayList;

/**
 * Created by Hunter on 05.09.2018.
 */

public class Saboy1_oyna extends Fragment {
    private View parent_view;
    GridView gv;
    static ArrayList<Saboy1_list> saboy1Lists = new ArrayList<>();
    static Saboy1_adapter saboy1_adapter;
    FragmentTransaction fragment;
    public static View layout_ofit_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.saboy1_oyna, container, false);
        Bosh_oyna.txt_asos_tool.setText(R.string.saboy_royh);
        final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
        final int stol_bormi = Bosh_oyna.sharedPreferences.getInt("stol_bormi", 1);
//        if (ofit_bormi == 0) {
//            if (stol_bormi == 0) {
//                Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.nav_icon);
//                Bosh_oyna.btn_asos_saboy.setVisibility(View.GONE);
//                Bosh_oyna.layout_asos_sana.setVisibility(View.GONE);
//                Bosh_oyna.btn_lock.setVisibility(View.VISIBLE);
//            } else {
//                Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.back_icon);
//                Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.stol_bosh);
//            }
//        } else if (ofit_bormi == 1) {
        Bosh_oyna.btn_asos_nav.setImageResource(R.drawable.nav_icon);
        Bosh_oyna.btn_asos_saboy.setImageResource(R.drawable.waiter);
//        }
        Bosh_oyna.btn_asos_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
//                if (ofit_bormi == 0) {
//                    if (stol_bormi == 0) {
//                        Bosh_oyna.drawer.openDrawer(Gravity.LEFT);
//                    } else {
//                        changeFragment(new Stol_oyna());
//                    }
//                } else if (ofit_bormi == 1) {
//                    changeFragment(new Ofitsant_oyna());
//                }

                Bosh_oyna.drawer.openDrawer(Gravity.LEFT);
            }
        });
        Bosh_oyna.btn_asos_saboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final int ofit_bormi = Bosh_oyna.sharedPreferences.getInt("ofitsant_bormi", 1);
//                if (ofit_bormi == 0) {
//                    changeFragment(new Stol_oyna());
//                } else if (ofit_bormi == 1) {
                changeFragment(new Ofitsant_oyna());
//                }
            }
        });
        init();
        return parent_view;
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getActivity().getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

    }

    public void init() {
        layout_ofit_mal_yoq = parent_view.findViewById(R.id.layout_ofit_mal_yoq);
        gv = (GridView) parent_view.findViewById(R.id.saboy_Grid);
        saboy1_adapter = new Saboy1_adapter(getContext(), saboy1Lists);
        gv.setAdapter(saboy1_adapter);
        LoadData();

        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView shot = (TextView) view.findViewById(R.id.txt_saboy1_item_id);
                TextView vaqti = (TextView) view.findViewById(R.id.txt_saboy1_item_vaqt);
                String shot1 = shot.getText().toString().trim();
                String vaq = vaqti.getText().toString().trim();
                if (shot1.equals("plus")) {
                    Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                    intent.putExtra("stol", "Saboy");
                    intent.putExtra("ofit", "Saboy");
                    intent.putExtra("shot", "yangi");
                    intent.putExtra("vaqti", "");
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getContext(), Umumiy_oyna.class);
                    intent.putExtra("stol", "Saboy");
                    intent.putExtra("ofit", "Saboy");
                    intent.putExtra("shot", shot1);
                    intent.putExtra("vaqti", vaq);
                    startActivity(intent);
                }
            }
        });


    }

    public static void LoadData() {
        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT * FROM SHOTLAR WHERE ofit_id = 'saboy' AND yopilgan_sana IS NULL");
        int p = 0;
        if (cursor_2.getCount() != 0) {
            saboy1Lists.clear();
            layout_ofit_mal_yoq.setVisibility(View.GONE);
            saboy1Lists.add(new Saboy1_list("plus", "0", ""));
            cursor_2.moveToFirst();
            do {
                p++;
                String shot = cursor_2.getString(1);
                String ochilganvaqti = cursor_2.getString(2);
                saboy1Lists.add(new Saboy1_list(shot, String.valueOf(p), ochilganvaqti));
            } while (cursor_2.moveToNext());
            saboy1_adapter.notifyDataSetChanged();

        } else {
            saboy1Lists.clear();
            layout_ofit_mal_yoq.setVisibility(View.VISIBLE);
            saboy1Lists.add(new Saboy1_list("plus", "0", ""));
            saboy1_adapter.notifyDataSetChanged();
        }

    }

}
