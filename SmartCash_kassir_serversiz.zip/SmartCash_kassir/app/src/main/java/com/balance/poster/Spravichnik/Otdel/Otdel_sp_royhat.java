package com.balance.poster.Spravichnik.Otdel;


import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.balance.poster.Admin.Admin_sp_royhat.Admin_Sp_oyna;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.R;
import com.balance.poster.Spravichnik.Ofitsant.Ofitsant_sp_oynaQoshish;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

/**
 * Created by Hunter on 25.08.2018.
 */

public class Otdel_sp_royhat extends Fragment {
    private View parent_view;
    ListView lv;
    static ArrayList<Otdel_sp_list> otdelSpLists = new ArrayList<>();
    static Otdel_sp_adapter otdel_sp_adapter;
    static View txt_otdel_oyna_mal_yoq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        parent_view = inflater.inflate(R.layout.otdel_sp_royhat, container, false);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setVisibility(View.VISIBLE);
        Admin_Sp_oyna.btn_admin_spr_qoshish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), Otdel_sp_QoshishOyna.class);
                intent.putExtra("SESSION_ID", "");
                startActivity(intent);
            }
        });
        init();
        return parent_view;
    }

    public void init() {
        lv = (ListView) parent_view.findViewById(R.id.otdel_sp_royhatList);
        otdelSpLists.clear();
        txt_otdel_oyna_mal_yoq = parent_view.findViewById(R.id.txt_otdel_oyna_mal_yoq);


        otdel_sp_adapter = new Otdel_sp_adapter(getContext(), otdelSpLists);
        lv.setAdapter(otdel_sp_adapter);
        GetData_Otdel();


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                final Dialog dialog = new Dialog(getContext(), R.style.ozgart_oyna_di);
                dialog.setContentView(R.layout.alertdialog_oyna);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.setTitle("O'zgartirish");
                Button btn_change = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ozgartir);
                Button btn_delet = (Button) dialog.findViewById(R.id.btn_foydalan_sp_ochir);
                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextView idd = (TextView) view.findViewById(R.id.otdel_sp_royhat_item_id);
                        String f_id = idd.getText().toString();
                        Intent intent = new Intent(getContext(), Otdel_sp_QoshishOyna.class);
                        intent.putExtra("SESSION_ID", f_id);
                        startActivity(intent);
                        dialog.dismiss();


                    }
                });

                btn_change.setText(R.string.o_zgartirish);
                btn_delet.setText(R.string.o_chirish);
                btn_delet.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        TextView idd = (TextView) view.findViewById(R.id.otdel_sp_royhat_item_id);
                        String f_id = idd.getText().toString();
                        Login_oyna.SQLITE_HELPER.deleteData("DELETE FROM OTDEL WHERE Id='" + f_id + "'");
                        GetData_Otdel();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
    }

    public static void GetData_Otdel() {
        Cursor cursor_2 = Login_oyna.SQLITE_HELPER.getData("SELECT print.nomi,otdel.* FROM OTDEL AS otdel INNER JOIN PRINTER AS print ON" +
                " otdel.printer=print.Id");
        int p = 0;
        if (cursor_2.getCount() != 0) {
            otdelSpLists.clear();
            cursor_2.moveToFirst();
            txt_otdel_oyna_mal_yoq.setVisibility(View.GONE);
            do {
                p++;

                String printer_Nomi = cursor_2.getString(0);
                String id = cursor_2.getString(1);
                String nomi = cursor_2.getString(2);
                byte[] rasm = cursor_2.getBlob(3);
                String num = String.valueOf(p);
                otdelSpLists.add(new Otdel_sp_list(id, num, nomi, printer_Nomi, rasm));

            } while (cursor_2.moveToNext());
            otdel_sp_adapter.notifyDataSetChanged();

        } else {
            otdelSpLists.clear();
            txt_otdel_oyna_mal_yoq.setVisibility(View.VISIBLE);
            otdel_sp_adapter.notifyDataSetChanged();
        }

    }
}