package com.balance.poster.Asosiy;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.balance.poster.Admin.Admin_Assosiy_oyna.Admin_asosiy_oyna;
import com.balance.poster.Dastur_haqida.Dastur_haqida_oyna;
import com.balance.poster.Hisobot.Hisobot_ofitsant;
import com.balance.poster.Login.Login_oyna;
import com.balance.poster.Ofitsant.Ofitsant_oyna;
import com.balance.poster.Otmenalar.Otmena_oyna;
import com.balance.poster.R;
import com.balance.poster.Saboy1.Saboy1_oyna;
import com.balance.poster.Sotilganlar.Sotilgan_oyna;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.StringTokenizer;

import cn.pedant.SweetAlert.SweetAlertDialog;

/**
 * Created by Ibrohimjon on 19.08.2018.
 */

public class Bosh_oyna extends FragmentActivity {

    private Bosh_oyna mContext;
    public static ImageButton btn_lock, btn_asos_saboy;
    FragmentTransaction fragment;

    public static int year_x, month_x, day_x;
    int DatePicker = 1;
    Animation slideInRight, fadeOut;
    public static TextView txt_asos_tool, txt_sana;
    public static View layout_asos_sana;
    public static ImageView btn_asos_nav;
    public static SharedPreferences sharedPreferences;
    public static DrawerLayout drawer;
    public static int qaysi_oyna = 0;
    public static int HISOB_OYNA = 1;
    public static int OTMEN_OYNA = 2;
    public static int SOTILGAN_OYNA = 3;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = getSharedPreferences("Sozlamalar", Activity.MODE_PRIVATE);
        txt_asos_tool = (TextView) findViewById(R.id.txt_asos_toolbar);
        txt_sana = (TextView) findViewById(R.id.txt_asos_sana);
        slideInRight = AnimationUtils.loadAnimation(this, R.anim.anim_in);
        fadeOut = AnimationUtils.loadAnimation(this, R.anim.anim_out);
        btn_asos_nav = (ImageView) findViewById(R.id.btn_asos_nav);
        layout_asos_sana = (View) findViewById(R.id.layout_asos_sana);
        btn_asos_saboy = (ImageButton) findViewById(R.id.btn_asos_saboy);
        btn_lock = (ImageButton) findViewById(R.id.btn_asos_lock);


        btn_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bosh_oyna.this, Login_oyna.class);
                startActivity(intent);
            }
        });

        btn_asos_saboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Saboy1_oyna());
            }
        });
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        String strDate = format.format(calendar1.getTime());
        txt_sana.setText(strDate);

        final Calendar calendar = Calendar.getInstance();
        year_x = calendar.get(Calendar.YEAR);
        month_x = calendar.get(Calendar.MONTH);
        day_x = calendar.get(Calendar.DAY_OF_MONTH);
        txt_sana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DatePicker);
            }
        });

        layout_asos_sana.setVisibility(View.GONE);

        mContext = this;

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        View btn_nav_asosiy = (View) findViewById(R.id.btn_nav_asosiy);
        View btn_nav_shot = (View) findViewById(R.id.btn_nav_yopil_shot);
        View btn_nav_qayt_taom = (View) findViewById(R.id.btn_nav_qaytgan_taom);
        View btn_nav_hisobot = (View) findViewById(R.id.btn_nav_hisobot);
        View btn_nav_yuklama = (View) findViewById(R.id.btn_nav_yuklama);
        View btn_nav_sozlama = (View) findViewById(R.id.btn_nav_sozlama);
        View btn_nav_dastur = (View) findViewById(R.id.btn_nav_dastur);
        View btn_nav_log_out = (View) findViewById(R.id.btn_nav_log_out);

        TextView txt_asos = btn_nav_asosiy.findViewById(R.id.txt_nav_asosiy);
        TextView txt_shot = btn_nav_shot.findViewById(R.id.txt_nav_yop_shot);
        TextView txt_dastur = btn_nav_dastur.findViewById(R.id.txt_nav_dastur);
        TextView txt_otmen = btn_nav_qayt_taom.findViewById(R.id.txt_nav_otmen);
        TextView txt_hisob = btn_nav_hisobot.findViewById(R.id.txt_nav_ofit_hisob);
        TextView txt_log = btn_nav_log_out.findViewById(R.id.txt_nav_log_out);

        txt_asos.setText(R.string.nav_asosiy_oyna);
        txt_shot.setText(R.string.nav_yopilgan_shotlar);
        txt_dastur.setText(R.string.nav_dastur_haqida);
        txt_otmen.setText(R.string.nav_qaytarilgan_taom);
        txt_hisob.setText(R.string.nav_ofitsant_hisoboti);
        txt_log.setText(R.string.log_out);

        btn_nav_shot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Sotilgan_oyna());
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });
        btn_nav_qayt_taom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Otmena_oyna());
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });
        btn_nav_hisobot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Hisobot_ofitsant());
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });
        btn_nav_yuklama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                changeFragment(new Yuklama_oyna(), 0);
//                txt_asos_tool.setText("Yuklama oyna");
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });


        int ochir_royh_korish = sharedPreferences.getInt("ochir_royh_korish", 1);
        int tolov_korish = sharedPreferences.getInt("tolov_korish", 1);
        int pul_korish = sharedPreferences.getInt("pul_korish", 1);
        final int ofit_bormi = sharedPreferences.getInt("ofitsant_bormi", 1);
        final int stol_bormi = sharedPreferences.getInt("stol_bormi", 1);

//        if (ofit_bormi == 0) {
//            if (stol_bormi == 0) {
//                if (savedInstanceState == null) {
//                    changeFragment(new Saboy1_oyna());
//                }
//            } else {
//                if (savedInstanceState == null) {
//                    changeFragment(new Stol_oyna());
//                }
//            }
//        } else if (ofit_bormi == 1) {
//            if (savedInstanceState == null) {
//                changeFragment(new Ofitsant_oyna());
//            }
//        }
        if (savedInstanceState == null) {
            changeFragment(new Saboy1_oyna());
        }
        btn_nav_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (ofit_bormi == 0) {
//                    if (stol_bormi == 0) {
                        changeFragment(new Saboy1_oyna());
//                    } else {
//                        changeFragment(new Stol_oyna());
//                    }
//                } else if (ofit_bormi == 1) {
//                    changeFragment(new Ofitsant_oyna());
//                }

                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });
        if (ochir_royh_korish == 1) {
            btn_nav_qayt_taom.setVisibility(View.VISIBLE);
        } else {
            btn_nav_qayt_taom.setVisibility(View.GONE);
        }

        if (tolov_korish == 1) {
            btn_nav_shot.setVisibility(View.VISIBLE);
        } else {
            btn_nav_shot.setVisibility(View.GONE);
        }

        if (pul_korish == 1) {
            btn_nav_hisobot.setVisibility(View.VISIBLE);
        } else {
            btn_nav_hisobot.setVisibility(View.GONE);
        }

        btn_nav_sozlama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bosh_oyna.this, Admin_asosiy_oyna.class);
                startActivity(intent);
//                changeFragment(new Sozlama_oyna());
//                txt_asos_tool.setText("Sozlama oyna");
//                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//                drawer.closeDrawer(GravityCompat.START);
            }
        });
        btn_nav_dastur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(new Dastur_haqida_oyna());
                txt_asos_tool.setText(R.string.dastur_haqida);
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });
        btn_nav_log_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bosh_oyna.this, Login_oyna.class);
                startActivity(intent);
                finish();
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });
    }

    public void changeFragment(Fragment targetFragment) {
        fragment = getSupportFragmentManager().beginTransaction();
        fragment.setCustomAnimations(R.anim.slide_in_right, R.anim.hide)
                .replace(R.id.main_fragment, targetFragment)
                .commit();

        Sozlash_qolgan();
    }


    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == DatePicker) {
            return new DatePickerDialog(Bosh_oyna.this, dpickerListener1, year_x, month_x, day_x);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener dpickerListener1 = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(android.widget.DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String oy, kun;
            if (monthOfYear < 10) {
                oy = "0" + String.valueOf(monthOfYear + 1) + ".";
            } else {
                oy = String.valueOf(monthOfYear + 1) + ".";
            }
            if (dayOfMonth < 10) {
                kun = "0" + String.valueOf(dayOfMonth) + ".";
            } else {
                kun = String.valueOf(dayOfMonth) + ".";
            }
            String string = kun.toString() + oy.toString() + String.valueOf(year);

            txt_sana.setText(string);
            if (qaysi_oyna == HISOB_OYNA) {
                String sql = "SELECT shot.ofit_id, tolov.xizmat_sum FROM TOLOVLAR AS tolov INNER JOIN SHOTLAR AS shot ON tolov.shot_raqam = shot.shot_raqam WHERE tolov.vaqti LIKE '" + string + "%' AND tolov.vaqti = shot.yopilgan_sana ORDER BY shot.ofit_id ASC";

                Hisobot_ofitsant.Orqa_get_data orqa_get_data = new Hisobot_ofitsant.Orqa_get_data(sql, Bosh_oyna.this);
                orqa_get_data.execute();
            } else if (qaysi_oyna == SOTILGAN_OYNA) {
                String sql = "SELECT tolov.naqd, tolov.plastik, tolov.taom_sum, tolov.xizmat_sum, tolov.tolov_sum, shot.* FROM SHOTLAR AS shot INNER JOIN TOLOVLAR AS tolov ON shot.shot_raqam = tolov.shot_raqam WHERE shot.yopilgan_sana LIKE '" + string + "%' AND shot.yopilgan_sana = tolov.vaqti";
                Sotilgan_oyna.Yangilash yangilash = new Sotilgan_oyna.Yangilash(sql);
                yangilash.execute();
            } else if (qaysi_oyna == OTMEN_OYNA) {
                String sql = "SELECT * FROM OTMEN_TAOMLAR WHERE ochirilgan_sana LIKE '" + string + "%'";
                Otmena_oyna.Yangilash yangilash = new Otmena_oyna.Yangilash(sql, Bosh_oyna.this);
                yangilash.execute();
            }
        }
    };

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Bosh_oyna.this, Login_oyna.class);
        startActivity(intent);
        super.onBackPressed();
    }

    public static void OGOHLANTIRISH_XABAR(Context c, String title, String text) {
        new SweetAlertDialog(c, SweetAlertDialog.ERROR_TYPE)
                .setTitleText(title)
                .setContentText(text)
                .show();
    }


    public static String getDecimalFormattedString(String value) {
        StringTokenizer lst = new StringTokenizer(value, ".");
        String str1 = value;
        String str2 = "";
        if (lst.countTokens() > 1) {
            str1 = lst.nextToken();
            str2 = lst.nextToken();
        }
        String str3 = "";
        int i = 0;
        int j = -1 + str1.length();
        if (str1.charAt(-1 + str1.length()) == '.') {
            j--;
            str3 = ".";
        }
        for (int k = j; ; k--) {
            if (k < 0) {
                if (str2.length() > 0)
                    str3 = str3 + "." + str2;
                return str3;
            }
            if (i == 3) {
                str3 = " " + str3;
                i = 0;
            }
            str3 = str1.charAt(k) + str3;
            i++;
        }

    }

    public static void Sozlash_qolgan() {
        layout_asos_sana.setVisibility(View.GONE);
        btn_lock.setVisibility(View.VISIBLE);
        btn_asos_saboy.setVisibility(View.VISIBLE);
    }

}
