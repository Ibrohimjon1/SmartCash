package com.ufreedom.uikit;

/**
 * Author UFreedom
 * 
 * 
 */
public interface FloatingPathEffect {

    abstract FloatingPath getFloatingPath(FloatingTextView floatingTextView);


}
