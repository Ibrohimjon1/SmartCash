package com.ufreedom.uikit;

/**
 * Author UFreedom
 * 
 */
public interface FloatingAnimator {

    public void applyFloatingAnimation(FloatingTextView view);

}
